//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by expresion.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EXPRESION_DIALOG            102
#define IDS_VARLIST_COL1                102
#define IDS_VARLIST_COL2                103
#define IDS_ERROR_AT                    104
#define IDS_DIVBY0                      105
#define IDR_MAINFRAME                   128
#define IDD_VARINSERT                   129
#define IDC_EXPRESSION_EDIT             1000
#define IDC_RESULT_EDIT                 1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_CHECK1                      1003
#define IDC_VARNAME_EDIT                1004
#define IDC_VARVLUE_EDIT                1005
#define IDC_LIST1                       1007
#define IDC_BUTTON3                     1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
