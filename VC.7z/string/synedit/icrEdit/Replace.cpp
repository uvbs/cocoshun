// Replace.cpp : implementation file
//

#include "stdafx.h"
#include "icrEdit.h"
#include "Replace.h"
#include "MRUCombo.h"
#include "BtnST.h"
#include "Mainfrm.h"
#include "icrEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReplace dialog


CReplace::CReplace(CWnd* pParent /*=NULL*/)
	: CDialog(CReplace::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReplace)
	m_chkcasevalue = FALSE;
	m_chkwordvalue = FALSE;
	m_cmb1string = _T("");
	m_cmb2string = _T("");
	//}}AFX_DATA_INIT
}


void CReplace::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReplace)
	DDX_Control(pDX, IDC_CMB2, m_cmb2);
	DDX_Control(pDX, IDC_CMB1, m_cmb1);
	DDX_Control(pDX, IDC_CHKWORD, m_chkword);
	DDX_Control(pDX, IDC_CHKCASE, m_chkcase);
	DDX_Control(pDX, IDC_REPLACEALL, m_cmdreplaceall);
	DDX_Control(pDX, IDC_REPLACE, m_cmdreplace);
	DDX_Control(pDX, IDC_FINDNEXT, m_cmdnext);
	DDX_Control(pDX, IDC_CANCEL, m_cmdcancel);
	DDX_Check(pDX, IDC_CHKCASE, m_chkcasevalue);
	DDX_Check(pDX, IDC_CHKWORD, m_chkwordvalue);
	DDX_CBString(pDX, IDC_CMB1, m_cmb1string);
	DDX_CBString(pDX, IDC_CMB2, m_cmb2string);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReplace, CDialog)
	//{{AFX_MSG_MAP(CReplace)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_FINDNEXT, OnFindnext)
	ON_BN_CLICKED(IDC_CHKWORD, OnChkword)
	ON_BN_CLICKED(IDC_CHKCASE, OnChkcase)
	ON_BN_CLICKED(IDC_REPLACE, OnReplace)
	ON_BN_CLICKED(IDC_REPLACEALL, OnReplaceall)
	ON_BN_CLICKED(IDC_RADIOSEL, OnRadiosel)
	ON_BN_CLICKED(IDC_RADIOWHOLE, OnRadiowhole)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CReplace::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CWinApp *app = AfxGetApp();

	CRect rect,rect1;
	GetWindowRect(&rect);
	m_cmdcancel.GetWindowRect(&rect1);
	int height=rect1.bottom - rect.top +45;
	int width=rect.Width(); 
	rect.left = app->GetProfileInt(_T("CReplace"), _T("left"), 114);
	rect.top = app->GetProfileInt(_T("CReplace"), _T("top"), 91);
	rect.right = rect.left + width;
	rect.bottom = rect.top + height;
	MoveWindow(&rect);	
	
	m_cmb1.SetMRURegKey ( _T("Replace_cmb1 MRU") );
	m_cmb1.SetMRUValueFormat ( _T("File #%d") );
    m_cmb1.SetAutoRefreshAfterAdd ( TRUE );
    m_cmb1.SetAutoSaveAfterAdd ( TRUE );
    m_cmb1.LoadMRU();
    m_cmb1.RefreshCtrl();

	m_cmb2.SetMRURegKey ( _T("Replace_cmb2 MRU") );
	m_cmb2.SetMRUValueFormat ( _T("File #%d") );
    m_cmb2.SetAutoRefreshAfterAdd ( TRUE );
    m_cmb2.SetAutoSaveAfterAdd ( TRUE );
    m_cmb2.LoadMRU();
    m_cmb2.RefreshCtrl();

	m_cmdnext.SetIcon(IDI_FIND);
	m_cmdcancel.SetIcon(IDI_CANCEL);
	m_cmdreplace.SetIcon(IDI_REPLACE);
	m_cmdreplaceall.SetIcon(IDI_REPLACEALL);
	
	m_chkwordvalue=app->GetProfileInt(_T("CReplace"), _T("word"), 0);
	m_chkcasevalue=app->GetProfileInt(_T("CReplace"), _T("case"), 0);
	m_cmb1string=app->GetProfileString(_T("CReplace"), _T("cmb1string"), _T(""));
	m_cmb2string=app->GetProfileString(_T("CReplace"), _T("cmb2string"), _T(""));

	CMainFrame *mainfrm=(CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl &edit=icrEditView->GetRichEditCtrl(); 

	UpdateData(FALSE);

	int nsel = app->GetProfileInt(_T("CReplace"), _T("Selection"), 0);
	if(nsel==1)
		CheckDlgButton (IDC_RADIOSEL, BST_CHECKED);
	else
		CheckDlgButton (IDC_RADIOWHOLE, BST_CHECKED);

	SetTimer(1, 250, NULL);
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CReplace::OnDestroy() 
{
	KillTimer(1);
	CWinApp *app = AfxGetApp();
	CRect rect;
	GetWindowRect(&rect);
	app->WriteProfileInt(_T("CReplace"), _T("left"), rect.left);  
	app->WriteProfileInt(_T("CReplace"), _T("top"), rect.top);
	app->WriteProfileInt(_T("CReplace"), _T("right"), rect.right);
	app->WriteProfileInt(_T("CReplace"), _T("bottom"), rect.bottom);

	CDialog::OnDestroy();	
}

void CReplace::OnCancel() 
{
	UpdateData(TRUE);

	CWinApp *app = AfxGetApp();
	app->WriteProfileString(_T("CReplace"), _T("cmb1string"), m_cmb1string);  
	app->WriteProfileString(_T("CReplace"), _T("cmb2string"), m_cmb2string);  

	CDialog::OnCancel(); 	
}

void CReplace::OnFindnext() 
{
	BOOL binsel = IsDlgButtonChecked(IDC_RADIOSEL)==BST_CHECKED;
	if(binsel)
		return;
	
	UpdateData(TRUE);
	
	if(m_cmb1string.IsEmpty())
		return;
	m_cmb1.AddToMRU(m_cmb1string);
	if(!m_cmb2string.IsEmpty()) 
		m_cmb2.AddToMRU(m_cmb2string);
	
	CMainFrame *mainfrm =(CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	
	int dwFlags = 0;
	if(m_chkcasevalue)
		dwFlags|=FR_MATCHCASE;
	if(m_chkwordvalue)
		dwFlags|=FR_WHOLEWORD;
	dwFlags |= FR_DOWN;
	
	CHARRANGE cr;
	edit.GetSel(cr); 
	FINDTEXTEX *ft = new FINDTEXTEX[1];
	ft->chrg.cpMin = cr.cpMin+1; 
	ft->chrg.cpMax = -1;// search through end of the text 
	
	TCHAR *t = new TCHAR[m_cmb1string.GetLength()+1];
	strcpy(t, m_cmb1string);
	ft->lpstrText = t;
	
	int nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
	
	if(nPos!=-1) {
		edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
		icrEditView->AdjustDialogPosition((CDialog *)this);
		icrEditView->ShowWindow(SW_HIDE); 
		icrEditView->SetFocus(); 
		icrEditView->ShowWindow(SW_SHOW);
		SetFocus();
	}
	else {
		CString strShow;
		strShow.Format(_T("Cannot find the string: \"%s\", search again from the beginning?"), m_cmb1string);
		icrEditView->ShowWindow(SW_SHOW);
		if(MessageBox(strShow, _T(""), MB_ICONINFORMATION|MB_YESNO)==IDYES)
		{
			icrEditView->GetRichEditCtrl().SetSel(0, 0); 
			OnFindnext();
			return;
		}
	}
}

void CReplace::OnChkword() 
{
	UpdateData(TRUE);
	CWinApp *app = AfxGetApp();
	app->WriteProfileInt(_T("CReplace"), _T("word"), m_chkwordvalue);  	
}

void CReplace::OnChkcase()
{
	UpdateData(TRUE);
	CWinApp *app = AfxGetApp();
	app->WriteProfileInt(_T("CReplace"), _T("case"), m_chkcasevalue);  	
}

void CReplace::OnReplace() 
{
	UpdateData(TRUE);
	m_cmb1.AddToMRU(m_cmb1string);
	if(!m_cmb2string.IsEmpty()) 
		m_cmb2.AddToMRU(m_cmb2string);

	CMainFrame *mainfrm =(CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl& editctrl = icrEditView->GetRichEditCtrl();
	CString str=editctrl.GetSelText();
	if(str.IsEmpty())
		return;
	editctrl.ReplaceSel(m_cmb2string,TRUE); 
	icrEditView->ShowWindow(SW_HIDE); 
	icrEditView->SetFocus(); 
	icrEditView->ShowWindow(SW_SHOW);
	OnFindnext();
	icrEditView->AdjustDialogPosition((CDialog *)this);
}

void CReplace::OnReplaceall() 
{
	CMainFrame *mainfrm =(CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl& edit = icrEditView->GetRichEditCtrl();
	
	UpdateData(TRUE);
	if(m_cmb1string.IsEmpty())
		return;
	m_cmb1.AddToMRU(m_cmb1string);
	if(!m_cmb2string.IsEmpty()) 
		m_cmb2.AddToMRU(m_cmb2string);
	
	int dwFlags = 0;
	if(m_chkcasevalue)
		dwFlags|=FR_MATCHCASE;
	if(m_chkwordvalue)
		dwFlags|=FR_WHOLEWORD;
	dwFlags |= FR_DOWN;
	
	CHARRANGE cr;
	edit.GetSel(cr); 
	FINDTEXTEX *ft = new FINDTEXTEX[1];
	
	TCHAR *t = new TCHAR[m_cmb1string.GetLength()+1];
	strcpy(t, m_cmb1string);
	ft->lpstrText = t;
	
	int nPos;
	icrEditView->ShowWindow(SW_HIDE); 
	BOOL binsel = IsDlgButtonChecked(IDC_RADIOSEL)==BST_CHECKED;
	if(binsel) {
		long s,e;
		edit.GetSel(s,e); 
		ft->chrg.cpMin = s+1; 
		ft->chrg.cpMax = -1;// search through end of the text 
		
		nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
		while(nPos!=-1 && ft->chrgText.cpMax<e) {
			edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
			edit.ReplaceSel(m_cmb2string,TRUE); 
			e += m_cmb2string.GetLength() - m_cmb1string.GetLength();
			ft->chrg.cpMin = ft->chrgText.cpMin+m_cmb1string.GetLength(); 
			ft->chrg.cpMax = -1;// search through end of the text 
			nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
		}
	}
	else {		
		ft->chrg.cpMin = 0; 
		ft->chrg.cpMax = -1;// search through end of the text 
		nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
		while(nPos!=-1) {
			edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
			edit.ReplaceSel(m_cmb2string,TRUE); 
			ft->chrg.cpMin = ft->chrgText.cpMin+m_cmb2string.GetLength(); 
			ft->chrg.cpMax = -1;// search through end of the text 
			nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
		}
	}
	icrEditView->AdjustDialogPosition((CDialog *)this);
	icrEditView->SetFocus(); 
	icrEditView->ShowWindow(SW_SHOW);
	SetFocus(); 
}


BOOL CReplace::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message ==  WM_KEYDOWN && (int)pMsg->wParam==VK_RETURN) {
		if(pMsg->hwnd != m_cmdcancel.m_hWnd) 
			OnFindnext();
		else
			::PostMessage(pMsg->hwnd, BM_CLICK, 0, 0xa00a); 

		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);		
}


BOOL CReplace::IsVisible()
{
	if(!IsOpen())
		return FALSE;
	WINDOWPLACEMENT winS;
	GetWindowPlacement(&winS);
	if(winS.showCmd == SW_SHOW)
		return TRUE;
	else
		return FALSE;
}

BOOL CReplace::IsOpen()
{
	return(m_hWnd?TRUE:FALSE);
}


void CReplace::OnRadiosel() 
{
	BOOL bcheck = IsDlgButtonChecked(IDC_RADIOSEL)==BST_CHECKED;

	CWinApp *app = AfxGetApp();
	if(bcheck)
		app->WriteProfileInt(_T("CReplace"), _T("Selection"), 1);
	else
		app->WriteProfileInt(_T("CReplace"), _T("Selection"), 0);
}

void CReplace::OnRadiowhole() 
{
	BOOL bcheck = IsDlgButtonChecked(IDC_RADIOWHOLE)==BST_CHECKED;

	CWinApp *app = AfxGetApp();
	if(bcheck)
		app->WriteProfileInt(_T("CReplace"), _T("Selection"), 0);
	else
		app->WriteProfileInt(_T("CReplace"), _T("Selection"), 1);
}


void CReplace::OnTimer(UINT nIDEvent) 
{
	if(IsDlgButtonChecked(IDC_RADIOWHOLE)==BST_CHECKED) {
		m_cmdreplace.EnableWindow(TRUE); 
		m_cmdnext.EnableWindow(TRUE);
	}
	else {
		m_cmdreplace.EnableWindow(FALSE); 
		m_cmdnext.EnableWindow(FALSE);
	}

	CMainFrame *mainfrm =(CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl& edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr);
	CWnd *pwnd = GetDlgItem(IDC_RADIOSEL);
	if(cr.cpMin == cr.cpMax) {
		::EnableWindow(pwnd->m_hWnd, FALSE); 
		CheckDlgButton (IDC_RADIOWHOLE, BST_CHECKED);
		CheckDlgButton (IDC_RADIOSEL, BST_UNCHECKED);
	}
	else
		::EnableWindow(pwnd->m_hWnd, TRUE); 

	CDialog::OnTimer(nIDEvent);
}

