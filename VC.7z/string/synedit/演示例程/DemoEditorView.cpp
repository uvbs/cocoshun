// DemoEditorView.cpp : implementation of the CDemoEditorView class
//

#include "stdafx.h"
#include "DemoEditor.h"

#include "DemoEditorDoc.h"
#include "CntrItem.h"
#include "DemoEditorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorView

IMPLEMENT_DYNCREATE(CDemoEditorView, CSynEditView)

BEGIN_MESSAGE_MAP(CDemoEditorView, CSynEditView)
	//{{AFX_MSG_MAP(CDemoEditorView)
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CSynEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CSynEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CSynEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorView construction/destruction

CDemoEditorView::CDemoEditorView()
{
	// TODO: add construction code here

}

CDemoEditorView::~CDemoEditorView()
{
}



BOOL CDemoEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CSynEditView::PreCreateWindow(cs);
}

void CDemoEditorView::OnInitialUpdate()
{
	CSynEditView::OnInitialUpdate();

	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorView printing

BOOL CDemoEditorView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


/////////////////////////////////////////////////////////////////////////////
// CDemoEditorView diagnostics

#ifdef _DEBUG
void CDemoEditorView::AssertValid() const
{
	CSynEditView::AssertValid();
}

void CDemoEditorView::Dump(CDumpContext& dc) const
{
	CSynEditView::Dump(dc);
}

CDemoEditorDoc* CDemoEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDemoEditorDoc)));
	return (CDemoEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorView message handlers

void CDemoEditorView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_DEMOEDTYPE));
	
	CMenu* pPopup = menu.GetSubMenu(1);
	ASSERT(pPopup != NULL);
	CWnd* pWndPopupOwner = this;
	
	while (pWndPopupOwner->GetStyle() & WS_CHILD)
		pWndPopupOwner = pWndPopupOwner->GetParent();
	
	ClientToScreen(&point);
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
		pWndPopupOwner);
}
