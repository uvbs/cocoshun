// STDAFX.H for CStr test application

#include <windows.h>
