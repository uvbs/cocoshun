/////////////////////////////////////////////////////////////////////////////
//
// MRUCombo.h: Header file for the CMRUComboBox class.
//
// Written by Michael Dunn <mdunn at inreach dot com>
//
/////////////////////////////////////////////////////////////////////////////
//
// Revision history:
//
//  9/9/1998: First release.
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MRUCOMBO_H__BDE24F13_4632_11D2_9505_D07F50C10000__INCLUDED_)
#define AFX_MRUCOMBO_H__BDE24F13_4632_11D2_9505_D07F50C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MRUCombo.h : header file
//

#include "afxpriv.h"                    // for CRecentFileList
#define FC_DRAWNORMAL	0x00000001
#define FC_DRAWRAISED	0x00000002
#define FC_DRAWPRESSD	0x00000004

/////////////////////////////////////////////////////////////////////////////
// CMRUComboBox window

class CMRUComboBox : public CComboBox
{
// Construction
public:
	CMRUComboBox();

// Attributes & accessor functions
public:
    void           SetMRURegKey ( LPCTSTR szRegKey );
    const CString& GetMRURegKey() const;

    BOOL           SetMRUValueFormat ( LPCTSTR szValueFormat );
    const CString& GetMRUValueFormat() const;

    int            SetMaxMRUSize ( int nMaxSize );
    int            GetMaxMRUSize() const;

    BOOL SetAutoSaveOnDestroy   ( BOOL bAutoSave );
    BOOL SetAutoSaveAfterAdd    ( BOOL bAutoSave );
    BOOL SetAutoRefreshAfterAdd ( BOOL bAutoRefresh );

protected:
    CRecentFileList*    m_pMRU;
    CString             m_cstrRegKey;
    CString             m_cstrRegValueFormat;
    int                 m_nMaxMRUSize;
    BOOL                m_bSaveOnDestroy;
    BOOL                m_bSaveAfterAdd;
    BOOL                m_bRefreshAfterAdd;

	BOOL		m_bLBtnDown;
	COLORREF	m_clrHilite;
	COLORREF	m_clrShadow;
	COLORREF	m_clrButton;

// Operations
public:
    BOOL AddToMRU ( LPCTSTR szNewItem );
    void EmptyMRU();

    void RefreshCtrl();

    BOOL LoadMRU();
    BOOL SaveMRU();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMRUComboBox)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:
	void ShowAutoWidth(BOOL bShowAutoWidth);
	virtual ~CMRUComboBox();

protected:
    BOOL AllocNewMRU();
    BOOL VerifyMRUParams() const;

    BOOL m_bParamsChanged;

	// Generated message map functions
protected:
	void DrawCombo(DWORD dwStyle, COLORREF clrTopLeft, COLORREF clrBottomRight);
	//{{AFX_MSG(CMRUComboBox)
	afx_msg void OnDropdown();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bShowAutoWidth;
	int Offset();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MRUCOMBO_H__BDE24F13_4632_11D2_9505_D07F50C10000__INCLUDED_)

