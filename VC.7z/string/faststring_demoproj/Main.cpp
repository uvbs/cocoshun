
#include "stdafx.h"

// Uncomment the following line to get increased speed
//   with single-threaded apps (or if you use CStr objects
//   in only one thread)
//#define CSTR_NOT_MT_SAFE

#include "cstr.h"
#include "stdio.h"
#include <time.h>
#include <malloc.h>

#include "CStrMgr.cpp"

// We must implement this because we're not using MFC in this project.
//   By returning NULL we use the resources of the current application
//   (note: works in EXEs only; for DLLs, you must return a true
//   instance handle!)
HANDLE get_stringres()
{
	return NULL;
}


//
// Utility class to measure memory requirements
class CMemStat
{
public:
	CMemStat()		{ TakeSnapshot(); }
protected:
	MEMORYSTATUS m_Status;
public:
	void TakeSnapshot();
	void Report();
	CStr ToKB(int val);
};

void CMemStat::TakeSnapshot()
{
	m_Status.dwLength = sizeof(m_Status);
	GlobalMemoryStatus (&m_Status);
}

CStr CMemStat::ToKB(int val)
{
	CStr result (16);
	if (abs(val) < 65536)
		result.AddInt (val);
	else if (abs(val) < (1024*1024)) {
		val = (int) (val / 1024);
		result.AddInt (val);
		result.AddChar ('K');
	}
	else {
		val = (int) (val / 1024);
		double r = val / 1024;
		result.AddDouble (double(val) / 1024, 2);
		result.AddChar ('M');
	}
	return result;
}

void CMemStat::Report()
{
	// Get current situation
	MEMORYSTATUS cur;
	cur.dwLength = sizeof(cur);
	GlobalMemoryStatus(&cur);
	// Report differences
	printf (">>Memory: %% load %d (increase %d)\n",
		(int) cur.dwMemoryLoad, (int) cur.dwMemoryLoad-m_Status.dwMemoryLoad);
	if (m_Status.dwAvailPhys >= cur.dwAvailPhys) {
		printf ("          avail phys %s (decrease %s)\n",
			(LPCSTR) ToKB(cur.dwAvailPhys), (LPCSTR) ToKB(m_Status.dwAvailPhys - cur.dwAvailPhys));
	}
	else {
		printf ("          avail phys %s (increase %s)\n",
			(LPCSTR) ToKB(cur.dwAvailPhys), (LPCSTR) ToKB(cur.dwAvailPhys - m_Status.dwAvailPhys));
	}
	// Provide new reference point
	m_Status = cur;
}

DWORD CheckTime(DWORD count, CStr* keep)
{
	DWORD time0 = GetTickCount();
	CStr st_fixed (80);
	for (UINT i=0; i<count; i++) {
		CStr* st = &st_fixed;
		st->Format ("./%u\\.", 511);
		*st += "Coconut";
		for (int j=0; j<10; j++) {
			char k = char ('0' + j);
			st->AddChar ((char) j);
		}
		keep[i] = *st;
	}
	return GetTickCount() - time0;
}

CStr ReturnSomething (const CStr& in)
{
	CStr k ("-->");
	k += in;
	k += "<--";
	return k;
}

int main(int /*argc*/, char* /*argv[]*/, char* /*envp[]*/)
{
	srand(time(NULL));
	Sleep(300);

	CStr hoohoo;
	hoohoo.LoadString (100);
	printf ("<<%s>>\n", (const char*) hoohoo);

	/*
	CStr empty ("Try this");
	printf ("Hello1 [%s]\n", (const char*) empty);
	empty = "Test that!";
	printf ("Hello2 [%s]\n", (const char*) empty);
	CStr a_copy (empty);
	empty += " here it is...";
	printf ("Hello3 [%s]\n", (const char*) empty);
	empty.AddStringAtLeft ("Prep-->");
	printf ("Hello4 [%s]\n", (const char*) empty);

	empty.RemoveLeft (0);
	printf ("Hello5 [%s]\n", (const char*) empty);
	empty.RemoveLeft (2);
	printf ("Hello6 [%s]\n", (const char*) empty);
	empty.RemoveLeft (20);
	printf ("Hello7 [%s]\n", (const char*) empty);

	CStr tryout ("oo");
	CStr a = ReturnSomething (tryout);
	printf ("tryout was %s, now a is %s\n", (LPCSTR) tryout, (LPCSTR) a);
	*/

	const DWORD count = 10000;
	CStr* keep = new CStr[count];
	CMemStat ms;
	printf ("Allocating memory...\n");
	int result = CheckTime(count, keep);
	printf ("Time for %d: %d ms\n", (int) count, result);
	ms.Report();

	printf ("Releasing memory...\n");
	delete [] keep;

	keep = new CStr[count];
	printf ("\nAllocating memory again (should be faster)...\n");
	result = CheckTime(count, keep);
	printf ("Time for %d: %d ms\n", (int) count, result);
	ms.Report();
	printf ("Releasing memory...\n");
	delete [] keep;

	CStr::CompactFree();
	_heapmin();
	ms.Report();

	return 0;
}


