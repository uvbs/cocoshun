#if !defined(AFX_FIND_H__83A5C81C_05BE_40EC_9EB4_E2CFC267B148__INCLUDED_)
#define AFX_FIND_H__83A5C81C_05BE_40EC_9EB4_E2CFC267B148__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Find.h : header file
//

#include "MRUCombo.h"
#include "BtnST.h"
#include "FlatCheckBox.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CFind dialog

class CFind : public CDialog
{
// Construction
public:
	BOOL IsVisible();
	BOOL IsOpen();
	CFind(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFind)
	enum { IDD = IDD_FIND };
	CButtonST m_cmdReturn;
	CButtonST m_cmdFind;
	CMRUComboBox m_cmbstring;
	CFlatCheckBox	m_chkword;
	CFlatCheckBox	m_chkcase;
	BOOL m_bCase;
	BOOL m_bWholeWord;
	CString	m_strEdit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFind)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFind)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnReturn();
	afx_msg void OnFind();
	afx_msg void OnChkword();
	afx_msg void OnChkcase();
	afx_msg void OnRadiodown();
	afx_msg void OnRadioup();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIND_H__83A5C81C_05BE_40EC_9EB4_E2CFC267B148__INCLUDED_)

