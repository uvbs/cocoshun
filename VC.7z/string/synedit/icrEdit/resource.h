//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by icrEdit.rc
//
#define IDD_ABOUTBOX                    100
#define IDI_OK                          125
#define IDR_MAINFRAME                   128
#define IDR_ICREDITYPE                  129
#define IDD_FIND                        130
#define IDI_FIND                        131
#define IDI_CANCEL                      132
#define IDI_REPLACE                     133
#define IDI_REPLACEALL                  134
#define IDD_REPLACE                     137
#define IDD_DIALOGDATATIME              288
#define IDC_RETURN                      1025
#define IDC_CMBSTRING                   1030
#define IDC_CHKWORD                     1032
#define IDC_CHKCASE                     1033
#define IDC_STATIC1                     1035
#define IDC_CMB1                        1037
#define IDC_CMB2                        1038
#define IDC_FINDNEXT                    1040
#define IDC_FIND                        1040
#define IDC_REPLACE                     1041
#define IDC_REPLACEALL                  1043
#define IDC_CANCEL                      1044
#define IDC_STATICS                     1146
#define IDC_RADIOUP                     1292
#define IDC_RADIODOWN                   1293
#define IDC_RADIOSEL                    1295
#define IDC_RADIOWHOLE                  1296
#define IDC_DATEDIALOG_LIST             1347
#define IDC_STATIC_HEADING              1348
#define ID_EDITUNDO                     32771
#define ID_EDITREDO                     32772
#define ID_EDIT_MOVERIGHT               32773
#define ID_EDIT_MOVELEFT                32774
#define ID_EDITFIND                     32775
#define ID_EDITREPEAT                   32776
#define ID_EDITREPEATNEXT               32777
#define ID_EDIT_SEARCH                  32778
#define ID_EDIT_COMMENT                 32779
#define ID_EDIT_UNCOMMENT               32780
#define ID_EDITCUT                      32781
#define ID_EDITCOPY                     32782
#define ID_EDITSELECTALL                32784
#define ID_EDITREPLACE                  32785
#define ID_VIEW_FONT                    32786
#define ID_TOOLBAR_EMPTY                32787
#define ID_FILE_SAVE_AS_                32788
#define ID_FILESAVE                     32789
#define ID_EDITPASTE                    40015
#define ID_EDIT_SELECTALL               40017
#define IDC_COMBOXFIND                  40055
#define IDC_COMBOX                      40055
#define ID_EDITGOTOLINE                 40056
#define ID_EDIT_UCASE                   40057
#define ID_EDIT_LCASE                   40058
#define ID_EDIT_INSERTDATETIME          40060
#define ID_EDIT_INSERTFILE              40061
#define ID_EDIT_INVERT                  40074
#define ID_EDIT_CAPITALIZE              40075
#define ID_EDIT_TABTOSPACE              40081
#define ID_EDIT_SPACETOTAB              40082
#define ID_EDIT_LEADINGSPACETOTAB       40083
#define ID_EDIT_TRIMTRAILLINGSPACE      40084
#define ID_EDIT_TRIMTRAILLINGTAB        40086
#define ID_EDIT_SENTANCECASE            40093
#define IDS_TITLE                       61446

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
