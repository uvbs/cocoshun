﻿/**
 * 2007-11-12
 */
package com.firefly.mvc.support;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.butterfly.engine.support.RDSPageUtil;
import com.firefly.core.Application;
import com.firefly.mvc.ActionContext;
import com.firefly.mvc.AttributeNames;
import com.firefly.mvc.ResultModes;
import com.firefly.mvc.web.UploadFile;
import com.firefly.util.NullSafeUtils;
import com.firefly.util.StringUtils;
import com.firefly.util.tree.TreeUtils;

/**
 * <p>
 * 控制器内部使用的工具类。
 * </p>
 * 
 * @author <A href="mailto:zhuhb9277@gmail.com">朱海斌</A>
 * 
 */
public abstract class MVCUtils {

    /**
     * <p>
     * 获得要输出的调试信息。
     * </p>
     * 
     * @param name
     *            属性名称。
     * @param source
     *            属性对象实例。
     * @return String 调试信息字符串。
     */
    public static String debugInfo(String name, String source) {
        return name + " = \"" + NullSafeUtils.nullSafeString(source, "(null)") + "\"";
    }

    /**
     * <p>
     * 获得要输出的调试信息。
     * </p>
     * 
     * @param name
     *            属性名称。
     * @param source
     *            属性对象实例。
     * @return String 调试信息字符串。
     */
    @SuppressWarnings("unchecked")
    public static String debugInfo(String name, Collection source) {
        return name + " = {" + StringUtils.collectionToDelimitedString(source, ",") + "}";
    }

    /**
     * <p>
     * 为一个没有后缀的请求Urn添加Action类型的后缀。
     * </p>
     * 
     * @param actionUrn
     *            请求Urn。
     * @return 添加了Action后缀的请求Urn。
     */
    public static String addActivityExtension(String actionUrn) {
        return (actionUrn.indexOf(".") == -1 && Application.app.getActionExtensions() != null) ? actionUrn + "."
                + (Application.app.getActionExtensions().toArray())[0].toString() : actionUrn;
    }

    /**
     * <p>
     * 将ActionContext转换为XML或JSON格式的输出数据。
     * </p>
     * 
     * @param actionContext
     *            ActionContext实例。
     * @param resultMode
     *            返回格式。
     * @return String XML或JSON文本。
     */
    @SuppressWarnings( { "unchecked" })
    public static String toXMLorJSON(ActionContext actionContext, ResultModes resultMode) {

        Object object = null;
        String resultObjectNames = actionContext.getString(AttributeNames.resultObjectNames.name());
        if (StringUtils.hasText(resultObjectNames)) {
            String[] objectNames = resultObjectNames.split(",");
            if (objectNames.length == 1) {
                object = actionContext.get(objectNames[0]);
            }
            else {
                Map map = new HashMap();
                for (String objectName : objectNames) {
                    objectName = objectName.trim();
                    map.put(objectName, actionContext.get(objectName));
                }
                object = map;
            }
        } else {
            Map map = actionContext.toMap();
            String dateFormatPattern = actionContext.getString(AttributeNames.dateFormatPattern.name());
            if (StringUtils.hasText(dateFormatPattern)) {
                Application.setDateFormat(dateFormatPattern);
            }

            if (resultMode.equals(ResultModes.xml) || resultMode.equals(ResultModes.json)
            		|| resultMode.equals(ResultModes.json_pagination)) {
                for (AttributeNames an : AttributeNames.values()) {
                    map.remove(an.name());
                }
                //去除上传文件参数。
                List<Object> fileParamNames = new ArrayList<Object>();
                for (Object key : map.keySet()) {
                    Object value = map.get(key);
                    if (value != null && value.getClass() == UploadFile.class) {
                        fileParamNames.add(key);
                    }
                }
                for (Object fileParamName : fileParamNames) {
                    map.remove(fileParamName);
                }
            } else {
                HttpServletRequest request = actionContext.getRequest();
                Map<String, String> requestAttributeMap = new HashMap<String, String>();
                requestAttributeMap.put("userIP", request.getRemoteAddr());
                requestAttributeMap.put("requestMethod", request.getMethod());
                requestAttributeMap.put("serverName", request.getServerName());
                requestAttributeMap.put("serverPort", String.valueOf(request.getServerPort()));
                try {
                    requestAttributeMap.put("serverIP", InetAddress.getLocalHost().getHostAddress());
                } catch (UnknownHostException uhe) {
                    uhe.printStackTrace();
                }
                map.put("request", requestAttributeMap);
                map.remove(AttributeNames.application.name());
                map.remove(AttributeNames.servletContext.name());
            }

            // 加入ResultCode
            map.put(AttributeNames.resultCode.name(), actionContext.getString(AttributeNames.resultCode.name()));

            // 加入错误信息
            if (actionContext.getErrors().hasErrors()) {
                map.put("errors", actionContext.getErrors().toMap());
            }
            object = map;
        }
        
        if(resultMode.equals(ResultModes.json_pagination))
        {
        	// 对QDS进行分页
        	RDSPageUtil.ProcessPagination(actionContext, object);
        }

        return (resultMode.equals(ResultModes.xml) || resultMode.equals(ResultModes.xml_all)) ? TreeUtils
                .Object2XML(object) : TreeUtils.Object2JSON(object);
    }

    public static Map<String, Object> getResultObjects(ActionContext actionContext) {
        Map<String, Object> map = new HashMap<String, Object>();
        String resultObjectNames = actionContext.getString(AttributeNames.resultObjectNames.name());
        if (StringUtils.hasText(resultObjectNames)) {
            String[] objectNames = resultObjectNames.split(",");
            if (objectNames.length == 1) {
                map.put(objectNames[0], actionContext.get(objectNames[0]));
            } else {
                for (String objectName : objectNames) {
                    objectName = objectName.trim();
                    map.put(objectName, actionContext.get(objectName));
                }
            }
        } else {
            map.putAll(actionContext.toMap());
            map.put(AttributeNames.actionContext.name(), actionContext);
        }
        return map;
    }

}
