// ConnPtr_Open_ExeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ConnPtr_Open_Exe.h"
#include "ConnPtr_Open_ExeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnPtr_Open_ExeDlg dialog

CConnPtr_Open_ExeDlg::CConnPtr_Open_ExeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConnPtr_Open_ExeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnPtr_Open_ExeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CConnPtr_Open_ExeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnPtr_Open_ExeDlg)
	DDX_Control(pDX, IDC_LIST1, m_list1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CConnPtr_Open_ExeDlg, CDialog)
	//{{AFX_MSG_MAP(CConnPtr_Open_ExeDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_INSERT_INTO, OnBtnInsertInto)
	ON_BN_CLICKED(IDC_BTN_UPDATE, OnBtnUpdate)
	ON_BN_CLICKED(IDC_BTN_SELECT, OnBtnSelect)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConnPtr_Open_ExeDlg message handlers

BOOL CConnPtr_Open_ExeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CConnPtr_Open_ExeDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CConnPtr_Open_ExeDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CConnPtr_Open_ExeDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CConnPtr_Open_ExeDlg::OnBtnInsertInto() 
{
	_ConnectionPtr m_pConnection;
	_variant_t RecordsAffected;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}
	try
	{
		_bstr_t strCmd="INSERT INTO Employees(EmployeeID,FirstName,LastName,HireDate,City,Country) VALUES(10,'Mary','Williams','15/4/1993 12:00:00','New York','USA')";
		m_pConnection->Execute(strCmd,&RecordsAffected,adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}
	if(m_pConnection->State)
		m_pConnection->Close();
}

void CConnPtr_Open_ExeDlg::OnBtnUpdate() 
{
	_ConnectionPtr m_pConnection;
	_variant_t RecordsAffected;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}
	try
	{
		_bstr_t strCmd="UPDATE Employees SET FirstName='Bill',LastName='Clinton',HireDate='25/11/1994 12:00:00',City='Los Angeles' WHERE EmployeeID=10";
		m_pConnection->Execute(strCmd,&RecordsAffected,adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}
	if(m_pConnection->State)
		m_pConnection->Close();	
}

void CConnPtr_Open_ExeDlg::OnBtnSelect() 
{
	_ConnectionPtr m_pConnection;
	_variant_t RecordsAffected;
	_RecordsetPtr m_pRecordset;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}
	try
	{
		m_pRecordset.CreateInstance("ADODB.Recordset"); //ΪRecordset���󴴽�ʵ��
		_bstr_t strCmd="SELECT EmployeeID,FirstName,LastName,HireDate,City FROM Employees WHERE City='London'";
		m_pRecordset=m_pConnection->Execute(strCmd,&RecordsAffected,adCmdText);

	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	_variant_t vEmployeeID,vFirstName,vLastName,vHireDate,vCity;

	try
	{
		while(!m_pRecordset->adoEOF)
		{
			vEmployeeID=m_pRecordset->GetCollect(_variant_t((long)0));
		    //ȡ�õ�1�е�ֵ����0��ʼ��������Ҳ����ֱ���г��е����ƣ�����һ��

			vFirstName=m_pRecordset->GetCollect("FirstName");
			vLastName=m_pRecordset->GetCollect("LastName");
			vHireDate=m_pRecordset->GetCollect("HireDate");
			vCity=m_pRecordset->GetCollect("City");

			CString strtemp;
			if(vEmployeeID.vt!=VT_NULL)
			{
				strtemp.Format("%d",vEmployeeID.lVal);
			}

			if(vFirstName.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vFirstName;
			}

			if(vLastName.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vLastName;
			}

			if(vHireDate.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vHireDate;
			}

			if(vCity.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vCity;
			}

			m_list1.AddString(strtemp);
			
			m_list1.AddString("\n");

			m_pRecordset->MoveNext();
		}
		
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}


	m_pRecordset->Close();
	m_pRecordset=NULL;
	m_pConnection->Close();	
	m_pConnection=NULL;
}

