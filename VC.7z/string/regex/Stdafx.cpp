// static char BASED_CODE * RCSId = "$Id: STDAFX.CPP 1.1 1995/10/05 23:36:55 guy Exp $";

/*
 *	$Revision: 1.1 $
 */
// stdafx.cpp : source file that includes just the standard includes
//  stdafx.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
