package com.butterfly.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.butterfly.core.schema.model.rds.HistoryParameter;
import com.butterfly.core.schema.model.rds.HistoryParameterType;
import com.butterfly.core.schema.model.rds.QueryDataSet;
import com.butterfly.core.schema.model.rds.ReportDataSet;
import com.butterfly.engine.ReportContext;
import com.butterfly.engine.ReportEngine;
import com.butterfly.manager.configuration.entity.rdmlog.RdmLog;
import com.butterfly.util.StringUtil;
import com.firefly.core.Activity;
import com.firefly.core.ActivityContext;
import com.firefly.core.exception.ActivityException;
import com.firefly.orm.manager.EntityManager;

/**
 * 
 * @author kezhenxing
 *
 * 前台viewer的action
 * 
 * 查询报表数据和下钻、上卷功能。
 * 
 * 前台传递的参数有rdmName，ddParameter，ruParameter，userID，parameter
 * 
 * 报表的查询参数一定是RDM中QDM里定义的parameter的name(需要注意：每个QDM的parameter的name必须为不重复的！否则会有覆盖的情况)
 * 
 */
public class QueryReportDataAction4Viewer implements Activity {

	private static final Log logger = LogFactory.getLog(QueryReportDataAction4Viewer.class);
	@SuppressWarnings("unchecked")
	public void execute(ActivityContext activityContext)
			throws ActivityException {
		// 记录执行日志对象
		RdmLog rdmLog = new RdmLog();
		//引擎对象
		ReportEngine reportEngine = ReportEngine.getInstance();
		//定义报表执行上下文
		ReportContext reportContext = new ReportContext();
		//获取登录用户信息
		Map<String , Object> userInstance = (Map<String , Object>)activityContext.get("userInstance");
		//获取报表名称
		String rdmName = activityContext.getString("rdmName");
		boolean rotate = activityContext.getBoolean("rotate");
		reportContext.setRotate(rotate);
		// 获得查询参数的定义，需要从RDM定义中取出来
		List<Map<String , String>> queryParams = reportEngine.getQueryParam4Rdm(rdmName);
		for (Map<String , String> param : queryParams) {
			for(Entry<String , String> entry : param.entrySet()){
				String s = activityContext.getString(entry.getKey());
				// 测试时使用，如果参数为null初始值
				if (s == null) {
					if (entry.getKey().equals("TopN")) {
						s = "2";
					} else if(entry.getKey().equals("DateTimeParm")) {
						s = "[Date].[Fiscal].[Fiscal Year].&[2004]";
					} else if(entry.getKey().equals("msceid")){
						s = "6";
					} else if(entry.getKey().equals("EndDateTime")){
						s = "2010-01-02";
					} else if(entry.getKey().equals("StartDateTime")){
						s = "2001-01-01";
					}else if(entry.getKey().equals("cldnum")){
						s = "99999999999";
					}
				}
				reportContext.addQueryParameters(entry.getKey(), s);
				// 记录日志的查询参数
				rdmLog.addParameter(entry.getKey() + "=" + s);
			}
		}
		
		boolean isDrillThrough = activityContext.getBoolean("drillThrough");
		
		if(isDrillThrough){
			query4DrillThrough(activityContext , reportEngine , rdmLog , userInstance , rdmName , reportContext);
		}else{
			queryReportData(activityContext , reportEngine , rdmLog , userInstance , rdmName , reportContext);
		}
	}
	/**
	 * 执行drillThrough的查询
	 * @param activityContext
	 * @param reportEngine
	 * @param rdmLog
	 * @param userInstance
	 * @param rdmName
	 * @param reportContext
	 */
	private void query4DrillThrough(ActivityContext activityContext,
			ReportEngine reportEngine, RdmLog rdmLog,
			Map<String, Object> userInstance, String rdmName,
			ReportContext reportContext) {
		String colName = activityContext.getString("colName");
		String rowName = activityContext.getString("rowName");
		reportContext.setBt_colName(colName);
		reportContext.setBt_rowName(rowName);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("roles", userInstance.get("dbRoles"));
		reportContext.setBt_rdmName(rdmName);
		reportContext.getParameters().putAll(parameters);
		logger.info("开始执行DrillThrough");
		ReportDataSet rds = reportEngine.processDrillThrough(reportContext);
		logger.info("DrillThrough执行完成");
		activityContext.put("reportDataSet", rds);
	}
	/**
	 * 执行报表数据查询
	 * @param activityContext
	 * @param reportEngine
	 * @param rdmLog
	 * @param userInstance
	 * @param rdmName
	 * @param reportContext
	 */
	private static void queryReportData(ActivityContext activityContext , ReportEngine reportEngine , RdmLog rdmLog , Map<String , Object> userInstance , String rdmName , ReportContext reportContext){
		//钻取、上卷参数
		String ddParameter = activityContext.getString("ddParameter");
		String ruParameter = activityContext.getString("ruParameter");
		
		// 历史参数
		String parameter = activityContext.getString(StringUtil.PARAMETER);

		Set<String> ddParameters = new HashSet<String>();
		Set<String> ruParameters = new HashSet<String>();
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		
		parameters.put("roles", userInstance.get("dbRoles"));
		
		rdmLog.setRdmID(rdmName);
		
		if (ddParameter != null) {
			ddParameters.add(ddParameter);
		}

		if (ruParameter != null) {
			ruParameters.add(ruParameter);
		}
		
		rdmLog.setExecutor(userInstance.get("loginId").toString());
		//设置报表上下文的参数
		reportContext.setBt_rdmName(rdmName);
		reportContext.setBt_drillDown(ddParameters);
		reportContext.setBt_rollUp(ruParameters);
		reportContext.setHistoryParameter(parameter);
		reportContext.getParameters().putAll(parameters);
		// 记录日志，引擎执行的开始时间
		rdmLog.setStartTime(new Date());

		
		ReportDataSet rds = null;
		//行头数和列头数
		int rowCount = 0, colCount = 0;
		try {
			rds = reportEngine.process4viewer(reportContext);
			rdmLog.setStatus(0);
			// 记录日志，引擎执行的结束时间
			rdmLog.setEndTime(new Date());

			if (rds == null) {
				activityContext.put("message", "没有找到名称为\"" + rdmName + "\"的报表模型");
			} else {
				Map<String, QueryDataSet> map = rds.getQueryDataSets();
				
				for (Entry<String, QueryDataSet> entry : map.entrySet()) {
					if(entry.getValue().getRowRoot() == null){
						rowCount = entry.getValue().getBody().getRowSize()+entry.getValue().getColumnRoot().depth()-1;
						colCount = entry.getValue().getBody().getColumnSize();
					}else{
						colCount = entry.getValue().getBody().getColumnSize()+entry.getValue().getRowRoot().depth()-1;
						if(entry.getValue().getColumnRoot() == null){
							rowCount = entry.getValue().getBody().getRowSize();
						}else{
							rowCount = entry.getValue().getBody().getRowSize()+entry.getValue().getColumnRoot().depth()-1;
						}
					}
				}
				//往前台放测试的参数
				activityContext.put("colCount", colCount);
				activityContext.put("rowCount", rowCount);
				activityContext.put("reportDataSet", rds);
				activityContext.put("rdmName", rdmName);
				//从RDS得到历史参数
				List<HistoryParameter> historyParam = rds.getRenderQueryDataSet().getParameters();
				StringBuffer historyStr = new StringBuffer();
				List<HistoryParameter> queryParamList = new ArrayList<HistoryParameter>();
				//获得历史动作的参数
				if(historyParam != null){
					for(HistoryParameter history : historyParam){
						if(history.getType().equals(HistoryParameterType.DDPARAM)){
							//获得历史钻取参数
							historyStr.append(history.getParameterContent());
							historyStr.append(StringUtil.SPECIAL_SYMBOLS_PERCENT);
							historyStr.append(history.getParameterType());
							historyStr.append(StringUtil.SPECIAL_SYMBOLS_ADDR);
						}else{
							//获得历史查询参数
							queryParamList.add(history);
						}
					}
				}
				//向activityContext放入历史钻取参数
				activityContext.put(StringUtil.PARAMETER_HISTORY, historyStr);
				//向activityContext放入历史查询参数
				activityContext.put("queryParam", queryParamList);
				
				// 设置日志信息
				rdmLog.setStatement(rds.getStatements().get("MDX语句"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("报表引擎执行出错："+e.toString());
			activityContext.put("errorMsg", e.toString());
			rdmLog.setStatus(1);
			rdmLog.setStatusDesc(e.toString());
		} finally{
			// 保存日志
			if(rdmLog.getEndTime() == null){
				rdmLog.setEndTime(new Date());
			}
			rdmLog.setRowCount(rowCount);
			rdmLog.setColCount(colCount);
			EntityManager.save(rdmLog);
		}
	}

}
