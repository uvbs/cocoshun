// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "icrEdit.h"

#include "MainFrm.h"
#include "IcrEditView.h"
#include "resource.h"
#include "DateTime.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DWORD CALLBACK EditStreamCallbackWriteToFile(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb);
DWORD CALLBACK EditStreamCallbackOut(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb);

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_CBN_SELCHANGE(IDC_COMBOX, OnSelchangeCombo)
	ON_CBN_SELCHANGE(IDC_COMBOX, OnSelchangeComboFind)
	ON_COMMAND(ID_EDITPASTE, OnEditPaste)
	ON_COMMAND(ID_EDITCUT, OnEditcut)
	ON_UPDATE_COMMAND_UI(ID_EDITCUT, OnUpdateEditcut)
	ON_COMMAND(ID_EDITCOPY, OnEditcopy)
	ON_UPDATE_COMMAND_UI(ID_EDITCOPY, OnUpdateEditcopy)
	ON_UPDATE_COMMAND_UI(ID_EDITPASTE, OnUpdateEditpaste)
	ON_COMMAND(ID_EDITUNDO, OnEditundo)
	ON_UPDATE_COMMAND_UI(ID_EDITUNDO, OnUpdateEditundo)
	ON_COMMAND(ID_EDITREDO, OnEditredo)
	ON_UPDATE_COMMAND_UI(ID_EDITREDO, OnUpdateEditredo)
	ON_COMMAND(ID_EDITSELECTALL, OnEditselectall)
	ON_COMMAND(ID_EDITFIND, OnEditfind)
	ON_COMMAND(ID_EDITREPEAT, OnEditrepeat)
	ON_COMMAND(ID_EDITREPEATNEXT, OnEditrepeatnext)
	ON_UPDATE_COMMAND_UI(ID_EDITREPEAT, OnUpdateEditrepeat)
	ON_UPDATE_COMMAND_UI(ID_EDITREPEATNEXT, OnUpdateEditrepeatnext)
	ON_COMMAND(ID_EDITREPLACE, OnEditreplace)
	ON_COMMAND(ID_VIEW_FONT, OnViewFont)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_EDIT_TRIMTRAILLINGSPACE, OnEditTrimtraillingspace)
	ON_COMMAND(ID_EDIT_TRIMTRAILLINGTAB, OnEditTrimtraillingtab)
	ON_COMMAND(ID_EDIT_TABTOSPACE, OnEditTabtospace)
	ON_COMMAND(ID_EDIT_SPACETOTAB, OnEditSpacetotab)
	ON_COMMAND(ID_EDIT_LEADINGSPACETOTAB, OnEditLeadingspacetotab)
	ON_COMMAND(ID_EDIT_MOVERIGHT, OnEditMoveright)
	ON_COMMAND(ID_EDIT_UNCOMMENT, OnEditUncomment)
	ON_COMMAND(ID_EDIT_MOVELEFT, OnEditMoveleft)
	ON_COMMAND(ID_EDIT_COMMENT, OnEditComment)
	ON_COMMAND(ID_EDIT_LCASE, OnEditLcase)
	ON_COMMAND(ID_EDIT_UCASE, OnEditUcase)
	ON_COMMAND(ID_EDIT_INVERT, OnEditInvert)
	ON_COMMAND(ID_EDIT_CAPITALIZE, OnEditCapitalize)
	ON_COMMAND(ID_EDIT_SENTANCECASE, OnEditSentancecase)
	ON_COMMAND(ID_EDIT_INSERTDATETIME, OnEditInsertdatetime)
	ON_COMMAND(ID_EDIT_INSERTFILE, OnEditInsertfile)
	ON_UPDATE_COMMAND_UI(ID_EDIT_LCASE, OnUpdateEditLcase)
	ON_UPDATE_COMMAND_UI(ID_EDIT_INVERT, OnUpdateEditInvert)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SENTANCECASE, OnUpdateEditSentancecase)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UCASE, OnUpdateEditUcase)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILESAVE, OnFilesave)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CAPITALIZE, OnUpdateEditCapitalize)
	ON_COMMAND(ID_FILE_SAVE_AS_, OnFileSaveAs)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_pFindDialog = NULL;
	m_pReplaceDialog = NULL;

	m_strFileName = "";
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

  // TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_bAutoMenuEnable = FALSE;

	if(-1 == LoadToolbarCombo())
		return FALSE;

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


int CMainFrame::LoadToolbarCombo()
{
    CRect rect;

	m_wndToolBar.SetButtonInfo(17, IDC_COMBOXFIND, TBBS_SEPARATOR, 140 );
    m_wndToolBar.GetItemRect(17, &rect);
    rect.bottom += 200;
	if(!m_wndToolBar.m_comboboxFind.Create(CBS_DROPDOWN|WS_VISIBLE|WS_TABSTOP|CBS_AUTOHSCROLL|WS_VSCROLL,rect, &m_wndToolBar, IDC_COMBOXFIND))
        return -1;

    CFont *f = m_wndToolBar.GetFont();
	m_wndToolBar.m_comboboxFind.ShowAutoWidth(TRUE);
    m_wndToolBar.m_comboboxFind.SetFont(f);

	m_wndToolBar.m_comboboxFind.SetMRURegKey ( _T("cmbFind MRU") );
	m_wndToolBar.m_comboboxFind.SetMRUValueFormat ( _T("File #%d") );
    m_wndToolBar.m_comboboxFind.SetAutoRefreshAfterAdd ( TRUE );
    m_wndToolBar.m_comboboxFind.SetAutoSaveAfterAdd ( TRUE );
    m_wndToolBar.m_comboboxFind.LoadMRU();
    m_wndToolBar.m_comboboxFind.RefreshCtrl();
	////////////////////////////////////////

    m_wndToolBar.SetButtonInfo(21, IDC_COMBOX, TBBS_SEPARATOR, 110 );
    m_wndToolBar.GetItemRect(21, &rect);
    rect.bottom += 350;
	if(!m_wndToolBar.m_combobox.Create(CBS_DROPDOWNLIST|CBS_AUTOHSCROLL|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL, rect, &m_wndToolBar, IDC_COMBOX))
        return -1;
	
    m_wndToolBar.m_combobox.SetFont(f);
	m_wndToolBar.m_combobox.ShowAutoWidth(TRUE);

	m_wndToolBar.m_combobox.AddString(_T("Ada"));
	m_wndToolBar.m_combobox.AddString(_T("AML"));
	m_wndToolBar.m_combobox.AddString(_T("ASM"));
	m_wndToolBar.m_combobox.AddString(_T("Basic"));
	m_wndToolBar.m_combobox.AddString(_T("BAT"));
	m_wndToolBar.m_combobox.AddString(_T("Blue"));
	m_wndToolBar.m_combobox.AddString(_T("Clipper"));
	m_wndToolBar.m_combobox.AddString(_T("COBOL"));
	m_wndToolBar.m_combobox.AddString(_T("C++"));
	m_wndToolBar.m_combobox.AddString(_T("C#"));
	m_wndToolBar.m_combobox.AddString(_T("Dataflex"));
	m_wndToolBar.m_combobox.AddString(_T("Eiffel"));
	m_wndToolBar.m_combobox.AddString(_T("FORTRAN"));
	m_wndToolBar.m_combobox.AddString(_T("HLBL"));
	m_wndToolBar.m_combobox.AddString(_T("HTML"));
	m_wndToolBar.m_combobox.AddString(_T("INI"));
	m_wndToolBar.m_combobox.AddString(_T("Java"));
	m_wndToolBar.m_combobox.AddString(_T("JSP"));
	m_wndToolBar.m_combobox.AddString(_T("LIMBO"));
	m_wndToolBar.m_combobox.AddString(_T("LISP"));
	m_wndToolBar.m_combobox.AddString(_T("Modula2"));
	m_wndToolBar.m_combobox.AddString(_T("Object Pascal"));
	m_wndToolBar.m_combobox.AddString(_T("Paradox"));
	m_wndToolBar.m_combobox.AddString(_T("Perl"));
	m_wndToolBar.m_combobox.AddString(_T("PHP"));
	m_wndToolBar.m_combobox.AddString(_T("PL1"));
	m_wndToolBar.m_combobox.AddString(_T("Progress"));
	m_wndToolBar.m_combobox.AddString(_T("Python"));
	m_wndToolBar.m_combobox.AddString(_T("REBOL"));
	m_wndToolBar.m_combobox.AddString(_T("REXX"));
	m_wndToolBar.m_combobox.AddString(_T("RUBY"));
	m_wndToolBar.m_combobox.AddString(_T("Smalltalk"));
	m_wndToolBar.m_combobox.AddString(_T("SQL"));
	m_wndToolBar.m_combobox.AddString(_T("VHDL"));
	m_wndToolBar.m_combobox.AddString(_T("XML"));
	m_wndToolBar.m_combobox.AddString(_T("Plain text"));

	return 0;
}


void CMainFrame::OnSelchangeCombo() 
{
	CString strlanguage;
    m_wndToolBar.m_combobox.GetLBText(
        m_wndToolBar.m_combobox.GetCurSel(), strlanguage);
	int nlanguage = GetLanguageByStringShow(strlanguage);
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	icrEditView->SelectLanguage(nlanguage); 
}

void CMainFrame::OnEditPaste() 
{	
	char * buffer;
	if(!OpenClipboard())
		return;	

	buffer = (char*)::GetClipboardData(CF_TEXT);
	CloseClipboard(); 
	CString str = buffer;

	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();

	CWnd *pWnd = GetFocus();
	if(pWnd->m_hWnd!=edit.m_hWnd)
	{
		pWnd->SendMessage(WM_PASTE, 0, 0);
		return;
	}
	
	CHARRANGE cr;
	edit.GetSel(cr); 	
	icrEditView->SetParseCookieZeroFromGivenLine(edit.LineFromChar(cr.cpMin)); //ճ��ʱ�����ý���������
	edit.ReplaceSel(str, TRUE); 

	if(cr.cpMax != cr.cpMin)
	{
		icrEditView->ReCalcCursorPostion();
	}
}

void CMainFrame::OnEditcut() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &SynCtrl = icrEditView->GetRichEditCtrl();

	CWnd *pWnd = GetFocus();
	if(pWnd->m_hWnd != SynCtrl.m_hWnd)
	{
		pWnd->SendMessage(WM_CUT, 0, 0);
		return;
	}
	
	CHARRANGE cr;
	SynCtrl.GetSel( cr ); 

	icrEditView->GetRichEditCtrl().Cut();  

	if(cr.cpMax != cr.cpMin)
	{
		icrEditView->ReCalcCursorPostion();
	}
	else
	{
		SCROLLINFO si;
		si.cbSize = sizeof(si);
		icrEditView->GetScrollInfo(SB_HORZ, &si);
		icrEditView->m_nHorzMaxOld = si.nMax;
	}
}

void CMainFrame::OnUpdateEditcut(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl& editctrl = icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 	
}

void CMainFrame::OnEditcopy()
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();

	CWnd *pWnd = GetFocus();
	if(pWnd->m_hWnd != edit.m_hWnd)
	{
		pWnd->SendMessage(WM_COPY, 0, 0);
	}
	else
	{
		edit.Copy();
	}
}

void CMainFrame::OnUpdateEditcopy(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl& editctrl = icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 
}

void CMainFrame::OnUpdateEditpaste(CCmdUI* pCmdUI) 
{
	OpenClipboard();
	if(::GetClipboardData(CF_TEXT)==FALSE)
		pCmdUI->Enable(FALSE);
	else
		pCmdUI->Enable(TRUE); 
	CloseClipboard();		
}

void CMainFrame::OnEditundo() 
{
	GetFocus()->SendMessage(EM_UNDO, 0, 0);
}

void CMainFrame::OnUpdateEditundo(CCmdUI* pCmdUI) 
{
	CWnd *pWnd = GetFocus();
	if(!pWnd)
		return;

	BOOL bCanUndo = pWnd->SendMessage(EM_CANUNDO, 0, 0);
	pCmdUI->Enable(bCanUndo); 
}

void CMainFrame::OnEditredo() 
{
	GetFocus()->SendMessage(EM_REDO, 0, 0);
}

void CMainFrame::OnUpdateEditredo(CCmdUI* pCmdUI) 
{
	CWnd *pWnd = GetFocus();
	if(!pWnd)
		return;

	BOOL bCanRedo = pWnd->SendMessage(EM_CANREDO, 0, 0);
	pCmdUI->Enable(bCanRedo); 
}

void CMainFrame::OnEditselectall() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 

	CWnd *pWnd = GetFocus();
	if(pWnd->m_hWnd != editctrl.m_hWnd)
	{
		CString str;
		pWnd->GetWindowText(str);
		CHARRANGE ichCharRange;
		ichCharRange.cpMax = str.GetLength();
		ichCharRange.cpMin = 0;
		pWnd->SendMessage(EM_EXSETSEL, 0, (LPARAM)&ichCharRange);
		return;
	}

	editctrl.SetSel(0, -1);
	editctrl.SetFocus();  
	editctrl.PostMessage( WM_PAINT, 0, 0 ); 
}

void CMainFrame::OnEditfind() 
{
	if(!m_pFindDialog)
		m_pFindDialog = new CFind(this);
	else
	{
		m_pFindDialog->ShowWindow(SW_SHOW);
		m_pFindDialog->SetFocus();
		return;
	}
	m_pFindDialog->Create(IDD_FIND, this);
	m_pFindDialog->ShowWindow(SW_SHOW);
	return;	
}

void CMainFrame::OnEditrepeat() 
{
	CWinApp *app = AfxGetApp();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)GetActiveView(); 

	CString strEdit;
	mainfrm->m_wndToolBar.m_comboboxFind.GetWindowText(strEdit);
	//CString strEdit = app->GetProfileString(_T("CFind"), _T("str"), _T(""));
	BOOL bWholeWord = app->GetProfileInt(_T("CFind"), _T("WholeWord"), 0);	
	BOOL bCase = app->GetProfileInt(_T("CFind"), _T("Case"), 0);	
	
	if(strEdit.IsEmpty())
		return;

	int dwFlags = 0;
	if(bCase)
		dwFlags|=FR_MATCHCASE;
	if(bWholeWord)
		dwFlags|=FR_WHOLEWORD;

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	edit.GetSel(cr); 
	FINDTEXTEX *ft = new FINDTEXTEX[1];
	ft->chrg.cpMin = cr.cpMin-1; 
	ft->chrg.cpMax = -1;// search through end of the text 
	
	TCHAR *t = new TCHAR[strEdit.GetLength()+1];
	strcpy(t, strEdit);
	ft->lpstrText = t;
	
	mainfrm->m_wndToolBar.m_comboboxFind.AddToMRU(strEdit); 
	app->WriteProfileString(_T("CFind"), _T("str"), strEdit);	
		
	icrEditView->ShowWindow(SW_HIDE); 
	int nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 

	if(nPos!=-1) {
		edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
		icrEditView->SetFocus(); 
		SetFocus();
		icrEditView->ShowWindow(SW_SHOW);
	}
	else {
		icrEditView->ShowWindow(SW_SHOW);
		CString strShow;
		strShow.Format(_T("Cannot find the string: \"%s\", search again from the end?"), strEdit);
		if(MessageBox(strShow,_T("Find"), MB_ICONINFORMATION|MB_YESNO)==IDYES)
		{
			icrEditView->ShowWindow(SW_HIDE); 
			edit.SetSel(0, -1); 
			icrEditView->ShowWindow(SW_SHOW);
			CHARRANGE cr;
			edit.GetSel(cr); 
			edit.SetSel(cr.cpMax, cr.cpMax); 
			
			OnEditrepeat();
			if(t)
				delete t;
			if(ft)
				delete ft;
			return;
		}
	}
	if(t)
		delete t;
	if(ft)
		delete ft;
}

void CMainFrame::OnEditrepeatnext() 
{
	CWinApp *app = AfxGetApp();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)GetActiveView(); 

	CString strEdit;
	mainfrm->m_wndToolBar.m_comboboxFind.GetWindowText(strEdit);
	//CString strEdit = app->GetProfileString(_T("CFind"), _T("str"), _T(""));
	BOOL bWholeWord = app->GetProfileInt(_T("CFind"), _T("WholeWord"), 0);	
	BOOL bCase = app->GetProfileInt(_T("CFind"), _T("Case"), 0);	
	
	if(strEdit.IsEmpty())
		return;

	int dwFlags = 0;
	if(bCase)
		dwFlags|=FR_MATCHCASE;
	if(bWholeWord)
		dwFlags|=FR_WHOLEWORD;
	dwFlags|=FR_DOWN;;

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	edit.GetSel(cr); 
	FINDTEXTEX *ft = new FINDTEXTEX[1];
	ft->chrg.cpMin = cr.cpMin+1; 
	ft->chrg.cpMax = -1;// search through end of the text 
	
	TCHAR *t = new TCHAR[strEdit.GetLength()+1];
	strcpy(t, strEdit);
	ft->lpstrText = t;
	
	mainfrm->m_wndToolBar.m_comboboxFind.AddToMRU(strEdit); 
	app->WriteProfileString(_T("CFind"), _T("str"), strEdit);	
	
	icrEditView->ShowWindow(SW_HIDE); 
	int nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 
	
	if(nPos!=-1) {
		
		edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
		icrEditView->SetFocus(); 
		SetFocus();
		icrEditView->ShowWindow(SW_SHOW);
	}
	else {
		icrEditView->ShowWindow(SW_SHOW);
		CString strShow;
		strShow.Format(_T("Cannot find the string: \"%s\", search again from the beginning?"), strEdit);
		if(MessageBox(strShow, _T("Find"), MB_ICONINFORMATION|MB_YESNO)==IDYES)
		{
			edit.SetSel(0, 0); 			
			OnEditrepeatnext();
			if(t)
				delete t;
			if(ft)
				delete ft;
			return;
		}
	}	
	if(t)
		delete t;
	if(ft)
		delete ft;
}

void CMainFrame::OnUpdateEditrepeat(CCmdUI* pCmdUI) 
{
	CString strEdit;
	m_wndToolBar.m_comboboxFind.GetWindowText(strEdit);
	pCmdUI->Enable(!strEdit.IsEmpty()); 
}

void CMainFrame::OnUpdateEditrepeatnext(CCmdUI* pCmdUI) 
{
	CString strEdit;
	m_wndToolBar.m_comboboxFind.GetWindowText(strEdit);
	pCmdUI->Enable(!strEdit.IsEmpty()); 
}

void CMainFrame::OnEditreplace() 
{
	if(!m_pReplaceDialog)
		m_pReplaceDialog = new CReplace(this);
	else
	{
		m_pReplaceDialog->ShowWindow(SW_SHOW);
		m_pReplaceDialog->SetFocus();
		return;
	}
	m_pReplaceDialog->Create(IDD_REPLACE, this);
	m_pReplaceDialog->ShowWindow(SW_SHOW);
	return;		
}

void CMainFrame::OnViewFont() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	BOOL bModify = edit.GetModify();
	edit.ShowWindow(SW_HIDE);
	
	CString strText;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strText;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);
	
	CHARFORMAT cr;
	
	if(strText.IsEmpty())
	{
		strText = _T(" ");
		edit.SetSel(0, 1);
		cr = icrEditView->GetCharFormatSelection();
		edit.SetSel(0, 0); 
	}
	else
	{
		CHARRANGE range;
		edit.GetSel(range);
		int ntemp;
		if(range.cpMax < range.cpMin)
		{
			ntemp = range.cpMax;
			range.cpMax = range.cpMin;
			range.cpMin = ntemp;
		}

		if(range.cpMax == range.cpMin)
		{
			if(range.cpMin == 0)
			{
				edit.SetSel(0, 1);
			}
			else
			{
				edit.SetSel(range.cpMin-1, range.cpMin);
			}
			
			cr = icrEditView->GetCharFormatSelection();
			edit.SetSel(range.cpMin, range.cpMin);
		}
		else
		{
			cr = icrEditView->GetCharFormatSelection();
		}
	}

	edit.ShowWindow(SW_SHOW);
	
	CFontDialog dlg(cr, CF_BOTH|CF_NOOEMFONTS);
	
	if (dlg.DoModal() == IDOK)
	{		
		CHARFORMAT cr;
		dlg.GetCharFormat(cr);
		LockWindowUpdate();
		
		icrEditView->SetWindowText(_T(""));
		
		icrEditView->SetSynEditViewFont(*dlg.m_cf.lpLogFont);
		icrEditView->SetWindowText(strText);		
		
		edit.SetModify(bModify);
		UnlockWindowUpdate();
	}	
}

void CMainFrame::SaveTheContext()
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &richctrl=icrEditView->GetRichEditCtrl();
	
	if(0 == m_strFileName.GetLength())
		return;

	CFile cFile(m_strFileName, CFile::modeCreate|CFile::modeWrite);
	EDITSTREAM es;
	es.dwCookie = (DWORD) &cFile;
	es.pfnCallback = EditStreamCallbackWriteToFile; 
	richctrl.StreamOut(SF_TEXT, es);
	richctrl.SetModify(FALSE); 
}


void CMainFrame::OnFileOpen() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	if(edit.GetModify())
	{
		if(MessageBox("This file has been modified, do you want to save it?", "", MB_YESNO|MB_ICONQUESTION)==IDNO)
		{
			return;
		}
	}
	
	CFileDialog fd (TRUE, _T(""), NULL, OFN_HIDEREADONLY|OFN_EXPLORER, "*.*|*.*||"); 
	if(IDCANCEL == fd.DoModal())
	{
		return;
	}
	
	m_strFileName = fd.GetPathName();
	icrEditView->LoadFile(m_strFileName);
}


void CMainFrame::OnEditTrimtraillingspace() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();

	CWaitCursor wc;

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	int nfirstline = edit.GetFirstVisibleLine(); 
	CHARRANGE cr;
	edit.GetSel(cr);
	int nline = edit.LineFromChar(cr.cpMin);  

	CString strtext;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strtext;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);

	CString strnewtext = _T(""), strline;
	int npos = strtext.Find('\n');
	while(npos!=-1) {
		strline = strtext.Left(npos-1);
		strline.TrimRight(0x20);
		strline += '\n';
		strtext = strtext.Right(strtext.GetLength()-npos-1); 
		strnewtext += strline;
		npos = strtext.Find('\n');
	}

	icrEditView->LoadText(strnewtext);
	icrEditView->GotoLine(nfirstline+1); 
	int nlineindex = edit.LineIndex(nline); 
	edit.SetSel(nlineindex, nlineindex); 
	icrEditView->ShowCursorPosition(); 
	icrEditView->SetFocus(); 
	SaveTheContext();
}

void CMainFrame::OnEditTrimtraillingtab() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();

	CWaitCursor wc;

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	int nfirstline = edit.GetFirstVisibleLine(); 
	CHARRANGE cr;
	edit.GetSel(cr);
	int nline = edit.LineFromChar(cr.cpMin);  

	CString strtext;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strtext;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);

	CString strnewtext = _T(""), strline;
	int npos = strtext.Find('\n');
	while(npos!=-1) {
		strline = strtext.Left(npos-1);
		strline.TrimRight(0x9);
		strline += '\n';
		strtext = strtext.Right(strtext.GetLength()-npos-1); 
		strnewtext += strline;
		npos = strtext.Find('\n');
	}

	icrEditView->LoadText(strnewtext);
	icrEditView->GotoLine(nfirstline+1); 
	int nlineindex = edit.LineIndex(nline); 
	edit.SetSel(nlineindex, nlineindex); 
	icrEditView->ShowCursorPosition(); 
	icrEditView->SetFocus(); 
	SaveTheContext();	
}

void CMainFrame::OnEditTabtospace() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();

	CWaitCursor wc;
	TCHAR chr = 0x9;
	CString strtab = chr;
	int ntabsize = icrEditView->GetTabSize(); 
	CString strspace(0x20, ntabsize);

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	int nfirstline = edit.GetFirstVisibleLine(); 
	CHARRANGE cr;
	edit.GetSel(cr);
	int nline = edit.LineFromChar(cr.cpMin);  

	CString strtext;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strtext;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);

	strtext.Replace(strtab, strspace); 
	icrEditView->LoadText(strtext);
	icrEditView->GotoLine(nfirstline+1); 
	int nlineindex = edit.LineIndex(nline); 
	edit.SetSel(nlineindex, nlineindex); 
	icrEditView->ShowCursorPosition(); 
	icrEditView->SetFocus(); 
	SaveTheContext();	
}

void CMainFrame::OnEditSpacetotab() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();

	CWaitCursor wc;
	TCHAR chr = 0x9;
	CString strtab = chr;
	int ntabsize = icrEditView->GetTabSize(); 
	CString strspace(0x20, ntabsize);

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	int nfirstline = edit.GetFirstVisibleLine(); 
	CHARRANGE cr;
	edit.GetSel(cr);
	int nline = edit.LineFromChar(cr.cpMin);  

	CString strtext;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strtext;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);

	strtext.Replace(strspace, strtab); 
	icrEditView->LoadText(strtext);
	icrEditView->GotoLine(nfirstline+1); 
	int nlineindex = edit.LineIndex(nline); 
	edit.SetSel(nlineindex, nlineindex); 
	icrEditView->ShowCursorPosition(); 
	icrEditView->SetFocus(); 
	SaveTheContext();	
}

void CMainFrame::OnEditLeadingspacetotab() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();

	CWaitCursor wc;
	int ntabsize = icrEditView->GetTabSize(); 
	CString strspace(0x20, ntabsize);

	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	int nfirstline = edit.GetFirstVisibleLine(); 
	CHARRANGE cr;
	edit.GetSel(cr);
	int nline = edit.LineFromChar(cr.cpMin);  

	CString strtext;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strtext;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT, stream);

	CString strnewtext = _T(""), strline;
	int npos = strtext.Find('\n');
	while(npos!=-1) {
		int i=0;
		strline = strtext.Left(npos);
		while(strline[i]==0x20 || strline[i]==0x9)
			i++;
		CString strtmp = strline.Left(i); 
		strtmp.Replace( strspace, _T("\t"));
		strline = strtmp + strline.Right(strline.GetLength()-i); 
		strline += '\n';

		strtext = strtext.Right(strtext.GetLength()-npos-1); 
		strnewtext += strline;
		npos = strtext.Find('\n');
	}

	icrEditView->LoadText(strnewtext);
	icrEditView->GotoLine(nfirstline+1); 
	int nlineindex = edit.LineIndex(nline); 
	edit.SetSel(nlineindex, nlineindex); 
	icrEditView->ShowCursorPosition(); 
	icrEditView->SetFocus(); 	
	SaveTheContext();	
}

void CMainFrame::OnEditMoveright() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &SynCtrl = icrEditView->GetRichEditCtrl(); 
	icrEditView->ShowWindow(SW_HIDE); 

	int nfirstline, nendline;
	icrEditView->GetSelLine(nfirstline, nendline);
	
	CString strtext=_T(""), strline;

	BOOL bpriorlinerealreturn;
	int linenumber = nendline - nfirstline + 1;

	for(int i=0; i<linenumber; i++) {
		if(nfirstline+i-1<0)//�ж�ǰһ����ĩ�Ƿ���Ӳ�س�
			bpriorlinerealreturn = TRUE;
		else
			bpriorlinerealreturn = icrEditView->GetLineString(nfirstline+i-1, strline);
		icrEditView->GetLineString(nfirstline+i, strline);
		if(bpriorlinerealreturn || nfirstline==nendline) { //�����һ������Ļ���
			int nselstart = SynCtrl.LineIndex(nfirstline+i); 
			SynCtrl.SetSel(nselstart, nselstart); 
			int noldlinecount = SynCtrl.GetLineCount(); 
			SynCtrl.ReplaceSel(_T("\t"), TRUE); //�滻�����������������
			int nnewlinecount = SynCtrl.GetLineCount();
			linenumber+=nnewlinecount-noldlinecount;
		}
	}

	int nselstart = SynCtrl.LineIndex(nfirstline); 
	int nselend =  SynCtrl.LineIndex(nfirstline+linenumber);
	SynCtrl.SetSel(nselstart, nselend); 
	icrEditView->ShowWindow(SW_SHOW);	
}

void CMainFrame::OnEditMoveleft() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &SynCtrl = icrEditView->GetRichEditCtrl(); 
	icrEditView->ShowWindow(SW_HIDE); 

	int nfirstline, nendline;
	icrEditView->GetSelLine(nfirstline, nendline);
	
	CString strtext=_T(""), strline;
	
	BOOL bpriorlinerealreturn;
	int linenumber = nendline - nfirstline + 1;
	
	for(int i=0; i<linenumber; i++) {
		if(nfirstline+i-1<0)//�ж�ǰһ����ĩ�Ƿ���Ӳ�س�
			bpriorlinerealreturn = TRUE;
		else
			bpriorlinerealreturn = icrEditView->GetLineString(nfirstline+i-1, strline);
		icrEditView->GetLineString(nfirstline+i, strline);
		if(bpriorlinerealreturn || nfirstline==nendline) { //�����һ������Ļ���
			int nselstart = SynCtrl.LineIndex(nfirstline+i); 
			SynCtrl.SetSel(nselstart, nselstart);
			if(strline.Left(1)==_T("\t")) {
				SynCtrl.SetSel(nselstart, nselstart+1);
				SynCtrl.ReplaceSel(_T(""), TRUE); //�滻�����������������
			}
			else {
				if(strline!=_T(" ")) { //֮�����д��ж�����Ϊ����ǿ���icrEditView->GetLineString�᷵��һ���ո�
					int ncount = (strline.GetLength()>icrEditView->GetTabSize()? strline.GetLength():icrEditView->GetTabSize()); 
					for(int j=0; j<ncount; j++) {	
						if(strline[j]!=0x20)
							break;
					}
					SynCtrl.SetSel(nselstart, nselstart+j); 
					SynCtrl.ReplaceSel(_T(""), TRUE); //�滻�����������������
				}
			}
			int noldlinecount = SynCtrl.GetLineCount(); 
			int nnewlinecount = SynCtrl.GetLineCount();
			linenumber+=nnewlinecount-noldlinecount;
		}	
	}

	int nselstart = SynCtrl.LineIndex(nfirstline); 
	int nselend =  SynCtrl.LineIndex(nfirstline+linenumber);
	SynCtrl.SetSel(nselstart, nselend); 
	icrEditView->ShowWindow(SW_SHOW);	
}

void CMainFrame::OnEditUncomment() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &SynCtrl = icrEditView->GetRichEditCtrl(); 

	int nfirstline, nendline;
	icrEditView->GetSelLine(nfirstline, nendline);
	
	//ȡ��ǰ���Զ�Ӧ�ĵ���ע���ַ���
	CString strsinglecomment=icrEditView->GetSingleCommentString(icrEditView->GetLanguage());  
	if(strsinglecomment.IsEmpty()) //��Ϊ�մ���ʾ��ǰû�н����﷨�ؼ�����ʾ
		return;
	CString strtext=_T(""), strline;
	
	icrEditView->ShowWindow(SW_HIDE);

	BOOL bpriorlinerealreturn;
	int linenumber = nendline - nfirstline + 1;
	
	for(int i=0; i<linenumber; i++) {
		if(nfirstline+i-1<0)//�ж�ǰһ����ĩ�Ƿ���Ӳ�س�
			bpriorlinerealreturn = TRUE;
		else
			bpriorlinerealreturn = icrEditView->GetLineString(nfirstline+i-1, strline);
		icrEditView->GetLineString(nfirstline+i, strline);
		if(bpriorlinerealreturn || nfirstline==nendline) { //�����һ������Ļ���
			int nselstart = SynCtrl.LineIndex(nfirstline+i); 
			SynCtrl.SetSel(nselstart, nselstart);
			if(strline!=_T(" ")) {
				if(strline.Left(strsinglecomment.GetLength())==strsinglecomment) 
					SynCtrl.SetSel(nselstart, nselstart+strsinglecomment.GetLength()); 
				else {
					CString strtmp = strline;
					if(strtmp.GetLength()!=0) {
						while(strtmp.GetAt(0)==0x20 || strtmp.GetAt(0)=='\t') {
							strtmp.TrimLeft(0x20); 
							strtmp.TrimLeft('\t');
							if(strtmp.GetLength()==0)
								break;
						}
						if(strtmp.GetLength()>=strsinglecomment.GetLength() ) {
							if(strtmp.Left(strsinglecomment.GetLength())==strsinglecomment) {
								int npos = strline.Find(strsinglecomment);
								SynCtrl.SetSel( nselstart+npos, nselstart+npos+strsinglecomment.GetLength());
							}	
						}
					}
				}
			}
						
			int noldlinecount=SynCtrl.GetLineCount(); 
			SynCtrl.ReplaceSel(_T(""), TRUE); //���п��������ܵ���������
			int nnewlinecount=SynCtrl.GetLineCount();
			linenumber+=nnewlinecount-noldlinecount;
		}	
	}

	int nselstart = SynCtrl.LineIndex(nfirstline); 
	int nselend =  SynCtrl.LineIndex(nfirstline+linenumber);
	SynCtrl.SetSel(nselstart, nselend); 
	icrEditView->ShowWindow(SW_SHOW);
}

void CMainFrame::OnEditComment() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &SynCtrl = icrEditView->GetRichEditCtrl(); 

	int nfirstline, nendline;
	icrEditView->GetSelLine(nfirstline, nendline);
	
	//ȡ��ǰ���Զ�Ӧ�ĵ���ע���ַ���
	CString strsinglecomment=icrEditView->GetSingleCommentString(icrEditView->GetLanguage());  
	if(strsinglecomment.IsEmpty()) //��Ϊ�մ���ʾ��ǰû�н����﷨�ؼ�����ʾ
		return;

	icrEditView->ShowWindow(SW_HIDE); 
	CString strtext=_T(""), strline;

	BOOL bpriorlinerealreturn;
	int linenumber = nendline - nfirstline + 1;

	for(int i=0; i<linenumber; i++) {
		if(nfirstline+i-1<0)//�ж�ǰһ����ĩ�Ƿ���Ӳ�س�
			bpriorlinerealreturn = TRUE;
		else
			bpriorlinerealreturn = icrEditView->GetLineString(nfirstline+i-1, strline);
		icrEditView->GetLineString(nfirstline+i, strline);
		if(bpriorlinerealreturn || nfirstline==nendline) { //�����һ������Ļ���
			int nselstart = SynCtrl.LineIndex(nfirstline+i); 
			SynCtrl.SetSel(nselstart, nselstart); 
			int noldlinecount = SynCtrl.GetLineCount(); 
			SynCtrl.ReplaceSel(strsinglecomment, TRUE);
			int nnewlinecount = SynCtrl.GetLineCount();
			linenumber+=nnewlinecount-noldlinecount;
		}
	}

	int nselstart = SynCtrl.LineIndex(nfirstline); 
	int nselend =  SynCtrl.LineIndex(nfirstline+linenumber);
	SynCtrl.SetSel(nselstart, nselend); 
	icrEditView->ShowWindow(SW_SHOW);	
}

void CMainFrame::OnEditLcase() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr); 
	CString strsel;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strsel;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT|SFF_SELECTION, stream);		
	
	strsel.MakeLower(); 
	edit.ReplaceSel(strsel, TRUE);	
	edit.SetSel(cr); 	
}

void CMainFrame::OnEditUcase() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr); 

	CString strsel;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strsel;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT|SFF_SELECTION, stream);
	
	strsel.MakeUpper();
	edit.ReplaceSel(strsel, TRUE);	
	edit.SetSel(cr); 	
}

void CMainFrame::OnEditInvert() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr); 
	CString strsel;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strsel;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT|SFF_SELECTION, stream);		
	
	for(int i=0; i<strsel.GetLength(); i++) {
		TCHAR ch = strsel[i]; 
		if( ch >='A' && ch <='Z' )
			strsel.SetAt(i, ch + 'a' - 'A'); 
		else if( ch >='a' && ch <='z' )
			strsel.SetAt(i, ch + 'A' - 'a'); 
	}
	edit.ReplaceSel(strsel, TRUE);	
	edit.SetSel(cr); 	
}

void CMainFrame::OnEditCapitalize() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr); 
	CString strsel;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strsel;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT|SFF_SELECTION, stream);
    strsel.MakeLower(); 
    
    BOOL bIsChar = FALSE, bInString=FALSE;
    for(int i=0; i<strsel.GetLength(); i++) {
        TCHAR ch = strsel[i]; 
        if( ch >='a' && ch <='z' && !bIsChar) {
            strsel.SetAt(i, ch + 'A' - 'a'); 
        }
		if( (ch >='a' && ch <='z') || (ch >='A' && ch <='Z') )
			bIsChar = TRUE;			
		else
			bIsChar = FALSE;
	}
	edit.ReplaceSel(strsel, TRUE);	
	edit.SetSel(cr); 	
}

void CMainFrame::OnEditSentancecase() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	CHARRANGE cr;
	edit.GetSel(cr); 
	CString strsel;
	EDITSTREAM stream;
	stream.dwCookie = (DWORD)&strsel;
	stream.pfnCallback = EditStreamCallbackOut;
	edit.StreamOut(SF_TEXT|SFF_SELECTION, stream);
    
	BOOL bDo = TRUE;
    for(int i=0; i<strsel.GetLength(); i++) {
        TCHAR ch = strsel[i]; 
		if(ch == 0xa)
			bDo = TRUE;
		if( ((ch >='a' && ch <='z') || (ch >='A' && ch <='Z')) && bDo) {
			if( ch >='A' && ch <='Z' )
				strsel.SetAt(i, ch + 'a' - 'A'); 
			else
				strsel.SetAt(i, ch + 'A' - 'a'); 
			bDo = FALSE;
		}
	}
	edit.ReplaceSel(strsel, TRUE);	
	edit.SetSel(cr); 		
}

void CMainFrame::OnEditInsertdatetime() 
{
	CDateTime dt;
	dt.DoModal();
}

void CMainFrame::OnEditInsertfile() 
{
	CRecentFileList list(1, _T("FileTypes"), _T("FileTypes #%d"), 255);
	CString strtmp, strtitle, strfilter=_T("");
	list.ReadList();
	for(int i=0;i<list.GetSize();i++) {
		strtmp=list[i];
		if(strtmp.IsEmpty())
			continue;
		strtmp=strtmp.Right(strtmp.GetLength()-3);
		int npos = strtmp.Find(_T("|*."));
		if(npos!=-1) {
			strtitle = strtmp.Left( npos );
			strtmp = strtmp.Right( strtmp.GetLength() - npos - 1 );
		}
		strfilter=strfilter + strtitle + _T("(") + strtmp + _T(")|") + strtmp + _T("|");
	}
	strfilter+=_T("*.*|*.*||");

	CWinApp *app = AfxGetApp();
	CFileDialog fd ( TRUE, _T(""), NULL, OFN_HIDEREADONLY, strfilter); 
	fd.m_ofn.nFilterIndex =  app->GetProfileInt( _T("InsertFile"), _T("nFilterIndex"), 0);
	fd.DoModal(); 
	app->WriteProfileInt( _T("InsertFile"), _T("nFilterIndex"), fd.m_ofn.nFilterIndex);
	strtmp = fd.GetPathName(); 
	if(strtmp.IsEmpty())
		return;

	strtmp = GetFileContext(strtmp);
	CIcrEditView *editview = (CIcrEditView *)GetActiveView();
	CRichEditCtrl& editctrl = editview->GetRichEditCtrl(); 
	editctrl.ReplaceSel( strtmp, TRUE ); 
	editctrl.SetFocus(); 	
}

CString CMainFrame::GetFileContext(CString strfile)
{
	CString str=_T("");;
	CFileException fe;
	CFile file;
	file.Open(strfile, CFile::modeRead, &fe);
	if(fe.m_cause != CFileException::none) {
		fe.ReportError();
		return  _T("");		
	}
	DWORD dwSize=file.GetLength(); 
	if(dwSize==0)
		return  _T("");		
	try {	
		LPSTR lpszContext=new TCHAR[1];
		file.ReadHuge(lpszContext, 1);
		if(*lpszContext==-1) {
			if(lpszContext!=NULL)
				delete lpszContext;
			LPWSTR lpsztext= new WCHAR[1];
			file.ReadHuge(lpsztext, 1);
			if(lpsztext!=NULL)
				delete lpsztext;
			lpsztext= new WCHAR[dwSize-1];
			DWORD dwRead=file.ReadHuge(lpsztext, dwSize-2);
			lpsztext[dwRead/2]=0;
			str=lpsztext;
			if(lpsztext!=NULL)
				delete lpsztext;
		}
		else {
			if(lpszContext!=NULL)
				delete lpszContext;
			lpszContext=new TCHAR[dwSize+2];
			file.Seek(0, CFile::begin);
			DWORD dwRead=file.ReadHuge(lpszContext, dwSize);
			file.Close(); 
			lpszContext[dwRead]='\0';
			str=lpszContext;
			if(lpszContext!=NULL)
				delete lpszContext;
		}
	}
	catch(...){}
	
	return str;
}


void CMainFrame::OnSelchangeComboFind() 
{
}


void CMainFrame::OnUpdateEditLcase(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 	
}


void CMainFrame::OnUpdateEditInvert(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 	
}

void CMainFrame::OnUpdateEditSentancecase(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 		
}

void CMainFrame::OnUpdateEditUcase(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 	
}

void CMainFrame::OnFileNew() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	if(!m_strFileName.IsEmpty())
	{
		if(edit.GetModify())
		{
			if(MessageBox("This file has been modified, do you want to save it?", "", MB_YESNO|MB_ICONQUESTION)==IDYES)
			{
				SaveTheContext();
			}
		}
	}
	
	edit.SetWindowText("");
	m_strFileName = "";
	icrEditView->SetSynEditViewFont(icrEditView->GetSynEditViewFont());
}


void CMainFrame::OnFileSaveAs() 
{
	if(m_strFileName.IsEmpty())
	{
		CFileDialog fd ( FALSE, _T(""), NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("*.*|*.*||")); 
		if(fd.DoModal()==IDCANCEL)
			return;
		m_strFileName = fd.GetPathName();
	}
	else
	{
		CString strFileName = m_strFileName;
		int nPos= strFileName.ReverseFind('\\');
		strFileName = strFileName.Right(strFileName.GetLength()-nPos-1);
		CFileDialog fd ( FALSE, "", NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("*.*|*.*||")); 
		wsprintf(fd.m_ofn.lpstrFile, strFileName);

		if(fd.DoModal()==IDCANCEL)
			return;
		m_strFileName = fd.GetPathName();
	}

	SaveTheContext();	
}



void CMainFrame::OnFilesave() 
{
	if(m_strFileName.IsEmpty())
	{
		CFileDialog fd ( FALSE, _T(""), NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("*.*|*.*||")); 
		if(fd.DoModal()==IDCANCEL)
			return;
		m_strFileName = fd.GetPathName();
	}

	SaveTheContext();	
}

void CMainFrame::OnUpdateEditCapitalize(CCmdUI* pCmdUI) 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &editctrl=icrEditView->GetRichEditCtrl(); 
	CHARRANGE cr;
	editctrl.GetSel(cr);
	pCmdUI->Enable(cr.cpMin!=cr.cpMax); 
	
}


void CMainFrame::OnClose() 
{
	CIcrEditView *icrEditView = (CIcrEditView *)GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();
	if(edit.GetModify())
	{
		int nRet = MessageBox("This file has been modified, do you want to save it?", "", MB_YESNOCANCEL|MB_ICONQUESTION);
		if(nRet==IDYES)
		{
			if(!m_strFileName.IsEmpty())
			{
				SaveTheContext();
			}
			else
			{
				CFileDialog fd ( FALSE, _T(""), NULL, OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, _T("*.*|*.*||")); 
				if(fd.DoModal()==IDCANCEL)
					return;
				m_strFileName = fd.GetPathName();
				SaveTheContext();
			}
		}
		else if(nRet==IDCANCEL)
		{
			return;
		}
	}
	
	CFrameWnd::OnClose();
}
