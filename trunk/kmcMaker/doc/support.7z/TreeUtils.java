/**
 * 2008-6-14
 */
package com.firefly.util.tree;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.hibernate.Hibernate;
import org.hibernate.collection.PersistentSet;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.NullValueInNestedPathException;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.Node;

import com.butterfly.web.util.StringUtils;
import com.butterfly.web.util.DateHelper;
import com.firefly.core.Application;
import com.firefly.orm.manager.Entity;
import com.firefly.util.BeanUtils;
import com.firefly.util.ClassTypeUtils;
import com.firefly.util.ObjectUtils;
import com.firefly.util.XMLObject;
import com.firefly.util.beans.CommonBeanWrapper;
import com.firefly.util.beans.FireflyBeanWrapper;
import com.firefly.util.parse.SimpleStringTemplateParser;
import com.firefly.util.parse.TemplateParser;

/**
 * <p>
 * 树对象的帮助类，封装了一些实用树对象的典型方法。
 * </p>
 * 
 * @author <A href="mailto:zhuhb9277@gmail.com">朱海斌</A>
 * 
 */
public abstract class TreeUtils {

    private static final String EMPTY_KEY_CODE_OF_MAP = "@[EMPTY_KEY_CODE_OF_MAP]@";
    private static TemplateParser parser = new SimpleStringTemplateParser();

    /**
     * <p>
     * 简单类型和基本类型的包装类。
     * </p>
     * <p>
     * Object2Tree方法中使用。
     * </p>
     * 
     * @author <A href="mailto:zhuhb9277@gmail.com">朱海斌</A>
     * 
     */
    protected static class ObjectRef {
        private Object value;

        public ObjectRef(Object value) {
            this.value = value;
        }

        public Object getValue() {
            return this.value;
        }
    }

    /**
     * <p>
     * 将对象转换成XML文本。
     * </p>
     * <p>
     * 根元素的标签为"response"。
     * </p>
     * <p>
     * 数组和列表集合的每个元素放在"value"标签内。
     * </p>
     * 
     * @param object
     *            待转换的对象。
     * @return String XML文本。
     */
    public static String Object2XML(Object object) {
        return Object2XML(object, "response", "value");
    }

    /**
     * <p>
     * 将对象转换成XML文本。
     * </p>
     * <p>
     * 允许指定根元素标签和数组元素标签。
     * </p>
     * 
     * @param object
     *            待转换的对象。
     * @param rootLabel
     *            根元素的标签。
     * @param arrayItemLabel
     *            数组元素的标签。
     * @return String XML文本。
     */
    public static String Object2XML(Object object, String rootLabel, String arrayItemLabel) {
        Tree<Object, Object> tree = Object2Tree(object, rootLabel, arrayItemLabel);
        XMLObject xmlObject = new XMLObject(rootLabel, true);
        addONode2XML(tree, xmlObject, null);
        return xmlObject.toXML();
    }

    /**
     * <p>
     * 将一个树节点中装载的对象加入到XML中。
     * </p>
     * <p>
     * 这是一个递归调用的方法，用于处理树的所有子节点。
     * </p>
     * 
     * @param tree
     *            树对象。
     * @param xmlObject
     *            XMLObject对象。
     * @param parentNode
     *            父节点。
     */
    protected static void addONode2XML(Tree<Object, Object> tree, XMLObject xmlObject, Node parentNode) {

        // key为树中装载的值对象
        Object key = tree.getKey();

        // value为标签名称
        String value = tree.getValue().toString();

        // 获得父节点
        Node node = parentNode;
        if (parentNode == null) {
            node = xmlObject.getRootNode();
        } else {
            value = value.replace(".", "_");
            try {
                node = xmlObject.createElement(parentNode, value);
            } catch (Exception e) {
                node = xmlObject.createElement(parentNode, "InvalidLabel");
            }
        }
        // 处理简单类型和基本类型的对象，这些对象被包装在ObjectRef类中
        if (key instanceof ObjectRef) {
            Object object = ((ObjectRef) key).getValue();
            xmlObject.setNodeText(node, object.toString());
        }
        // 处理树的子节点
        else {
            if (tree.hasChildren()) {
                for (Tree<Object, Object> subTree : tree.getChildren()) {
                    addONode2XML(subTree, xmlObject, node);
                }
            }
        }
    }

    /**
     * <p>
     * 将对象转换为JSON文本。
     * </p>
     * <p>
     * 根节点的名称为"root"。
     * </p>
     * 
     * @param object
     *            待转换的对象。
     * @return String JSON文本。
     */
    public static String Object2JSON(Object object) {
//    	long a = new Date().getTime();
//		System.out.println(a);
//		String str = Object2JSON(object, "");
//		long b = new Date().getTime();
//		System.out.println(b);
//		System.out.println("修改后："+(b - a));
//		
//		long c = new Date().getTime();
//		System.out.println(c);
//		String str2 = Object2JSON_bak(object, "");
//		long d = new Date().getTime();
//		System.out.println(d);
//		System.out.println("修改前："+(d - c));
        return Object2JSON(object, "");
    }

    /**
     * <p>
     * 将对象转换为JSON文本。
     * </p>
     * <p>
     * 允许指定根节点名称。
     * </p>
     * 
     * @param object
     *            待转换的对象。
     * @param rootLabel
     *            根元素的标签。
     * @return String JSON文本。
     */
    public static String Object2JSON(Object object, String rootLabel) {
        Tree<Object, Object> tree = Object2Tree(object, rootLabel, "");
        
        StringBuffer filePath = new StringBuffer("");
        StringBuffer json = new StringBuffer("");
        String str = addNode2JSON(tree , json , filePath);
        
        if("".equals(filePath.toString())){
        	return str;        	
        } else {
        	String file = StringUtils.readTempFile(filePath.toString());
			StringUtils.deleteTempFile(filePath.toString());
			return file + str ;
        }
        
//        return str;
    }

    
    public static String Object2JSON_bak(Object object, String rootLabel) {
        Tree<Object, Object> tree = Object2Tree(object, rootLabel, "");
        return addNode2JSON_bak(tree);
    }
    
    /**
     * <p>
     * 将一个树节点中装载的对象输出为JSON文本。
     * </p>
     * <p>
     * 这是一个递归调用的方法，用于处理树的所有子节点。
     * </p>
     * 
     * @param tree
     *            树对象。
     * @return String JSON文本。
     */
    protected static String addNode2JSON(Tree<Object, Object> tree , StringBuffer json , StringBuffer filePath) {

        if (tree == null) {
            return "";
        }

//        StringBuffer json = new StringBuffer("");

        // key为树中装载的值对象
        Object key = tree.getKey();

        // value为对象名称
        StringBuffer value = new StringBuffer( tree.getValue().toString() );

        // 忽略空字符串的对象名称
        if (value.length() > 0) {
            if (value.equals(EMPTY_KEY_CODE_OF_MAP)) {
                value = new StringBuffer("");
            }
            json.append("\"").append(value).append("\" : ");
        }

        // 处理简单类型和基本类型的对象，这些对象被包装在ObjectRef类中
        if (key instanceof ObjectRef) {
            Object object = ((ObjectRef) key).getValue();
            if (object instanceof Class) {
                object = ((Class<?>) object).getName();
            }
            if (object instanceof String) {
                json.append("\"").append( ((String) object).replaceAll("\\\\", "\\\\\\\\\\\\\\\\").replaceAll("\"", "\\\\\"")
                                .replaceAll("'", "\\\\'").replaceAll("\r\n", "<br>").replaceAll("\r", "<br>")
                                .replaceAll("\n", "<br>") + "\"" );
            } else {
                json.append( object );
            }
        }
        // 处理树的子节点
        else {
            // Map类型和复杂类型使用"{}"
            String prefix = "{";
            String suffix = "\r\n}";
            String middlefix = "\r\n";
            // 数组类型和List类型使用"[]"
            if (ClassTypeUtils.isArray(key) || ClassTypeUtils.isCollection(key)) {
                prefix = "[";
                suffix = "]";
                middlefix = "";
            }
            json .append( prefix );
            if (tree.hasChildren()) {
                int i = 0;
                for (Tree<Object, Object> subTree : tree.getChildren()) {
                    if (i > 0) {
                        json.append(", ");
                    }
                    i++;
                    json.append( middlefix );
                    addNode2JSON(subTree , json , filePath) ;
//                    json.append( addNode2JSON(subTree , json , filePath) );
                }
            }
            json.append( suffix );
        }
        
		// 处理StringBuffer的内存溢出
		if(json.length() > 60000){
			if("".equals(filePath.toString())){
				filePath.append( UUID.randomUUID()+".txt" );
			}
			StringUtils.createTempFile(filePath.toString(), json.toString());
			json.delete(0, json.length());
			
		}
        return json.toString();
    }
    
    
    
    
    protected static String addNode2JSON_bak(Tree<Object, Object> tree) {

        if (tree == null) {
            return "";
        }

        String json = "";

        // key为树中装载的值对象
        Object key = tree.getKey();

        // value为对象名称
        String value = tree.getValue().toString();

        // 忽略空字符串的对象名称
        if (value.length() > 0) {
            if (value.equals(EMPTY_KEY_CODE_OF_MAP)) {
                value = "";
            }
            json += "\"" + value + "\" : ";
        }

        // 处理简单类型和基本类型的对象，这些对象被包装在ObjectRef类中
        if (key instanceof ObjectRef) {
            Object object = ((ObjectRef) key).getValue();
            if (object instanceof Class) {
                object = ((Class<?>) object).getName();
            }
            if (object instanceof String) {
                json += "\""
                        + ((String) object).replaceAll("\\\\", "\\\\\\\\\\\\\\\\").replaceAll("\"", "\\\\\"")
                                .replaceAll("'", "\\\\'").replaceAll("\r\n", "<br>").replaceAll("\r", "<br>")
                                .replaceAll("\n", "<br>") + "\"";
            } else {
                json += object;
            }
        }
        // 处理树的子节点
        else {
            // Map类型和复杂类型使用"{}"
            String prefix = "{";
            String suffix = "\r\n}";
            String middlefix = "\r\n";
            // 数组类型和List类型使用"[]"
            if (ClassTypeUtils.isArray(key) || ClassTypeUtils.isCollection(key)) {
                prefix = "[";
                suffix = "]";
                middlefix = "";
            }
            json += prefix;
            if (tree.hasChildren()) {
                int i = 0;
                for (Tree<Object, Object> subTree : tree.getChildren()) {
                    if (i > 0) {
                        json += ", ";
                    }
                    i++;
                    json += middlefix;
                    json += addNode2JSON(subTree, new StringBuffer("") , new StringBuffer(""));
                }
            }
            json += suffix;
        }
        return json;
    }

    /**
     * <p>
     * 将一个对象转换为树对象。
     * </p>
     * <p>
     * 解析集合对象和复杂对象，直到找到基本类型和简单类型的对象为止。
     * </p>
     * <p>
     * 复杂对象的解析使用了反射。
     * </p>
     * 
     * @param object
     *            待转换的对象。
     * @param rootName
     *            　根节点的标签名。
     * @param arrayTitle
     *            　数组元素的标签名。
     * @return Tree<Object,Object> 树对象。
     */
    public static Tree<Object, Object> Object2Tree(Object object, String rootName, String arrayTitle) {
        if (object == null) {
            return null;
        }
        Tree<Object, Object> tree = new LinkedTree<Object, Object>(object, rootName);
        addObject2Tree(tree, object, arrayTitle);
        return tree;
    }

    /**
     * <p>
     * 将一个对象装载成树节点并加入到树种。
     * </p>
     * <p>
     * 这是一个递归调用的方法，用于处理集合对象中的所有元素和复在对象的所有属性。
     * </p>
     * <p>
     * 解析过程在碰到简单类型和基本类型时终止
     * </p>
     * <p>
     * 为了避免对象的递归嵌套带来的堆栈溢出问题，使用了UnionTree类型的树，即该树中所有节点的键名具有唯一性约束。<br>
     * 使用对象本身作为节点的键名，简单对象和基本对象被包装成ObjectRef类。<br>
     * 键名的唯一性以来与对象的equals方法。
     * </p>
     * 
     * @param tree
     * @param object
     * @param arrayTitle
     */
    @SuppressWarnings("unchecked")
    protected static void addObject2Tree(Tree<Object, Object> tree, Object object, String arrayTitle) {
        if (object == null) {
            object = "";
        }
        if (!(Hibernate.isInitialized(object))) {
            return;
        }
        // 处理枚举类型
        // 用ObjectRef包装枚举类型的toString()值，并替换树节点中的key
        if (ClassTypeUtils.isEnum(object)) {
            tree.setKey(new ObjectRef(object.toString()));
        }
        // 处理异常类型
        // 用ObjectRef包装枚异常类型的类名称，并替换树节点中的key
        else if (object instanceof Throwable) {
            tree.setKey(new ObjectRef((object.getClass().getName())));
        }
        // 处理日期类型的对象
        // 用ObjectRef包装枚日期类型转换后的String值，并替换树节点中的key
        else if (ClassTypeUtils.isDate(object)) {
            DateFormat df = Application.threadDateForamt.get();
            if (df == null) {
                df = Application.defaultDateFormat;
            }
            String dateString = df.format((Date) tree.getKey()).toString();
            tree.setKey(new ObjectRef(dateString));
        }
        // 处理Map类型的对象
        else if (ClassTypeUtils.isMap(object)) {
            Map map = (Map) object;
            for (Object key : map.keySet()) {
                Object value = map.get(key);
                try {
                    String keyString = key.toString();
                    if (keyString.equals("")) {
                        keyString = EMPTY_KEY_CODE_OF_MAP;
                    }
                    Tree<Object, Object> newTree = tree.addTree(valueNotNull(value), keyString); // 将Map中的元素作为子节点加入当前对象中
                    addObject2Tree(newTree, value, arrayTitle); // 递归处理新加入的节点
                } catch (Exception e) {
                    continue;
                }
            }
        }
        // 处理Entity类型的对象
        else if (object instanceof Entity) {
            Entity entity = (Entity) object;
            for (Object key : entity.keySet()) {
                Object value = entity.get(key);
                try {
                    Tree<Object, Object> newTree = tree.addTree(valueNotNull(value), key.toString()); // 将Entity中的元素作为子节点加入当前对象中
                    addObject2Tree(newTree, value, arrayTitle); // 递归处理新加入的节点
                } catch (Exception e) {
                    continue;
                }
            }
        }
        // 处理数组类型的对象
        else if (ClassTypeUtils.isArray(object)) {
            Object[] array = (Object[]) object;
            for (Object value : array) {
                try {
                    Tree<Object, Object> newTree = tree.addTree(valueNotNull(value), arrayTitle); // 将Collection中的元素作为子节点加入当前对象中
                    addObject2Tree(newTree, value, arrayTitle); // 递归处理新加入的节点
                } catch (Exception e) {
                    continue;
                }
            }
        }
        // 处理Collection类型的对象
        else if (ClassTypeUtils.isCollection(object)) {
            Collection coll = (Collection) object;
            for (Object value : coll) {
                try {
                    Tree<Object, Object> newTree = tree.addTree(valueNotNull(value), arrayTitle); // 将Collection中的元素作为子节点加入当前对象中
                    addObject2Tree(newTree, value, arrayTitle); // 递归处理新加入的节点
                } catch (Exception e) {
                    continue;
                }
            }
        }
        // 处理简单类型、基本类型
        // 用ObjectRef包装简单类型和基本类型，并替换树节点中的key
        else if (ClassTypeUtils.isBase(object) || ClassTypeUtils.isSimple(object)) {
            tree.setKey(new ObjectRef(object));
        }
        // 处理复杂类型的对象
        else {
            try {
                Map<String, Object> map = BeanUtils.complexObject2Map(object); // 使用反射获得复杂对象的属性
                tree.setKey(map); // 用属性Map替换树节点中的复杂对象
                addObject2Tree(tree, map, arrayTitle); // 继续处理当前节点
            } catch (Exception e) {
            }
        }

        return;
    }

    protected static Object valueNotNull(Object value) {
        return (value == null) ? new ObjectRef("") : value;
    }

    @SuppressWarnings("unchecked")
    protected static void parsePersistentSet(Tree<Object, Object> tree, Object object, String arrayTitle) {
        Set set = (Set) object;
        LinkedTree<Object, Object> parentTree = ((LinkedTree) tree).parent;

        Map<String, Object> childrenMap = new HashMap<String, Object>();
        if (Hibernate.isInitialized(set)) {
            for (Object value : set) {
                Map<String, Object> childMap = TreeUtils.parseEntity(value, (String) tree.getValue());
                for (String key : childMap.keySet()) {
                    Object v = childMap.get(key);
                    String vStr = (v == null) ? "" : v.toString();
                    String str = (String) childrenMap.get(key);
                    if (str == null) {
                        str = vStr;
                    } else {
                        str = str + "_firefly_" + vStr;
                    }
                    childrenMap.put(key, str);
                }
            }
            for (Object key : childrenMap.keySet()) {
                Object v = childrenMap.get(key);
                try {
                    Tree<Object, Object> newTree = parentTree.addTree(v, key.toString()); // 将Map中的元素作为子节点加入当前对象中
                    addObject2Tree(newTree, v, arrayTitle); // 递归处理新加入的节点
                } catch (Exception e) {
                    continue;
                }
            }
        }
    }

    protected static Map<String, Object> parseEntity(Object object, String prefix) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        if (object == null) {
            return resultMap;
        }
        Map<String, Object> map = BeanUtils.complexObject2Map(object); // 使用反射获得复杂对象的属性
        for (String key : map.keySet()) {
            Object value = map.get(key);
            if (value instanceof PersistentSet) {
                Map<String, Object> childMap = TreeUtils.parseEntity(value, prefix + "." + key);
                if (!ObjectUtils.isEmpty(childMap)) {
                    resultMap.putAll(childMap);
                }
            } else {
                resultMap.put(prefix + "." + key, value);
            }
        }
        return resultMap;
    }

    /**
     * <p>
     * 将一个含有树形关系键的对象数组转换成树对象。
     * </p>
     * 
     * @param list
     *            　数组。
     * @param keyPattern
     *            获取键名的匹配模式，通常为一个属性名称。
     * @param parentPattern
     *            获取树形关系键(指向父对象的指针)的匹配模式，通常为一个属性名称。
     * @return Tree<Object,Object> 树对象。
     */
    public static List<Tree<Object, Object>> List2Tree(List<?> list, String keyPattern, String parentPattern) {
        if (ObjectUtils.isEmpty(list)) {
            return null;
        }

        // 创建存放key的list
        List<Object> keyList = new ArrayList<Object>();

        // 创建存放key-object对的map
        Map<Object, Object> keyMap = new HashMap<Object, Object>();

        // 创建存放key-parent的map
        Map<Object, Object> parentMap = new HashMap<Object, Object>();

        // 通过BeanWrapper取得每个值对象的key和parent的值，并放入Map中
        for (Object object : list) {
            try {
                BeanWrapper objWrapper = new BeanWrapperImpl(object);
                Object key = objWrapper.getPropertyValue(keyPattern);
                Object parent = null;
                try {
                    parent = objWrapper.getPropertyValue(parentPattern);
                } catch (NullValueInNestedPathException e) {
                    // ignore the excption
                }
                keyList.add(key);
                keyMap.put(key, object);
                parentMap.put(key, parent);
            } catch (Exception e) {
                return null;
            }
        }

        // 查找根节点，parent在key集合中不存在的就是根节点
        // 如果有多个根节点，则都取回来
        List<Object> rootKeys = new ArrayList<Object>();
        for (Object key : keyList) {
            Object parent = parentMap.get(key);
            if (!parentMap.containsKey(parent)) {
                rootKeys.add(key);
            }
        }
        // 如果没有找到根节点，则返回null
        if (ObjectUtils.isEmpty(rootKeys)) {
            return null;
        }

        List<Tree<Object, Object>> treeList = new ArrayList<Tree<Object, Object>>();
        for (Object rootKey : rootKeys) {
            Tree<Object, Object> tree = new SimpleTree<Object, Object>(rootKey, keyMap.get(rootKey));
            findChildren(tree, keyList, keyMap, parentMap);
            treeList.add(tree);
        }

        return treeList;
    }

    /**
     * <p>
     * 查找并添加指定节点的子节点。
     * </p>
     * <p>
     * 这是一个递归方法。
     * </p>
     * 
     * @param tree
     *            　树对象。
     * @param keyMap
     *            key-object集合。
     * @param parentMap
     *            key-parent集合。
     */
    protected static void findChildren(Tree<Object, Object> tree, List<Object> keyList, Map<Object, Object> keyMap,
            Map<Object, Object> parentMap) {
        Object key = tree.getKey();
        // 查找并添加当前节点的直接子节点
        for (Object childKey : keyList) {
            Object childParent = parentMap.get(childKey);
            if (key.equals(childParent)) {
                try {
                    tree.addTree(childKey, keyMap.get(childKey));
                } catch (Exception e) {
                    continue;
                }
            }
        }
        if (tree.hasChildren()) {
            // 去除已添加的子节点，缩小遍历范围
            for (Tree<Object, Object> child : tree.getChildren()) {
                keyList.remove(child.getKey());
            }
            // 为当前节点的每个子节点寻找其子节点
            for (Tree<Object, Object> child : tree.getChildren()) {
                findChildren(child, keyList, keyMap, parentMap);
            }
        }
    }

    public static List<Map<String, Object>> forExtTree(List<?> list, String keyPattern, String parentPattern,
            String textPattern) {
        List<Tree<Object, Object>> treeList = List2Tree(list, keyPattern, parentPattern);
        if (ObjectUtils.isEmpty(treeList)) {
            return null;
        }
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        Map<String, String> textPatternMap = new HashMap<String, String>();
        if (StringUtils.hasText(textPattern)) {
            String[] patterns = textPattern.split(",");
            for (String pattern : patterns) {
                if (StringUtils.hasText(pattern)) {
                    String[] keyName = pattern.split(":");
                    textPatternMap.put(keyName[0], keyName[1]);
                }
            }
        }
        for (Tree<Object, Object> tree : treeList) {
            mapList.add(addExtTree(tree, textPatternMap));
        }
        return mapList;
    }

    @SuppressWarnings("unchecked")
    protected static Map<String, Object> addExtTree(Tree<Object, Object> tree, Map<String, String> textPatternMap) {

        Object object = tree.getValue();
        Map<String, Object> map = new HashMap<String, Object>();
        if (ClassTypeUtils.isMap(object)) {
            map.putAll((Map) object);
        } else {
            map.putAll(BeanUtils.complexObject2Map(object));
        }

        map.put("id", tree.getKey());
        if (!ObjectUtils.isEmpty(textPatternMap)) {
            for (String key : textPatternMap.keySet()) {
                String propName = textPatternMap.get(key);
                map.put(key, map.get(propName));
            }
        }

        if (tree.hasChildren()) {
            List<Map<String, Object>> childrenList = new ArrayList<Map<String, Object>>();
            for (Tree<Object, Object> subTree : tree.getChildren()) {
                Map<String, Object> subMap = addExtTree(subTree, textPatternMap);
                childrenList.add(subMap);
            }
            map.put("children", childrenList);
        } else {
            map.put("leaf", "true");
        }
        return map;
    }

    /**
     * 将一个包含树形关系的对象集合转换成树对象List，集合中的对象可以是POJO或以Map表示的POJO（key为属性名，value为属性值）。<br>
     * 
     * @param objects
     *            包含树形关系的对象集合，其中的元素可以是POJO或以Map表示的POJO（key为属性名，value为属性值）。
     * @param keyPropName
     *            父节点key的属性名称（子节点的parentPropName指向本属性），该属性同时也将作为生成树节点的key。
     * @param parentPropName
     *            子节点上指向父节点key的属性名称（本属性指向父节点的keyPropName）。
     * @param maxDepth
     *            深度限制。0表示只取树根，1表示取树根及第一层子节点，...。<0表示无深度限制。
     * @param filterKeys
     *            要筛选的子树key，只有该参数中的子树才会包含在返回结果中。该参数为空表示无筛选条件。<br>
     * @param filterDepths
     *            filterKeys参数对应的深度限制。0表示只取该子树根，1表示取该子树根及第一层子节点，...。<br>
     *            <0表示无深度限制。
     * @return Tree<Object,Object> 树对象List。
     */
    public static List<Tree<Object, Object>> List2Tree(List<?> objects, String keyPropName, String parentPropName,
            int maxDepth, List<?> filterKeys, List<Integer> filterDepths) {

        // 构造结果List。
        List<Tree<Object, Object>> trees = new ArrayList<Tree<Object, Object>>();

        // 如果对象集合为空，直接返回。
        if (CollectionUtils.isEmpty(objects)) {
            return trees;
        }

        // 构造存放所有对象“key属性值”的List
        List<Object> keyList = new ArrayList<Object>();
        // 构造存放所有对象“key属性值-object”对的map
        Map<Object, Object> keyMap = new HashMap<Object, Object>();
        // 构造存放所有对象“key属性值-parent属性值”的map
        Map<Object, Object> parentMap = new HashMap<Object, Object>();

        // 通过FireflyBeanWrapper取得每个对象的key属性和parent属性的值，并放入相关集合中。
        for (Object object : objects) {
            // 取得key属性和parent属性的值
            FireflyBeanWrapper objWrapper = new CommonBeanWrapper(object);
            Object key = objWrapper.getPropertyValue(keyPropName);
            Object parent = objWrapper.getPropertyValue(parentPropName);
            keyList.add(key);
            keyMap.put(key, object);
            parentMap.put(key, parent);
        }

        // 构造存放“根对象key属性值”的List。
        List<Object> rootList = new ArrayList<Object>();
        // 查找根对象，parent在key集合中不存在的就是根节点
        for (Object key : keyList) {
            Object parent = parentMap.get(key);
            if (!keyMap.containsKey(parent)) {
                rootList.add(key);
            }
        }
        // 如果没有找到根对象，直接返回。
        if (ObjectUtils.isEmpty(rootList)) {
            return trees;
        }

        // 构造树的List
        for (Object key : rootList) {
            Tree<Object, Object> tree = new SimpleTree<Object, Object>(key, keyMap.get(key));
            if (maxDepth != 0) {
                findChildren(tree, keyList, keyMap, parentMap, maxDepth);
            }
            trees.add(tree);
        }

        // 根据筛选条件查找子树。
        if (!CollectionUtils.isEmpty(filterKeys)) {
            trees = filterSubTree(trees, filterKeys, filterDepths);
        }

        return trees;

    }

    /**
     * 根据参数为指定Tree添加其子节点。
     * 
     * @param tree
     *            　树对象。
     * @param keyList
     *            key的List。
     * @param keyMap
     *            key-object集合。
     * @param parentMap
     *            key-parent集合。
     * @param maxDepth
     *            深度限制。0什么也不做，1表示添加第一层子节点，...。<0表示无深度限制。
     */
    protected static void findChildren(Tree<Object, Object> tree, List<Object> keyList, Map<Object, Object> keyMap,
            Map<Object, Object> parentMap, int maxDepth) {

        // 如果深度限制=0，则什么也不做。
        if (maxDepth == 0) {
            return;
        }

        // 查找并添加当前节点的直接子节点
        Object parentKey = tree.getKey();
        for (Object key : keyList) {
            Object parent = parentMap.get(key);
            if (parentKey.equals(parent)) {
                tree.addTree(key, keyMap.get(key));
            }
        }

        // 深度限制-1。
        if (maxDepth > 0) {
            maxDepth--;
        }

        // 继续递归添加子节点。
        if (maxDepth != 0 && tree.hasChildren()) {
            // 为当前节点的每个子节点寻找其子节点
            for (Tree<Object, Object> child : tree.getChildren()) {
                findChildren(child, keyList, keyMap, parentMap, maxDepth);
            }
        }

    }

    /**
     * 根据子树筛选条件筛选子树。
     * 
     * @param trees
     *            原始树List。
     * @param filterKeys
     *            要筛选的子树key，只有该参数中的子树才会包含在返回结果中。该参数为空表示无筛选条件。<br>
     * @param filterDepths
     *            filterKeys参数对应的深度限制。0表示只取该子树根，1表示取该子树根及第一层子节点，...。<br>
     *            <0表示无深度限制。
     * @return 符合筛选条件的子树List。
     */
    public static List<Tree<Object, Object>> filterSubTree(List<Tree<Object, Object>> trees, List<?> filterKeys,
            List<Integer> filterDepths) {

        // 依次查找子树。
        List<Tree<Object, Object>> subTrees = new ArrayList<Tree<Object, Object>>();
        for (int i = 0; i < filterKeys.size(); i++) {
            Object key = filterKeys.get(i);
            int depth = filterDepths.get(i);
            for (Tree<Object, Object> tree : trees) {
                if (tree.containsKey(key)) {
                    // 取得符合深度限制的子树。
                    subTrees.add(getSubTree(tree.find(key), depth));
                    break;
                }
            }
        }

        // 返回结果。
        return subTrees;

    }

    /**
     * 根据深度限制获得子树。
     * 
     * @param tree
     *            原始数对象。
     * @param depth
     *            深度限制。0表示只取该树根，1表示取该树根及第一层子节点，...。<0表示无深度限制。
     * @return 符合深度限制的子树对象。
     */
    protected static Tree<Object, Object> getSubTree(Tree<Object, Object> tree, int depth) {

        // 构造当前树对象的拷贝。
        Tree<Object, Object> newTree = new SimpleTree<Object, Object>(tree.getKey(), tree.getValue());

        // 如果深度限制=0，直接返回当前树对象的拷贝。
        if (depth == 0) {
            return newTree;
        }

        // 构造符合深度限制的子树。
        if (tree.hasChildren()) {
            // 深度限制-1
            if (depth > 0) {
                depth--;
            }
            for (Tree<Object, Object> children : tree.getChildren()) {
                newTree.addTree(getSubTree(children, depth));
            }
        }

        return newTree;

    }

    /**
     * 将树List转换成Map。
     * 
     * @param trees
     *            树List。
     * @param trsfFieldsPattern
     *            转义字段模板。逗号分隔不同字段，冒号分隔字段key与值（值可以是变量）。
     * @return Map的List。
     */
    public static List<Map<String, Object>> TreeList2Map(List<Tree<Object, Object>> trees, String trsfFieldsPattern) {

        // 构造结果List。
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();

        // 如果树List为空，直接返回。
        if (CollectionUtils.isEmpty(trees)) {
            return mapList;
        }

        // 构造转义字段模板Map。
        Map<String, String> trsfFieldsPatternMap = new HashMap<String, String>();
        if (StringUtils.hasText(trsfFieldsPattern)) {
            String[] patterns = trsfFieldsPattern.split(",");
            for (String pattern : patterns) {
                if (StringUtils.hasText(pattern)) {
                    String[] keyName = pattern.split(":");
                    trsfFieldsPatternMap.put(keyName[0], keyName[1]);
                }
            }
        }

        // 转换每棵树。
        for (Tree<Object, Object> tree : trees) {
            mapList.add(Tree2Map(tree, trsfFieldsPatternMap));
        }

        return mapList;

    }

    /**
     * 将树转换成Map。
     * 
     * @param tree
     *            树。
     * @param trsfFieldsPattern
     *            转义字段模板。key为字段key，value为字段值（值可以是变量）。
     * @return Map。
     */
    @SuppressWarnings("unchecked")
    protected static Map<String, Object> Tree2Map(Tree<Object, Object> tree, Map<String, String> trsfFieldsPattern) {

        // 将当前节点对象放入Map。
        Object object = tree.getValue();
        Map<String, Object> map = new HashMap<String, Object>();
        if (ClassTypeUtils.isMap(object)) {
            map.putAll((Map<String, Object>) object);
        } else {
            map.putAll(BeanUtils.complexObject2Map(object));
        }

        // 增加id属性。
        map.put("id", tree.getKey());

        // 增加children和leaf属性。
        if (tree.hasChildren()) {
            List<Map<String, Object>> childrenList = new ArrayList<Map<String, Object>>();
            for (Tree<Object, Object> subTree : tree.getChildren()) {
                Map<String, Object> subMap = Tree2Map(subTree, trsfFieldsPattern);
                childrenList.add(subMap);
            }
            map.put("children", childrenList);
            map.put("leaf", "false");
        } else {
            map.put("leaf", "true");
        }

        // 处理转义字段
        if (!CollectionUtils.isEmpty(trsfFieldsPattern)) {
            for (String key : trsfFieldsPattern.keySet()) {
                String propertyName = trsfFieldsPattern.get(key);
                map.put(key, parser.parse(propertyName, map));
            }
        }

        return map;

    }

}
