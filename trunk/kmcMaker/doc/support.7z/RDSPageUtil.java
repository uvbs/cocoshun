package com.butterfly.engine.support;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.butterfly.core.schema.model.rds.Cell;
import com.butterfly.core.schema.model.rds.HeaderCell;
import com.butterfly.core.schema.model.rds.QueryDataSet;
import com.butterfly.core.schema.model.rds.ReportDataSet;
import com.firefly.mvc.ActionContext;

public class RDSPageUtil {
	
	/**
	 * 递归遍历计数器
	 *
	 */
	static class Counter
	{
		private int counter = 0;
		public Counter(int value)
		{
			this.counter = value;
		}
		
		public void inc()
		{
			counter++;
		}
		
		public int value()
		{
			return counter;
		}
	}
	
	/**
	 * 处理QueryDataSet行头列头以及Body区的数据分页
	 * 从
	 * @param actionContext 
	 * @param object
	 */
	public static void ProcessPagination(ActionContext actionContext,
			Object object) {
		if (!(object instanceof ReportDataSet))
			return;

		ReportDataSet rds = (ReportDataSet) object;
		Map<String, QueryDataSet> map = rds.getQueryDataSets();

		for (Entry<String, QueryDataSet> entry : map.entrySet()) {
			QueryDataSet qds = entry.getValue();

			// 处理行头及Body区的Rows
			HeaderCell rowRoot = qds.getColumnRoot();
			if (rowRoot != null && rowRoot.hasChildren()) {
				// 获取row分页参数
				int rowPageSize = actionContext.getInt("rowPageSize", 2);
				int rowCurPage = actionContext.getInt("rowCurPage", 1);
				int rowCount = actionContext.getInt("rowCount");

				Pagination pagination = new Pagination(rowPageSize,
						rowCurPage, rowCount);
				HeaderCell newRowRoot = new HeaderCell();
				processHeaderCellPagination(rowRoot, newRowRoot, pagination,
						new Counter(0));
				qds.setRowRoot(newRowRoot);
				
				List<List<Cell>> rows = qds.getBody().getRows();
				List<List<Cell>> newRows = processBodyPagination(rows, pagination);
				qds.getBody().setRows(newRows);
			}

			// 处理列头及Body区的Columns
			HeaderCell colRoot = qds.getColumnRoot();
			if (colRoot != null && colRoot.hasChildren()) {
				// 获取col分页参数
				int colPageSize = actionContext.getInt("colPageSize", 2);
				int colCurPage = actionContext.getInt("colCurPage", 1);
				int colCount = actionContext.getInt("colCount");

				Pagination pagination = new Pagination(colPageSize,
						colCurPage, colCount);
				HeaderCell newColRoot = new HeaderCell();
				processHeaderCellPagination(rowRoot, newColRoot, pagination,
						new Counter(0));
				qds.setColumnRoot(newColRoot);
				List<List<Cell>> cols = qds.getBody().getRows();
				List<List<Cell>> newCols = processBodyPagination(cols, pagination);
				qds.getBody().setRows(newCols);				
			}

		}
	}
	
	private static List<List<Cell>> processBodyPagination(
			List<List<Cell>> recs, Pagination pagination) {
		List<List<Cell>> newRecs = new ArrayList<List<Cell>>();
		int recStart = pagination.getStartNum();
		int recEnd = pagination.getEndNum();
		
		if(recStart > 0 && recStart<recs.size() && recEnd>recStart && recEnd<recs.size())
		{
			for(int i = recStart; i<recs.size() && i< recEnd; i++)
			{
				newRecs.add(recs.get(i));
			}
		}
		
		return newRecs;
	}

	private static HeaderCell copyHeaderCell(HeaderCell srcHC)
	{
		HeaderCell headerCell = new HeaderCell();
		
		headerCell.setColSpan(srcHC.getColSpan());
		headerCell.setContent(srcHC.getContent());
		headerCell.setContentType(srcHC.getContentType());
		headerCell.setExpand(srcHC.isExpand());
		headerCell.setFirstBodyCell(srcHC.getFirstBodyCell());
		headerCell.setHierarchyName(srcHC.getHierarchyName());
		headerCell.setId(srcHC.getId());
		headerCell.setKey(srcHC.getKey());
		headerCell.setKeyPath(srcHC.getKeyPath());
		headerCell.setLastBodyCell(srcHC.getLastBodyCell());
		headerCell.setLeaf(srcHC.isLeaf());
		headerCell.setLevelName(srcHC.getLevelName());
		headerCell.setName(srcHC.getName());
		headerCell.setOnRow(srcHC.isOnRow());
		headerCell.setParameter(srcHC.getParameter());
		headerCell.setProperties(srcHC.getProperties());
		headerCell.setRealValue(srcHC.getRealValue());
		headerCell.setRowSpan(srcHC.getRowSpan());
		headerCell.setSetName(srcHC.getSetName());
		headerCell.setStyle(srcHC.getStyle());
		headerCell.setValue(srcHC.getValue());
		
		return headerCell;
	}
	
	
	private static void processHeaderCellPagination(HeaderCell headerRoot, HeaderCell newRoot, Pagination pagination,Counter counter)
	{
		if(headerRoot == null) return;
		
		for (HeaderCell child : headerRoot.getChildren())
		{
			// the node for include child
			if(child.hasChildren())
			{
				// copy node
				HeaderCell newChild = copyHeaderCell(child);
				newRoot.addChild(newChild);
				newRoot.setChildCount(1);
				
				processHeaderCellPagination(child, newChild, pagination, counter);
			}else // leaf
			{
				if(counter.value() >= pagination.getStartNum())
				{
					// copy node
					HeaderCell newChild = copyHeaderCell(child);
					newRoot.addChild(newChild);
				}
				
				counter.inc();
				
				if(counter.value() >= pagination.getEndNum())
					return;				
			}
		}
	}
	
	private static void printHeaderCell(HeaderCell root)
	{
		List<HeaderCell> children = root.getChildren();
		for (int i = 0; i < children.size(); i++)
		{
			HeaderCell child =  children.get(i);
			if(child.hasChildren())
				printHeaderCell(child);
			
			System.out.println( child.getKey() + " hasChildren:" + child.hasChildren());
		}
	}
	
	public static void main(String[] args) {
		HeaderCell root = new HeaderCell();
		for(int i=0;i<5;i++)
		{
			HeaderCell child = new HeaderCell("L0 : key " + i, i);
			root.addChild(child);
		}
		
		for(int i=0;i<3;i++)
		{
			HeaderCell child = new HeaderCell("L1 : key " + i, i);
			root.getChildren().get(0).addChild(child);
		}
		printHeaderCell(root);
		System.out.println();
		
//		HeaderCell newRowRoot = new HeaderCell();
//		processHeaderCellPagination(root,newRowRoot,9,0,3,new Counter(0));
//		printHeaderCell(newRowRoot);
//		System.out.println();
		
//		newRowRoot = new HeaderCell();
//		processHeaderCellPagination(root,newRowRoot,9,3,5,new Integer(0));
//		printHeaderCell(newRowRoot);
//		System.out.println();
//		
//		newRowRoot = new HeaderCell();
//		processHeaderCellPagination(root,newRowRoot,9,6,8,new Integer(0));
//		printHeaderCell(newRowRoot);
//		System.out.println();
		
	}
}
