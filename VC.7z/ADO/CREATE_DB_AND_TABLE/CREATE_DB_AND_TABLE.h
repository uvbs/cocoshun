// CREATE_DB_AND_TABLE.h : main header file for the CREATE_DB_AND_TABLE application
//

#if !defined(AFX_CREATE_DB_AND_TABLE_H__2E6ACB60_1A78_4609_911A_4674174EBEE6__INCLUDED_)
#define AFX_CREATE_DB_AND_TABLE_H__2E6ACB60_1A78_4609_911A_4674174EBEE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCREATE_DB_AND_TABLEApp:
// See CREATE_DB_AND_TABLE.cpp for the implementation of this class
//

class CCREATE_DB_AND_TABLEApp : public CWinApp
{
public:
	CCREATE_DB_AND_TABLEApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCREATE_DB_AND_TABLEApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCREATE_DB_AND_TABLEApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATE_DB_AND_TABLE_H__2E6ACB60_1A78_4609_911A_4674174EBEE6__INCLUDED_)
