// Find.cpp : implementation file
//

#include "stdafx.h"
#include "icrEdit.h"
#include "Find.h"
#include "MRUCombo.h"
#include "BtnST.h"
#include "MainFrm.h"
#include "icrEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFind dialog


CFind::CFind(CWnd* pParent /*=NULL*/)
	: CDialog(CFind::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFind)
	m_bCase = FALSE;
	m_bWholeWord = FALSE;
	m_strEdit = _T("");
	//}}AFX_DATA_INIT
}


void CFind::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFind)
	DDX_Control(pDX, IDC_RETURN, m_cmdReturn);
	DDX_Control(pDX, IDC_FIND, m_cmdFind);
	DDX_Control(pDX, IDC_CMBSTRING, m_cmbstring);
	DDX_Control(pDX, IDC_CHKWORD, m_chkword);
	DDX_Control(pDX, IDC_CHKCASE, m_chkcase);
	DDX_Check(pDX, IDC_CHKCASE, m_bCase);
	DDX_Check(pDX, IDC_CHKWORD, m_bWholeWord);
	DDX_CBString(pDX, IDC_CMBSTRING, m_strEdit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFind, CDialog)
	//{{AFX_MSG_MAP(CFind)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_RETURN, OnReturn)
	ON_BN_CLICKED(IDC_FIND, OnFind)
	ON_BN_CLICKED(IDC_CHKWORD, OnChkword)
	ON_BN_CLICKED(IDC_CHKCASE, OnChkcase)
	ON_BN_CLICKED(IDC_RADIODOWN, OnRadiodown)
	ON_BN_CLICKED(IDC_RADIOUP, OnRadioup)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFind message handlers

BOOL CFind::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CWinApp *app = AfxGetApp();
	
	CRect rect,rect1;
	GetWindowRect(&rect);
	m_chkcase.GetWindowRect(&rect1);
	int height=rect1.bottom - rect.top + 15;
	int width=rect.Width(); 
	rect.left = app->GetProfileInt(_T("CFind"), _T("left"), 114);
	rect.top = app->GetProfileInt(_T("CFind"), _T("top"), 91);
	rect.right = rect.left + width;
	rect.bottom = rect.top + height;
	MoveWindow(&rect);	
	
	m_cmdFind.SetIcon(IDI_FIND); 
	m_cmdReturn.SetIcon(IDI_CANCEL); 
	
	m_cmbstring.SetMRURegKey ( _T("cmbFind MRU") );
	m_cmbstring.SetMRUValueFormat ( _T("File #%d") );
    m_cmbstring.SetAutoRefreshAfterAdd ( TRUE );
    m_cmbstring.SetAutoSaveAfterAdd ( TRUE );
    m_cmbstring.LoadMRU();
    m_cmbstring.RefreshCtrl();

	m_bWholeWord = app->GetProfileInt(_T("CFind"), _T("WholeWord"), 0);	
	m_bCase = app->GetProfileInt(_T("CFind"), _T("Case"), 0);	
	m_strEdit = app->GetProfileString(_T("CFind"), _T("str"), 0);	
	
	UpdateData(FALSE);

	int ndirection = app->GetProfileInt(_T("CFind"), _T("Direction"), 1);
	if(ndirection==1)
		CheckDlgButton (IDC_RADIODOWN, BST_CHECKED);
	else
		CheckDlgButton (IDC_RADIOUP, BST_CHECKED);

	return FALSE; 
}

void CFind::OnDestroy() 
{
	CRect rect;
	GetWindowRect(&rect);
	CWinApp *app = AfxGetApp();
	app->WriteProfileInt(_T("CFind"), _T("left"), rect.left);  
	app->WriteProfileInt(_T("CFind"), _T("top"), rect.top);
	app->WriteProfileInt(_T("CFind"), _T("right"), rect.right);
	app->WriteProfileInt(_T("CFind"), _T("bottom"), rect.bottom);

	CDialog::OnDestroy();
}

void CFind::OnReturn() 
{
	CDialog::OnCancel(); 	
}

void CFind::OnFind() 
{
	UpdateData(TRUE);
	if(m_strEdit.IsEmpty())
		return;

	CWinApp *app = AfxGetApp();
	m_cmbstring.AddToMRU(m_strEdit); 
	app->WriteProfileString(_T("CFind"), _T("str"), m_strEdit);		

	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView=(CIcrEditView *)mainfrm->GetActiveView();
	CRichEditCtrl &edit = icrEditView->GetRichEditCtrl();

	int dwFlags = 0;
	if(m_bCase)
		dwFlags|=FR_MATCHCASE;
	if(m_bWholeWord)
		dwFlags|=FR_WHOLEWORD;
	BOOL bdown = IsDlgButtonChecked(IDC_RADIODOWN)==BST_CHECKED;
	if(bdown)
		dwFlags |= FR_DOWN;

	CHARRANGE cr;
	edit.GetSel(cr); 
	FINDTEXTEX *ft = new FINDTEXTEX[1];
	if(bdown) {
		ft->chrg.cpMin = cr.cpMin+1; 
		ft->chrg.cpMax = -1;// search through end of the text 
	}
	else {
		ft->chrg.cpMin = cr.cpMin-1; 
		ft->chrg.cpMax = -1;// search through end of the text 
	}
	
	TCHAR *t = new TCHAR[m_strEdit.GetLength()+1];
	strcpy(t, m_strEdit);
	ft->lpstrText = t;
		
	int nPos = edit.SendMessage(EM_FINDTEXTEX, dwFlags, (LPARAM)ft); 

	if(nPos!=-1) {
		edit.SetSel(ft->chrgText.cpMin, ft->chrgText.cpMax); 
		icrEditView->AdjustDialogPosition((CDialog *)this);
		icrEditView->ShowWindow(SW_HIDE); 
		icrEditView->SetFocus(); 
		icrEditView->ShowWindow(SW_SHOW);
		SetFocus();
	}
	else {
		CString strShow;
		if(bdown)
			strShow.Format(_T("Cannot find the string: \"%s\", search again from the beginning?"), m_strEdit);
		else
			strShow.Format(_T("Cannot find the string: \"%s\", search again from the end?"), m_strEdit);
		if(MessageBox(strShow, _T(""), MB_ICONINFORMATION|MB_YESNO)==IDYES)
		{
			if(bdown) {
				icrEditView->GetRichEditCtrl().SetSel(0, 0); 
				icrEditView->SetFocus(); 
			}
			else {
				icrEditView->ShowWindow(SW_HIDE); 
				icrEditView->GetRichEditCtrl().SetSel(0, -1); 
				icrEditView->SetFocus(); 
				icrEditView->ShowWindow(SW_SHOW);
				CHARRANGE cr;
				icrEditView->GetRichEditCtrl().GetSel(cr); 
				icrEditView->GetRichEditCtrl().SetSel(cr.cpMax, cr.cpMax); 
			}
			OnFind();
			if(t)
				delete t;
			if(ft)
				delete ft;
			return;
		}
	}
	if(t)
		delete t;
	if(ft)
		delete ft;
}

void CFind::OnChkword() 
{
	UpdateData(TRUE);
	CWinApp *app = AfxGetApp();
	app->WriteProfileInt(_T("CFind"), _T("WholeWord"), m_bWholeWord);		
}

void CFind::OnChkcase() 
{
	UpdateData(TRUE);
	CWinApp *app = AfxGetApp();
	app->WriteProfileInt(_T("CFind"), _T("Case"), m_bCase);		
}

BOOL CFind::IsVisible()
{
	if(!IsOpen())
		return FALSE;
	WINDOWPLACEMENT winS;
	GetWindowPlacement(&winS);
	if(winS.showCmd == SW_SHOW)
		return TRUE;
	else
		return FALSE;
}

BOOL CFind::IsOpen()
{
	return(m_hWnd?TRUE:FALSE);
}



BOOL CFind::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message ==  WM_KEYDOWN && (int)pMsg->wParam==VK_RETURN) {
		if(pMsg->hwnd != m_cmdReturn.m_hWnd) 
			OnFind();
		else
			::PostMessage(pMsg->hwnd, BM_CLICK, 0, 0xa00a); 

		return TRUE;
	}

	return CDialog::PreTranslateMessage(pMsg);		
}

void CFind::OnRadiodown() 
{
	BOOL bcheck = IsDlgButtonChecked(IDC_RADIODOWN)==BST_CHECKED;

	CWinApp *app = AfxGetApp();
	if(bcheck)
		app->WriteProfileInt(_T("CFind"), _T("Direction"), 1);
	else
		app->WriteProfileInt(_T("CFind"), _T("Direction"), 0);
}

void CFind::OnRadioup() 
{
	BOOL bcheck = IsDlgButtonChecked(IDC_RADIOUP)==BST_CHECKED;

	CWinApp *app = AfxGetApp();
	if(bcheck)
		app->WriteProfileInt(_T("CFind"), _T("Direction"), 0);
	else
		app->WriteProfileInt(_T("CFind"), _T("Direction"), 1);
}

