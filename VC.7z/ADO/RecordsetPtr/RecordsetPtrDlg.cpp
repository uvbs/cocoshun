// RecordsetPtrDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RecordsetPtr.h"
#include "RecordsetPtrDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecordsetPtrDlg dialog

CRecordsetPtrDlg::CRecordsetPtrDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRecordsetPtrDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRecordsetPtrDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRecordsetPtrDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRecordsetPtrDlg)
	DDX_Control(pDX, IDC_LIST1, m_list1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRecordsetPtrDlg, CDialog)
	//{{AFX_MSG_MAP(CRecordsetPtrDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_READREC, OnBtnReadrec)
	ON_BN_CLICKED(IDC_BTN_CHANGE, OnBtnChange)
	ON_BN_CLICKED(IDC_BTN_NEW, OnBtnNew)
	ON_BN_CLICKED(IDC_BTN_DELETE, OnBtnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecordsetPtrDlg message handlers

BOOL CRecordsetPtrDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRecordsetPtrDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRecordsetPtrDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRecordsetPtrDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CRecordsetPtrDlg::OnBtnReadrec() 
{
	_ConnectionPtr m_pConnection;
	
	_RecordsetPtr m_pRecordset;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}

	try
	{
		m_pRecordset.CreateInstance("ADODB.Recordset");
		m_pRecordset->Open("SELECT EmployeeID,FirstName,LastName,HireDate,City FROM Employees WHERE City='London'",
			_variant_t((IDispatch*)m_pConnection,true),
			adOpenStatic,
			adLockOptimistic,
			adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	_variant_t vEmployeeID,vFirstName,vLastName,vHireDate,vCity;

	try
	{
		while(!m_pRecordset->adoEOF)
		{
			vEmployeeID=m_pRecordset->GetCollect(_variant_t((long)0));
		    //ȡ�õ�1�е�ֵ����0��ʼ��������Ҳ����ֱ���г��е����ƣ�����һ��

			vFirstName=m_pRecordset->GetCollect("FirstName");
			vLastName=m_pRecordset->GetCollect("LastName");
			vHireDate=m_pRecordset->GetCollect("HireDate");
			vCity=m_pRecordset->GetCollect("City");

			CString strtemp;
			if(vEmployeeID.vt!=VT_NULL)
			{
				strtemp.Format("%d",vEmployeeID.lVal);
			}

			if(vFirstName.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vFirstName;
			}

			if(vLastName.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vLastName;
			}

			if(vHireDate.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vHireDate;
			}

			if(vCity.vt!=VT_NULL)
			{
				strtemp+="      ";
				strtemp+=(LPCTSTR)(_bstr_t)vCity;
			}

			m_list1.AddString(strtemp);
			
			m_list1.AddString("\n");

			m_pRecordset->MoveNext();
		}
		
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	m_pRecordset->Close();
	m_pRecordset=NULL;
	m_pConnection->Close();	
	m_pConnection=NULL;	
}


void CRecordsetPtrDlg::OnBtnChange() 
{
	_ConnectionPtr m_pConnection;
	
	_RecordsetPtr m_pRecordset;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}

	try
	{
		m_pRecordset.CreateInstance("ADODB.Recordset");
		m_pRecordset->Open("SELECT EmployeeID,FirstName,LastName,HireDate,City FROM Employees WHERE (City='London') AND (EmployeeID=6)",
			_variant_t((IDispatch*)m_pConnection,true),
			adOpenStatic,
			adLockOptimistic,
			adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	try
	{
		while(!m_pRecordset->adoEOF)
		{
			m_pRecordset->PutCollect("LastName",_variant_t("Jackson"));
			m_pRecordset->MoveNext();
		}
		m_pRecordset->Update();
	}
	catch(_com_error* e)
	{
		AfxMessageBox(e->ErrorMessage());
	}
	
	m_pRecordset->Close();
	m_pRecordset=NULL;
	m_pConnection->Close();	
	m_pConnection=NULL;
}



void CRecordsetPtrDlg::OnBtnNew() 
{
	_ConnectionPtr m_pConnection;
	
	_RecordsetPtr m_pRecordset;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}

	try
	{
		m_pRecordset.CreateInstance("ADODB.Recordset");
		m_pRecordset->Open("SELECT * FROM Employees",
			_variant_t((IDispatch*)m_pConnection,true),
			adOpenStatic,
			adLockOptimistic,
			adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	try
	{
		m_pRecordset->MoveLast();
		m_pRecordset->AddNew();
		m_pRecordset->PutCollect("EmployeeID",_variant_t((long)10));
		m_pRecordset->PutCollect("FirstName",_variant_t("Mary"));
		m_pRecordset->PutCollect("LastName",_variant_t("Williams"));
		m_pRecordset->PutCollect("HireDate",_variant_t("15/4/1993 12:00:00"));
		m_pRecordset->PutCollect("City",_variant_t("New York"));
		m_pRecordset->PutCollect("Country",_variant_t("USA"));

	}
	
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}
	
	m_pRecordset->Update();

	m_pRecordset->Close();
	m_pRecordset=NULL;
	m_pConnection->Close();	
	m_pConnection=NULL;

}

void CRecordsetPtrDlg::OnBtnDelete() 
{
	_ConnectionPtr m_pConnection;
	
	_RecordsetPtr m_pRecordset;

	try
	{
		m_pConnection.CreateInstance(__uuidof(Connection));
		m_pConnection->Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Northwind.mdb","","",adModeUnknown);
	}
	catch(_com_error e)
	{
		CString errormessage;
    	errormessage.Format("�������ݿ�ʧ��!\r������Ϣ:%s",e.ErrorMessage());
    	AfxMessageBox(errormessage);
    	return;
	}

	try
	{
		m_pRecordset.CreateInstance("ADODB.Recordset");
		m_pRecordset->Open("SELECT * FROM Employees",
			_variant_t((IDispatch*)m_pConnection,true),
			adOpenStatic,
			adLockOptimistic,
			adCmdText);
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.Description());
	}

	try
	{
		//����ɾ����10����¼
		m_pRecordset->MoveFirst();
		m_pRecordset->Move(9);
		m_pRecordset->Delete(adAffectCurrent);
		//����adAffectCurrentΪɾ����ǰ��¼
		m_pRecordset->Update();
	}
	catch(_com_error *e)
	{
		AfxMessageBox(e->ErrorMessage());
	}

	m_pRecordset->Close();
	m_pRecordset=NULL;
	m_pConnection->Close();	
	m_pConnection=NULL;	
}
