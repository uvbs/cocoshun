#include "Main.h"

int main()
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string stNoSpaces = "abcd1234";
	string stSpaces = "     abcd1234    ";
	string stNumbers = "1234";

	char chNoSpaces[] = "abcd1234";
	char chSpaces[] = "     abcd1234    ";
	char chNumbers[] = "1234";

	string *stRet;
	LPCTSTR chRet = "";
	BOOL bRet = FALSE;
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	/*__--==IsNumeric Functions==--__*/

	bRet = IsNumeric(&stNumbers);
	if (bRet == TRUE)
		cout << stNumbers << " is numeric\r\n";

	bRet = IsNumeric(chNumbers);
	if (bRet == TRUE)
		cout << stNumbers << " is numeric\r\n";

	bRet = IsNumeric(&stNoSpaces);
	if (bRet == FALSE)
		cout << stNoSpaces << " isnt numeric\r\n";

	bRet = IsNumeric(chNoSpaces);
	if (bRet == FALSE)
		cout << stNoSpaces << " isnt numeric\r\n";

	/*__--==Upcase Functions==--__*/

	cout << stNoSpaces << " before Upcase ";
	Upcase(&stNoSpaces);
	cout << stNoSpaces << " after Upcase\r\n";

	cout << chNoSpaces << " before Upcase ";
	Upcase(chNoSpaces);
	cout << chNoSpaces << " after Upcase\r\n";

	/*__--==Lowercase Functions==--__*/

	cout << stNoSpaces << " before Lowercase ";
	Lowercase(&stNoSpaces);
	cout << stNoSpaces << " after Lowercase\r\n";

	cout << chNoSpaces << " before Lowercase ";
	Lowercase(chNoSpaces);
	cout << chNoSpaces << " after Lowercase\r\n";

	/*__--==Trim Functions==--__*/

	cout << stSpaces << " before Trim ";
	Trim(&stSpaces);
	cout << stSpaces << " after Trim\r\n";

	cout << chSpaces << " before Trim ";
	Trim(chSpaces);
	cout << chSpaces << " after Trim\r\n";

	stSpaces = "     abcd1234    ";
	strcpy(chSpaces, "     abcd1234    ");

	/*__--==RTrim Functions==--__*/

	cout << stSpaces << " before RTrim ";
	RTrim(&stSpaces);
	cout << stSpaces << " after RTrim\r\n";

	cout << chSpaces << " before RTrim ";
	RTrim(chSpaces);
	cout << chSpaces << " after RTrim\r\n";

	stSpaces = "     abcd1234    ";
	strcpy(chSpaces, "     abcd1234    ");

	/*__--==LTrim Functions==--__*/

	cout << stSpaces << " before LTrim ";
	LTrim(&stSpaces);
	cout << stSpaces << " after LTrim\r\n";

	cout << chSpaces << " before LTrim ";
	LTrim(chSpaces);
	cout << chSpaces << " after LTrim\r\n";

	/*__--==right Functions==--__*/

	cout << stNoSpaces << " before right ";
	stRet = right(&stNoSpaces,4);
	cout << *stRet << " after right\r\n";

	cout << chNoSpaces << " before right ";
	cout << right(chNoSpaces,4) << " after right\r\n";

	/*__--==left Functions==--__*/

	cout << stNoSpaces << " before left ";
	stRet = left(&stNoSpaces,4);
	cout << *stRet << " after left\r\n";

	cout << chNoSpaces << " before left ";
	cout << left(chNoSpaces,4) << " after left\r\n";

	/*__--==mid Functions==--__*/

	cout << stNoSpaces << " before mid ";
	stRet = mid(&stNoSpaces,3,2);
	cout << *stRet << " after mid\r\n";

	cout << chNoSpaces << " before mid ";
	cout << mid(chNoSpaces,3,2) << " after mid\r\n";

	cout << "\r\n";
}