// DirectoryString.h: interface for the CDirectoryString class.
//
// CDirectorySting. A subclassed CString to contain directory
// names. Two services are provided:
//
// 1. The path is always correctly terminated, saves you having to check
// for the last backslash character
// 
// 2. Includes 4 macro's for obtaining the windows directory,
// the system directory, the current directory or a directory
// name based on the date. Eg. CDirectoryString dir=[windowsdir]temp;
// will automatically be changed to c:\windows\temp\
//
// Copyright Richard Brock, 1998
// If you can improve on the code, great, if you would be so kind
// as to let me have a copy of your changes, I would appreciate it.
//
// Feel free to use and distribute. May not be sold for profit. 


#if !defined(AFX_DIRECTORYSTRING_H__9255A1E2_159D_11D2_8CBB_00C0DFAAC78E__INCLUDED_)
#define AFX_DIRECTORYSTRING_H__9255A1E2_159D_11D2_8CBB_00C0DFAAC78E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CDirectoryString : public CString  
{
	public:
		CDirectoryString();
		CDirectoryString(const CString& stringSrc);
		CDirectoryString(LPCTSTR lpsz);
		CDirectoryString(LPCWSTR lpsz);
		virtual ~CDirectoryString();
		const CString& operator=(const CString& stringSrc);
		const CString& operator=(LPCTSTR lpsz);
		const CString& operator+=(LPCTSTR lpsz);
		const CString& operator+=(TCHAR ch);
		const CString& operator+=(const CString& string);
		void GetWindowsDirectory();
		void GetSystemDirectory();
		void GetCurrentDirectory();
		void GetDateDirectory();
		void Fixate();
		void ProcessMacros(const char* szSrc);
	protected:
		void ExpandMacro(char* pchMacroString);
		int GetMacroIndex(char* pchMacroString);
		void Concat(const char* pchString);
		void GetDateString(char* pchBuffer);
};

#endif // !defined(AFX_DIRECTORYSTRING_H__9255A1E2_159D_11D2_8CBB_00C0DFAAC78E__INCLUDED_)
