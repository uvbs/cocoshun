// DirectoryString.cpp: implementation of the CDirectoryString class.
//
// DirectoryString.h: interface for the CDirectoryString class.
//
// CDirectorySting. A subclassed CString to contain directory
// names.
//
// Examples:
// CDirectoryString dir1="c:\test"  will automatically be changed to c:\test\
// CDirectoryString dir2="c:\outbox\[datedir]" will result in c:\outbox\08061998\
//
// Copyright Richard Brock, 1998
// If you can improve on the code, great, if you would be so kind
// as to let me have a copy of your changes, I would appreciate it.
//
// Feel free to use and distribute. May not be sold for profit. 
//
// valid macros:
//  [windowsdir]
//  [systemdir]
//  [currentdir]
//  [datedir]

#include "stdafx.h"
#include "DirectoryString.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDirectoryString::CDirectoryString()
{
}

CDirectoryString::CDirectoryString(const CString& stringSrc)
{
	ProcessMacros(stringSrc);
}

CDirectoryString::CDirectoryString(LPCTSTR lpsz)
{
	ProcessMacros(lpsz);
}

CDirectoryString::CDirectoryString(LPCWSTR lpsz)
{
	CString::CString(lpsz);
	ProcessMacros(m_pchData);
}

CDirectoryString::~CDirectoryString()
{
}

const CString& CDirectoryString::operator=(const CString& stringSrc)
{	
	ProcessMacros(stringSrc);
	return *this;
}

const CString& CDirectoryString::operator=(LPCTSTR lpsz)
{	
	ProcessMacros(lpsz);
	return *this;
}

const CString& CDirectoryString::operator+=(LPCTSTR lpsz)
{
	*(CString*)this+=(lpsz);
	ProcessMacros(m_pchData);
	return *this;
}

const CString& CDirectoryString::operator+=(TCHAR ch)
{
	*(CString*)this+=(ch);
	ProcessMacros(m_pchData);
	return *this;
}

const CString& CDirectoryString::operator+=(const CString& string)
{
	*(CString*)this+=(string);
	ProcessMacros(m_pchData);
	return *this;
}

void CDirectoryString::ProcessMacros(const char* szSrc)
{
	if(!szSrc)
	{
		return;
	}
	int nOriginalLength=strlen(szSrc);

	char* pchOriginal=new char[nOriginalLength+1];
	strcpy(pchOriginal,szSrc);
	Release();

	char* pchAnchor=pchOriginal;
	char* pchLead=strchr(pchOriginal,'[');
	while(pchLead)
	{
		if(pchLead!=pchAnchor)
		{
			pchLead[0]=0;
			Concat(pchAnchor);
			pchLead[0]='[';
		}
		pchAnchor=pchLead;
		//scan through to the end of macro
		pchLead=strchr(pchLead,']');
		if(pchLead)
		{
			pchLead[0]=0;
			pchAnchor++;
			ExpandMacro(pchAnchor);
			pchLead[0]=']';
			pchAnchor=pchLead;
			pchAnchor++;
			pchLead=strchr(pchLead,'[');
		}
		else
		{
			break;
		}
	}
	if(strlen(pchAnchor))
	{
		Concat(pchAnchor);
	}
	delete[] pchOriginal;
	Fixate();
}

void CDirectoryString::ExpandMacro(char* pchMacroString)
{
	if(pchMacroString)
	{
		char szTemp[MAX_PATH];
		switch(GetMacroIndex(pchMacroString))
		{
			case 0:
				::GetWindowsDirectory(szTemp,MAX_PATH);
				break;
			case 1:
				::GetSystemDirectory(szTemp,MAX_PATH);
				break;
			case 2:
				::GetCurrentDirectory(MAX_PATH,szTemp);
				break;
			case 3:
				GetDateString(szTemp);
				break;
			default:
				//unknown macro, return
				return;
		}
		if(szTemp[strlen(szTemp)-1]!=92)
		{
			strcat(szTemp,"\\");
		}
		Concat(szTemp);
	}
}

void CDirectoryString::Concat(const char* pchString)
{
	CStringData* pOldData = GetData();
	ConcatCopy(GetData()->nDataLength, m_pchData, strlen(pchString),pchString);
	ASSERT(pOldData != NULL);
	CString::Release(pOldData);
}

void CDirectoryString::GetWindowsDirectory()
{
	char szTemp[MAX_PATH];
	::GetWindowsDirectory(szTemp,MAX_PATH);
	*this=szTemp;
	Fixate();
}

void CDirectoryString::GetSystemDirectory()
{
	char szTemp[MAX_PATH];
	::GetSystemDirectory(szTemp,MAX_PATH);
	*this=szTemp;
	Fixate();
}

void CDirectoryString::GetCurrentDirectory()
{
	char szTemp[MAX_PATH];
	::GetCurrentDirectory(MAX_PATH,szTemp);
	*this=szTemp;
	Fixate();
}

void CDirectoryString::GetDateDirectory()
{
	char szTemp[MAX_PATH];
	GetDateString(szTemp);
	*this=szTemp;
	Fixate();
}

void CDirectoryString::GetDateString(char* pchBuffer)
{
	if(!pchBuffer)
	{
		return;
	}
	char szTemp[5];
	SYSTEMTIME now;
	GetLocalTime(&now);
	sprintf(pchBuffer,"%02d",now.wDay);
	sprintf(szTemp,"%02d",now.wMonth);
	strcat(pchBuffer,szTemp);
	sprintf(szTemp,"%04d",now.wYear);
	strcat(pchBuffer,szTemp);
}

void CDirectoryString::Fixate()
{
	if(m_pchData[GetLength()-1]!=92)
	{
		*this+="\\";	
	}
}

int CDirectoryString::GetMacroIndex(char* pchMacroString)
{
	if(!pchMacroString)
	{
		return -1;
	}
	if(strcmp(pchMacroString,"windowsdir")==0)
	{
		return 0;
	}
	if(strcmp(pchMacroString,"systemdir")==0)
	{
		return 1;
	}
	if(strcmp(pchMacroString,"currentdir")==0)
	{
		return 2;
	}
	if(strcmp(pchMacroString,"datedir")==0)
	{
		return 3;
	}
	return -1;
}