// ConnPtr_Open_ExeDlg.h : header file
//

#if !defined(AFX_CONNPTR_OPEN_EXEDLG_H__C34EA7C9_F749_47D2_B3CA_E68CCCD35E2E__INCLUDED_)
#define AFX_CONNPTR_OPEN_EXEDLG_H__C34EA7C9_F749_47D2_B3CA_E68CCCD35E2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CConnPtr_Open_ExeDlg dialog

class CConnPtr_Open_ExeDlg : public CDialog
{
// Construction
public:
	CConnPtr_Open_ExeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CConnPtr_Open_ExeDlg)
	enum { IDD = IDD_CONNPTR_OPEN_EXE_DIALOG };
	CListBox	m_list1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnPtr_Open_ExeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CConnPtr_Open_ExeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnInsertInto();
	afx_msg void OnBtnUpdate();
	afx_msg void OnBtnSelect();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNPTR_OPEN_EXEDLG_H__C34EA7C9_F749_47D2_B3CA_E68CCCD35E2E__INCLUDED_)
