// CntrItem.cpp : implementation of the CDemoEditorCntrItem class
//

#include "stdafx.h"
#include "DemoEditor.h"

#include "DemoEditorDoc.h"
#include "DemoEditorView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorCntrItem implementation

IMPLEMENT_SERIAL(CDemoEditorCntrItem, CRichEditCntrItem, 0)

CDemoEditorCntrItem::CDemoEditorCntrItem(REOBJECT* preo, CDemoEditorDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CDemoEditorCntrItem::~CDemoEditorCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CDemoEditorCntrItem diagnostics

#ifdef _DEBUG
void CDemoEditorCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CDemoEditorCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
