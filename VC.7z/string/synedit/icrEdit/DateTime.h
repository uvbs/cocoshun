#if !defined(AFX_DATETIME_H__A2C00381_8183_11D6_AB29_B064B91FC37D__INCLUDED_)
#define AFX_DATETIME_H__A2C00381_8183_11D6_AB29_B064B91FC37D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DateTime.h : header file
//

#include "BtnST.h"

/////////////////////////////////////////////////////////////////////////////
// CDateTime dialog

class CDateTime : public CDialog
{
// Construction
public:
	CDateTime(CWnd* pParent = NULL);   // standard constructor

// Attributes
	static SYSTEMTIME m_time;
	static LCID m_id;
	static CListBox* m_pListBox;
	static BOOL CALLBACK DateFmtEnumProc(LPTSTR lpszFormatString);
	static BOOL CALLBACK TimeFmtEnumProc(LPTSTR lpszFormatString);

// Dialog Data
	//{{AFX_DATA(CDateTime)
	enum { IDD = IDD_DIALOGDATATIME };
	CButtonST	m_cmdCancel;
	CButtonST	m_cmdOk;
	CListBox	m_listBox;
	CString m_strSel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDateTime)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDateTime)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkDatedialogList();
	virtual void OnCancel();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATETIME_H__A2C00381_8183_11D6_AB29_B064B91FC37D__INCLUDED_)
