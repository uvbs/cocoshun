#if !defined(AFX_REPLACE_H__04B128E3_3EAB_4CAC_803D_360263C8F5C7__INCLUDED_)
#define AFX_REPLACE_H__04B128E3_3EAB_4CAC_803D_360263C8F5C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Replace.h : header file
//
#include "MRUCombo.h"
#include "BtnST.h"
#include "FlatCheckBox.h"

/////////////////////////////////////////////////////////////////////////////
// CReplace dialog

class CReplace : public CDialog
{
// Construction
public:
	BOOL IsVisible();
	BOOL IsOpen();
	CReplace(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CReplace)
	enum { IDD = IDD_REPLACE };
	CMRUComboBox m_cmb2;
	CMRUComboBox m_cmb1;
	CFlatCheckBox	m_chkword;
	CFlatCheckBox	m_chkcase;
	CButtonST m_cmdreplaceall;
	CButtonST m_cmdreplace;
	CButtonST m_cmdnext;
	CButtonST m_cmdcancel;
	BOOL	m_chkcasevalue;
	BOOL	m_chkwordvalue;
	CString	m_cmb1string;
	CString	m_cmb2string;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplace)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReplace)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnCancel();
	afx_msg void OnFindnext();
	afx_msg void OnChkword();
	afx_msg void OnChkcase();
	afx_msg void OnReplace();
	afx_msg void OnReplaceall();
	afx_msg void OnRadiosel();
	afx_msg void OnRadiowhole();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLACE_H__04B128E3_3EAB_4CAC_803D_360263C8F5C7__INCLUDED_)

