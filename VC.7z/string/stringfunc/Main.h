/***************************************************************************
  Name:			Main.h
  Version:		1.0
  Date Created: 3/20/2002
  Description:  Header file for Main.cpp
				Main is the starting file for our program

  Notes:		None

  Owner:		Technocrat(technocrat@usa.com)
 ***************************************************************************/

#ifndef __MAIN_H__
#define __MAIN_H__

/*-----------------------------*/
			//Include

#include <Windows.h>

#include "StringFunctions.h"

/*-----------------------------*/
			//Global Functions

int main();

/*-----------------------------*/
			//Global VARs

/*-----------------------------*/

#endif