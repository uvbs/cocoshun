// icrEditDoc.cpp : implementation of the CIcrEditDoc class
//

#include "stdafx.h"
#include "icrEdit.h"

#include "icrEditDoc.h"
#include "icrEditView.h"
#include "Mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIcrEditDoc

IMPLEMENT_DYNCREATE(CIcrEditDoc, CDocument)

BEGIN_MESSAGE_MAP(CIcrEditDoc, CDocument)
	//{{AFX_MSG_MAP(CIcrEditDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIcrEditDoc construction/destruction

CIcrEditDoc::CIcrEditDoc()
{
	// TODO: add one-time construction code here

}

CIcrEditDoc::~CIcrEditDoc()
{
}


/////////////////////////////////////////////////////////////////////////////
// CIcrEditDoc serialization

void CIcrEditDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CIcrEditDoc diagnostics

#ifdef _DEBUG
void CIcrEditDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CIcrEditDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIcrEditDoc commands

