// ADOXCreateDatabaseDlg.h : header file
//

#if !defined(AFX_ADOXCREATEDATABASEDLG_H__F287B388_09DC_428B_BFC9_CBF805C26913__INCLUDED_)
#define AFX_ADOXCREATEDATABASEDLG_H__F287B388_09DC_428B_BFC9_CBF805C26913__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CADOXCreateDatabaseDlg dialog

class CADOXCreateDatabaseDlg : public CDialog
{
// Construction
public:
	CADOXCreateDatabaseDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CADOXCreateDatabaseDlg)
	enum { IDD = IDD_ADOXCREATEDATABASE_DIALOG };
	CString	m_dbName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CADOXCreateDatabaseDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CADOXCreateDatabaseDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnCreate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADOXCREATEDATABASEDLG_H__F287B388_09DC_428B_BFC9_CBF805C26913__INCLUDED_)
