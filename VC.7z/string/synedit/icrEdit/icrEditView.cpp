// icrEditView.cpp : implementation of the CIcrEditView class
//

#include "stdafx.h"
#include "icrEdit.h"

#include "icrEditDoc.h"
#include "icrEditView.h"
#include "Mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView

IMPLEMENT_DYNCREATE(CIcrEditView, CSynEditView)

BEGIN_MESSAGE_MAP(CIcrEditView, CSynEditView)
	//{{AFX_MSG_MAP(CIcrEditView)
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CSynEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CSynEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CSynEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView construction/destruction

CIcrEditView::CIcrEditView()
{
	// TODO: add construction code here

}

CIcrEditView::~CIcrEditView()
{
}

BOOL CIcrEditView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CSynEditView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView drawing

void CIcrEditView::OnDraw(CDC* pDC)
{
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView printing

BOOL CIcrEditView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CIcrEditView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CIcrEditView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView diagnostics

#ifdef _DEBUG

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CIcrEditView message handlers

LRESULT CIcrEditView::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CSynEditView::WindowProc(message, wParam, lParam);
}

void CIcrEditView::ShowCursorPosition()
{
	long start, end;
	CRichEditCtrl& richctrl = GetRichEditCtrl();
	richctrl.GetSel(start, end);
	long row = richctrl.LineFromChar(start);
	long column = start - richctrl.LineIndex(row);
	CString strShow;
	strShow.Format(_T("Ln:%d, Col:%d"), row+1, column+1);
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CStatusBarCtrl &statusCtrl = mainfrm->m_wndStatusBar.GetStatusBarCtrl();
	statusCtrl.SetText(strShow, 1, 0); 	
}

CString CIcrEditView::GetCursorString()
{
	long start, end;
	CRichEditCtrl& richctrl = GetRichEditCtrl();
	richctrl.GetSel(start, end);
	long startline = richctrl.LineFromChar(start);
	long endlie = richctrl.LineFromChar(end);

	if(startline == endlie && start != end) //�û�ѡ�����ı�
	{
		return richctrl.GetSelText();
	}
	else
	{
		int nlnstart, nlnend;
		long line = richctrl.LineFromChar(end);
		int ntmp = end-richctrl.LineIndex(line); //��������ƫ��
		
		CString strline;
		GetLineString(line, strline);
		int i=0, noffset=0;
		while(noffset!=ntmp) //�õ���������е��ַ����е�λ��(�ַ���������Ϊ�����ַ�)
		{
			if(IsDBCSLeadByte(strline[i]))	++i;
			++i;	++noffset;
		}
		
		ntmp = i;
		
		while(ntmp>0)
		{
			--ntmp;
			if(!isalnum(strline[ntmp]) && strline[ntmp]!='_')
			{
				if(ntmp>0)
				{
					if(IsDBCSLeadByte(strline[ntmp-1])) //����ǲ��������ַ�
					{
						--ntmp;
					}
					else
						break;
				}
			}
		}

		if(!(isalnum(strline[ntmp]) || IsDBCSLeadByte(strline[ntmp])) || strline[ntmp]=='_')
			nlnstart = ntmp+1;
		else
			nlnstart = ntmp;
		
		ntmp = i; //��������ƫ��
		
		int nstrlen = strline.GetLength();
		while(ntmp<nstrlen-1)
		{
			if(IsDBCSLeadByte(strline[ntmp])) //����ǲ��������ַ�
				++ntmp;
			else
			{
				if(!isalnum(strline[ntmp]) && strline[ntmp]!='_')
					break;
			}						
			++ntmp;
		}
		nlnend = ntmp;
		
		CString str = strline.Mid(nlnstart, nlnend-nlnstart);
		return str;
	}
}

void CIcrEditView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CSynEditView::OnKeyDown(nChar, nRepCnt, nFlags);
	ShowCursorPosition();

	CString str = GetCursorString();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	mainfrm->m_wndToolBar.m_comboboxFind.SetWindowText(str);
}

void CIcrEditView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CSynEditView::OnKeyUp(nChar, nRepCnt, nFlags);
	ShowCursorPosition();

	CString str = GetCursorString();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	mainfrm->m_wndToolBar.m_comboboxFind.SetWindowText(str);
}


void CIcrEditView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CSynEditView::OnLButtonDown(nFlags, point);
	ShowCursorPosition();

	CString str = GetCursorString();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	mainfrm->m_wndToolBar.m_comboboxFind.SetWindowText(str);
}

void CIcrEditView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CSynEditView::OnLButtonUp(nFlags, point);
	ShowCursorPosition();

	CString str = GetCursorString();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	mainfrm->m_wndToolBar.m_comboboxFind.SetWindowText(str);
}

void CIcrEditView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	POINT ptCursor;
	::GetCursorPos(&ptCursor);
	
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_MAINFRAME));
	
	CMenu* pPopup = menu.GetSubMenu(1);
	ASSERT(pPopup != NULL);
	CWnd* pWndPopupOwner = this;
	
	while (pWndPopupOwner->GetStyle() & WS_CHILD)
		pWndPopupOwner = pWndPopupOwner->GetParent();
	
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, ptCursor.x, ptCursor.y,
		pWndPopupOwner);
	
	CSynEditView::OnRButtonDown(nFlags, point);
}
