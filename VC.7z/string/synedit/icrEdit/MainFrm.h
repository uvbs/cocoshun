// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__85B70812_749B_45EA_BDB9_C5EEB31DD1C8__INCLUDED_)
#define AFX_MAINFRM_H__85B70812_749B_45EA_BDB9_C5EEB31DD1C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ComboToolBar.h"
#include "Find.h"	// Added by ClassView
#include "Replace.h"	// Added by ClassView

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
	CStatusBar  m_wndStatusBar;
	CComboToolBar m_wndToolBar;
	CString m_strFileName;

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnSelchangeCombo();//��ӦCBN_SELCHANGE��Ϣ�ĺ���
    afx_msg void OnSelchangeComboFind();//��ӦCBN_SELCHANGE��Ϣ�ĺ���
	afx_msg void OnEditPaste();
	afx_msg void OnEditcut();
	afx_msg void OnUpdateEditcut(CCmdUI* pCmdUI);
	afx_msg void OnEditcopy();
	afx_msg void OnUpdateEditcopy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditpaste(CCmdUI* pCmdUI);
	afx_msg void OnEditundo();
	afx_msg void OnUpdateEditundo(CCmdUI* pCmdUI);
	afx_msg void OnEditredo();
	afx_msg void OnUpdateEditredo(CCmdUI* pCmdUI);
	afx_msg void OnEditselectall();
	afx_msg void OnEditfind();
	afx_msg void OnEditrepeat();
	afx_msg void OnEditrepeatnext();
	afx_msg void OnUpdateEditrepeat(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditrepeatnext(CCmdUI* pCmdUI);
	afx_msg void OnEditreplace();
	afx_msg void OnViewFont();
	afx_msg void OnFileOpen();
	afx_msg void OnEditTrimtraillingspace();
	afx_msg void OnEditTrimtraillingtab();
	afx_msg void OnEditTabtospace();
	afx_msg void OnEditSpacetotab();
	afx_msg void OnEditLeadingspacetotab();
	afx_msg void OnEditMoveright();
	afx_msg void OnEditUncomment();
	afx_msg void OnEditMoveleft();
	afx_msg void OnEditComment();
	afx_msg void OnEditLcase();
	afx_msg void OnEditUcase();
	afx_msg void OnEditInvert();
	afx_msg void OnEditCapitalize();
	afx_msg void OnEditSentancecase();
	afx_msg void OnEditInsertdatetime();
	afx_msg void OnEditInsertfile();
	afx_msg void OnUpdateEditLcase(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditInvert(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditSentancecase(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditUcase(CCmdUI* pCmdUI);
	afx_msg void OnFileNew();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFilesave();
	afx_msg void OnUpdateEditCapitalize(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int LoadToolbarCombo();
	CString GetFileContext(CString strfile);
	void SaveTheContext();
	CFind *m_pFindDialog;
	CReplace *m_pReplaceDialog;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__85B70812_749B_45EA_BDB9_C5EEB31DD1C8__INCLUDED_)
