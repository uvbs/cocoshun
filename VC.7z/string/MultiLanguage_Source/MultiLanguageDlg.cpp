// MultiLanguageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MultiLanguage.h"
#include "MultiLanguageDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CString g_LoadString(CString szID);
void g_SetDialogStrings(CDialog *pDlg,UINT uDlgID);

extern CString g_szCurPath;
extern CString g_szSettingPath;	//�������õ��ļ�·��

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	g_SetDialogStrings(this,IDD);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CMultiLanguageDlg dialog

CMultiLanguageDlg::CMultiLanguageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMultiLanguageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMultiLanguageDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMultiLanguageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMultiLanguageDlg)
	DDX_Control(pDX, IDC_COMBO1, m_cmbLang);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMultiLanguageDlg, CDialog)
	//{{AFX_MSG_MAP(CMultiLanguageDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelChangeLang)
	ON_COMMAND(ID_HELP_ABOUT, OnHelpAbout)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultiLanguageDlg message handlers

BOOL CMultiLanguageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//�������п������ԣ�װ�������б���
	LoadAllLanguage();

	m_menuMain.LoadMenu(IDR_MENU_MAIN);
	SetMenu(&m_menuMain);

	SetMenuStrings();	//���ò˵��ϵ�����

	//���öԻ����Ͽؼ�����������
	g_SetDialogStrings(this,IDD);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMultiLanguageDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMultiLanguageDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		GetDlgItem(IDC_STC_DEMO)->SetWindowText(g_LoadString("IDS_DEMO"));
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMultiLanguageDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMultiLanguageDlg::SetMenuStrings()
{
	int nCurPos = 0;
	CMenu* subMenu = m_menuMain.GetSubMenu(nCurPos);

	//�ļ��˵�
	m_menuMain.ModifyMenu(nCurPos,MF_BYPOSITION,nCurPos,g_LoadString("IDS_MENU_FILE"));
	subMenu->ModifyMenu(ID_FILE_NEW,MF_BYCOMMAND,ID_FILE_NEW,g_LoadString("IDS_MENU_FILE_NEW"));
	subMenu->ModifyMenu(ID_FILE_OPEN,MF_BYCOMMAND,ID_FILE_OPEN,g_LoadString("IDS_MENU_FILE_OPEN"));
	subMenu->ModifyMenu(ID_FILE_CLOSE,MF_BYCOMMAND,ID_FILE_CLOSE,g_LoadString("IDS_MENU_FILE_CLOSE"));
	subMenu->ModifyMenu(ID_FILE_EXIT,MF_BYCOMMAND,ID_FILE_EXIT,g_LoadString("IDS_MENU_FILE_EXIT"));

	//�༭�˵�
	subMenu = m_menuMain.GetSubMenu(++nCurPos);											
	m_menuMain.ModifyMenu(nCurPos,MF_BYPOSITION,nCurPos,g_LoadString("IDS_MENU_EDIT"));
	subMenu->ModifyMenu(ID_EDIT_CUT,MF_BYCOMMAND,ID_EDIT_CUT,g_LoadString("IDS_MENU_EDIT_CUT"));
	subMenu->ModifyMenu(ID_EDIT_COPY,MF_BYCOMMAND,ID_EDIT_COPY,g_LoadString("IDS_MENU_EDIT_COPY"));
	subMenu->ModifyMenu(ID_EDIT_PASTE,MF_BYCOMMAND,ID_EDIT_PASTE,g_LoadString("IDS_MENU_EDIT_PASTE"));

	//�����˵�
	subMenu = m_menuMain.GetSubMenu(++nCurPos);	
	m_menuMain.ModifyMenu(nCurPos,MF_BYPOSITION,nCurPos,g_LoadString("IDS_MENU_HELP"));
	subMenu->ModifyMenu(ID_HELP,MF_BYCOMMAND,ID_HELP,g_LoadString("IDS_MENU_HELP_HELP"));
	subMenu->ModifyMenu(ID_HELP_ABOUT,MF_BYCOMMAND,ID_HELP_ABOUT,g_LoadString("IDS_MENU_HELP_ABOUT"));
	
}

void CMultiLanguageDlg::LoadAllLanguage()
{
	CString szKey = "Language",szSection = "Setting";
	
	CFileFind find;
	bool ret = find.FindFile(g_szCurPath + "Language\\*.ini");
	while(ret)
	{
		ret = find.FindNextFile();
		if(find.IsDots() || find.IsDirectory()) continue;
		
		CString szValue;
		DWORD dwSize = 100;
		if(GetPrivateProfileString(szSection,szKey,"",
			szValue.GetBuffer(dwSize),dwSize,find.GetFilePath()) != 0)
		{
			m_cmbLang.AddString(szValue);
		}
		szValue.ReleaseBuffer();
	}
	find.Close();

	DWORD dwSize = 1000;
	CString szLang;
	GetPrivateProfileString(szSection,szKey,"English",szLang.GetBuffer(dwSize),dwSize,g_szSettingPath);
	szLang.ReleaseBuffer();

	m_cmbLang.SelectString(-1,szLang);
}

void CMultiLanguageDlg::OnSelChangeLang() 
{
	CString szValue;
	m_cmbLang.GetLBText(m_cmbLang.GetCurSel(),szValue);
	((CMultiLanguageApp*)AfxGetApp())->LoadLanguage(szValue);
	
	//�ı�˵�����
	SetMenuStrings();
	DrawMenuBar();		//ˢ�²˵���ʾ

	//ˢ�¶Ի����������ʾ
	g_SetDialogStrings(this,IDD);
	Invalidate(false);
}

void CMultiLanguageDlg::OnAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}

void CMultiLanguageDlg::OnHelpAbout() 
{
	OnAbout();
}

