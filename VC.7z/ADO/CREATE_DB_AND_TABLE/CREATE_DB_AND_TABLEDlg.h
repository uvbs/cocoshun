// CREATE_DB_AND_TABLEDlg.h : header file
//

#if !defined(AFX_CREATE_DB_AND_TABLEDLG_H__1F17B3AB_1842_4B61_95FB_996BFED6E684__INCLUDED_)
#define AFX_CREATE_DB_AND_TABLEDLG_H__1F17B3AB_1842_4B61_95FB_996BFED6E684__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCREATE_DB_AND_TABLEDlg dialog

class CCREATE_DB_AND_TABLEDlg : public CDialog
{
// Construction
public:
	CCREATE_DB_AND_TABLEDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCREATE_DB_AND_TABLEDlg)
	enum { IDD = IDD_CREATE_DB_AND_TABLE_DIALOG };
	CString	m_dbName;
	CString	m_tableName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCREATE_DB_AND_TABLEDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCREATE_DB_AND_TABLEDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnCreate();
	afx_msg void OnBtnCreateTable();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATE_DB_AND_TABLEDLG_H__1F17B3AB_1842_4B61_95FB_996BFED6E684__INCLUDED_)
