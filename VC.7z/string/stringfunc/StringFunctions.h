/*###############################################################################################*/
//# File Name	:	StringFunctions.h															#
//# Version		:	1.0.1																		#
//# Created By	:	Technocrat (Technocrat498@yahoo.com)										#
//# Date		:	3/20/02																		#
//# Completed	:	W/I/P																		#
//# Mod			:	3/25/02																		#
//#						Changed IsDigit Inline													#
//# Does		:	Has Function Headers														#
//# Notes		:	None																		#
/*###############################################################################################*/


#ifndef __STRINGFUNCTIONS_H__
#define __STRINGFUNCTIONS_H__

/*-----------------------------*/
			//Include

//MS C/C++ .h(s)
#include <stdio.h>
#include <malloc.h>
#include <crtdbg.h>
#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

//My .h(s)
#include "Main.h"

/*-----------------------------*/
			//Define

#define _ISDIGIT 0x10

/*-----------------------------*/
			//Inline

inline bool IsDigit(char *buf){return((*buf & _ISDIGIT) ? 1 : (*buf =='.'));}
inline char ToUpper(unsigned char a){return ((a >= 'a' && a <= 'z') ? a-('a'-'A') : a );}
inline char ToLower(unsigned char a){return ((a >= 'A' && a <= 'Z') ? a+('a'-'A') : a );}

/*-----------------------------*/
			//Classes

/*-----------------------------*/
			//Global Functions

BOOL IsNumeric(char *chString);			//Checks To See If A Char Or String Of Chars Is Numeric
BOOL IsNumeric(string *stString);		//Overloader For Strings

void Upcase(char *chString);			//Uppercases A Char Or String Of Chars
void Upcase(string *stString);			//Overloader For Strings

void Lowercase(char *chString);			//Uppercases A Char Or String Of Chars
void Lowercase(string *stString);		//Overloader For Strings

void Trim(char *t);						//Trims Spaces
void Trim(string *stString);			//Overloader For Strings	

void RTrim(char *t);					//Trims Spaces From The Right Side
void RTrim(string *stString);			//Overloader For Strings

void LTrim(char *t);					//Trims Spaces From The Left Side
void LTrim(string *stString);			//Overloader For Strings

char *right(const char *chString,unsigned int len);			//Takes Chars From The Right To The Left
string *right(const string *stString,unsigned int len);		//Overloader For Strings

char *left(const char *chString,unsigned int len);			//Takes Chars From The Left To The Right
string *left(const string *stString,unsigned int len);		//Overloader For Strings

char *mid(const char *chstring,unsigned int start,unsigned int len);			//Takes Chars From A Start Position To Then To The Right
string *mid(const string *stString,unsigned int start,unsigned int len);		//Overloader For Strings

/*-----------------------------*/
			//Global VARs

/*-----------------------------*/

#endif