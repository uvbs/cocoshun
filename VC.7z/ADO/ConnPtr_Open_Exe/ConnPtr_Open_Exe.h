// ConnPtr_Open_Exe.h : main header file for the CONNPTR_OPEN_EXE application
//

#if !defined(AFX_CONNPTR_OPEN_EXE_H__E252C81C_1168_441A_89C5_737D471E915E__INCLUDED_)
#define AFX_CONNPTR_OPEN_EXE_H__E252C81C_1168_441A_89C5_737D471E915E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CConnPtr_Open_ExeApp:
// See ConnPtr_Open_Exe.cpp for the implementation of this class
//

class CConnPtr_Open_ExeApp : public CWinApp
{
public:
	CConnPtr_Open_ExeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnPtr_Open_ExeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CConnPtr_Open_ExeApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNPTR_OPEN_EXE_H__E252C81C_1168_441A_89C5_737D471E915E__INCLUDED_)
