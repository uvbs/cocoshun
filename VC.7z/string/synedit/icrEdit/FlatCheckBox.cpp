// FlatCheckBox.cpp : implementation file
//

#include "stdafx.h"
#include "FlatCheckBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlatCheckBox

CFlatCheckBox::CFlatCheckBox()
{
	m_bHasFocus = FALSE;
}

CFlatCheckBox::~CFlatCheckBox()
{
}


BEGIN_MESSAGE_MAP(CFlatCheckBox, CButton)
	//{{AFX_MSG_MAP(CFlatCheckBox)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_ERASEBKGND()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlatCheckBox message handlers

void CFlatCheckBox::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	MakeFlat();
}


void CFlatCheckBox::MakeFlat()
{
	CDC *pDC = GetDC();

	CRect rect;
	GetClientRect( &rect );	
	pDC->FillSolidRect( &rect, ::GetSysColor(COLOR_BTNFACE) );
	CPoint p = rect.CenterPoint(); 
	rect.top = p.y - 6;
	rect.bottom = p.y + 7;
	rect.right = 13;
	pDC->Draw3dRect( &rect, ::GetSysColor(COLOR_BTNFACE), ::GetSysColor(COLOR_BTNFACE) ); 
	rect.DeflateRect( 1, 1 ); 
	pDC->Draw3dRect( &rect, ::GetSysColor(COLOR_BTNSHADOW), ::GetSysColor(COLOR_BTNHIGHLIGHT) ); 
	rect.DeflateRect( 1, 1 ); 

	pDC->FillSolidRect( &rect, ::GetSysColor(COLOR_3DHIGHLIGHT) );
	if( GetCheck() != 0 ) {
		CPen NewPen;
		NewPen.CreatePen(PS_SOLID, 0, RGB(180, 0, 0));
		CPen *OldPen = pDC->SelectObject(&NewPen); 
		CRect rect;
		GetClientRect( &rect );	
		CPoint p = rect.CenterPoint(); 
		p.x = 6;
		for(int i = -1; i < 4; i++) {
			pDC->MoveTo(p.x+i, p.y-i);
			pDC->LineTo(p.x+i, p.y-i+3); 
		}
		
		pDC->MoveTo(p.x-3, p.y-1);
		pDC->LineTo(p.x-3, p.y+2); 
		
		pDC->MoveTo(p.x-2, p.y);
		pDC->LineTo(p.x-2, p.y+3); 
		pDC->SelectObject(OldPen);
	}
	
	rect.DeflateRect( -2, -2 ); 
	rect.OffsetRect( 18, 1 ); 
	CString str;
	GetWindowText( str );
	CFont *pNewFont = GetFont();
	CFont *pOldFont = pDC->SelectObject( pNewFont );
	CSize size = pDC->GetTextExtent( str );
	rect.right = rect.left + size.cx;
/*
	if( m_bHasFocus ) {
		rect.DeflateRect( -1, -1 ); 
		rect.OffsetRect( 0, -1 ); 
		pDC->Draw3dRect( &rect, RGB(0, 0, 180), RGB(0, 0, 180) ); 
		rect.OffsetRect( 0, 1 ); 
		rect.DeflateRect( 1, 1 ); 
	}
//*/	
	int nFormat = DT_LEFT|DT_VCENTER|DT_SINGLELINE;
	if( m_bHasFocus )
		pDC->SetTextColor( RGB(0, 0, 225) );
	else
		pDC->SetTextColor( RGB(0, 0, 0) );
	pDC->SetBkColor( ::GetSysColor(COLOR_BTNFACE) ); 
	pDC->DrawText( str, &rect, nFormat );
	pDC->SelectObject( pOldFont );

	ReleaseDC(pDC);
}


void CFlatCheckBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CButton::OnLButtonDown(nFlags, point);
	MakeFlat();
}

void CFlatCheckBox::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CButton::OnLButtonUp(nFlags, point);
	MakeFlat();
}

BOOL CFlatCheckBox::OnEraseBkgnd(CDC* pDC) 
{
	BOOL bret = CButton::OnEraseBkgnd(pDC);
	MakeFlat();
	return bret;
}

void CFlatCheckBox::OnSetFocus(CWnd* pOldWnd) 
{
	m_bHasFocus = TRUE;
	CButton::OnSetFocus(pOldWnd);
}

void CFlatCheckBox::OnKillFocus(CWnd* pNewWnd) 
{
	m_bHasFocus = FALSE;
	CButton::OnKillFocus(pNewWnd);
}

void CFlatCheckBox::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CButton::OnKeyDown(nChar, nRepCnt, nFlags);
	MakeFlat();
}

void CFlatCheckBox::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CButton::OnKeyUp(nChar, nRepCnt, nFlags);
	MakeFlat();
}

