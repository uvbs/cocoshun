// DateTime.cpp : implementation file
//

#include "stdafx.h"
#include "icrEdit.h"
#include "DateTime.h"
#include "Mainfrm.h"
#include "icrEditView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

SYSTEMTIME CDateTime::m_time;
LCID CDateTime::m_id;
CListBox* CDateTime::m_pListBox = NULL;

/////////////////////////////////////////////////////////////////////////////
// CDateTime dialog


CDateTime::CDateTime(CWnd* pParent /*=NULL*/)
	: CDialog(CDateTime::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDateTime)
	m_strSel = _T("");
	//}}AFX_DATA_INIT
}


void CDateTime::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDateTime)
	DDX_Control(pDX, IDCANCEL, m_cmdCancel);
	DDX_Control(pDX, IDOK, m_cmdOk);
	DDX_Control(pDX, IDC_DATEDIALOG_LIST, m_listBox);
	DDX_LBString(pDX, IDC_DATEDIALOG_LIST, m_strSel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDateTime, CDialog)
	//{{AFX_MSG_MAP(CDateTime)
	ON_LBN_DBLCLK(IDC_DATEDIALOG_LIST, OnDblclkDatedialogList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDateTime message handlers

BOOL CDateTime::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cmdOk.SetIcon(IDI_OK); 
	m_cmdCancel.SetIcon(IDI_CANCEL); 

	m_pListBox = &m_listBox; // set static member
	GetLocalTime(&m_time);
	m_id = GetUserDefaultLCID();

	EnumDateFormats(DateFmtEnumProc, m_id, DATE_SHORTDATE);
	EnumDateFormats(DateFmtEnumProc, m_id, DATE_LONGDATE);
	EnumTimeFormats(TimeFmtEnumProc, m_id, 0);

	m_pListBox = NULL;
	m_listBox.SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CALLBACK CDateTime::DateFmtEnumProc(LPTSTR lpszFormatString)
{
	ASSERT(m_pListBox != NULL);
	TCHAR buf[256];
	VERIFY(GetDateFormat(m_id, 0, &m_time, lpszFormatString, buf, 256));
	// we can end up with same format because a format with leading
	// zeroes may be the same as one without when a number is big enough
	// e.g. 09/10/94 9/10/94 are different but 10/10/94 and 10/10/94 are
	// the same
	if (m_pListBox->FindStringExact(-1,buf) == CB_ERR)
		m_pListBox->AddString(buf);
	return TRUE;
}

BOOL CALLBACK CDateTime::TimeFmtEnumProc(LPTSTR lpszFormatString)
{
	ASSERT(m_pListBox != NULL);
	TCHAR buf[256];
	VERIFY(GetTimeFormat(m_id, 0, &m_time, lpszFormatString, buf, 256));
	// we can end up with same format because a format with leading
	// zeroes may be the same as one without when a number is big enough
	// e.g. 09/10/94 9/10/94 are different but 10/10/94 and 10/10/94 are
	// the same
	if (m_pListBox->FindStringExact(-1,buf) == CB_ERR)
		m_pListBox->AddString(buf);
	return TRUE;
}

void CDateTime::OnDblclkDatedialogList()
{
	UpdateData();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView = (CIcrEditView *)mainfrm->GetActiveView();
	icrEditView->GetRichEditCtrl().ReplaceSel(m_strSel, TRUE);
	CDialog::OnOK();
}

void CDateTime::OnCancel() 
{
	
	CDialog::OnCancel();
}

void CDateTime::OnOK() 
{
	UpdateData();
	CMainFrame *mainfrm = (CMainFrame *)AfxGetMainWnd();
	CIcrEditView *icrEditView = (CIcrEditView *)mainfrm->GetActiveView();
	icrEditView->GetRichEditCtrl().ReplaceSel(m_strSel, TRUE);
	CDialog::OnOK();
}
