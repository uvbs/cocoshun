/*###############################################################################################*/
//# File Name	:	StringFunctions.cpp															#
//# Version		:	1.0.1																		#
//# Created By	:	Technocrat (Technocrat498@yahoo.com)										#
//# Date		:	3/20/02																		#
//# Completed	:	W/I/P																		#
//# Mod			:	3/25/02																		#
//#						Changed IsNumeric, Upcase & Lowercase To Have Loops To Use Pointers		#
//#							Thanks To jim mcnamara												#
//# Does		:	Contains The Following Functions:											#
//#						IsNumeric (Checks To See If A Char Or String Is Numeric)				#
//#						Upcase (Uppercases A Char Or String)									#
//#						Lowercase(Lowercases A Char Or String)									#
//#						Trim (Trims The Spaces At The End Of A String Of Chars)					#
//#						RTrim (Trims The Spaces To The Right Of A String Of Chars)				#
//#						LTrim (Trims The Spaces To The Left Of A String Of Chars)				#
//#						right (Trims Chars From Right To Left Of A String)						#
//#						left (Trims Chars To From Left To Right Of A String)					#
//#						mid (Trims Chars To From A Position To Right Of A String)				#
//# Notes		:	The Header File (StringFunctions.h) Must Be Included						#
//# Reason		:	To hold all these functions in a classes in one cpp so I can use them in any#
//#						program.																#
//# Thanks		:	Parksie, jim mcnamara, CornedBee, Kedaman and Zaei on the VB-World.net		#
//#						C/C++ Forums for all their help with this and other C/C++ projects		#
//#					Megatron on the VB-World.net Forums for helping me with more problems than	#
//#						I care to count.  With out his help I would have quit programming along	#
//#						time ago.																#
/*###############################################################################################*/



/*-----------------------------*/
			//Include

#include "StringFunctions.h"

/*-----------------------------*/
			//Global

/*-----------------------------*/
			//.cpp Global

/*-----------------------------*/
			//.cpp Functions

/*-----------------------------*/




/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	IsNumeric()
//| In:			char *chString
//|					In Char Or String Of Chars
//| Return:		BOOL
//| Notes:		This Function Checks To Is If A Char Or A String Of Chars Is Numeric Or Not
//| Example:	char p[] = "5";
//|				BOOL bRet = FALSE;
//|				bRet = IsNumeric(p);	//Should Return True
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

BOOL IsNumeric(char *chString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	char *buf;						//Temp Char VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
	
	buf = chString;

	//Loop Through The Pointer Using The Inline Function IsDigit
	while (IsDigit(buf))
	{
		buf++;						//Increase The Pointer
	}
	return  (BOOL) (*buf==0x00);
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	IsNumeric()
//|						Overload Function
//| In:			string *stString
//|					In String Pointer
//| Return:		BOOL
//| Notes:		This Function Checks To Is If A String Of Chars Is Numeric Or Not
//| Example:	string p = "5";
//|				BOOL bRet = FALSE;
//|				bRet = IsNumeric(&p);	//Should Return True
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

BOOL IsNumeric(string *stString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	static char chTemp;					//Temp Char VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	//Loop Through The Length Of The Input
	for(unsigned int i=0; i < stString->length(); i++ )    
	{
		//Copy One Char At A Time To The Temp Char VAR
		strcpy(&chTemp,stString->substr(i,1).c_str());

		//If The Inline Function IsDigit Returns A False And It Is Not A .
		if(!IsDigit(&chTemp))
			return FALSE;
	}

	return TRUE;
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Upcase()
//| In:			char *chString
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Uppercases A Char Or Sting Of Chars
//| Example:	char p[] = "t";
//|				Upcase(p);			//Should Chang p To T
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Upcase(char *chString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string stTemp = "";					//Temp String VAR
	char *buf;
	unsigned int i =0;
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
	
	buf = chString;

	//Loop Through The Length Of The Pointer 
	while(*buf != 0x00)
	{
		//Make The Temp VAR Set To The Uppercase Of The Input VAR
		stTemp += ToUpper(chString[i]);
		buf++;
		i++;
	}

	try
	{
		//Copy Back
		strcpy(chString,stTemp.c_str());
	}
	catch(...)
	{
		return;
	}
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Upcase()
//|					Overload Function
//| In:			string *stString
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Uppercases A Char Or Sting Of Chars
//| Example:	string p = "t";
//|				Upcase(p);			//Should Chang p To T
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Upcase(string *stString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string stTemp = "";				//Temp String VAR
	static char chTemp;				//Temp Char VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
	
	//Loop Through The Length Of The Input
	for(unsigned int i=0; i<stString->size(); i++)    
	{
		//Copy One Char At A Time To The Temp Char VAR
		strcpy(&chTemp,stString->substr(i,1).c_str());
		
		//Make The Temp VAR Set To The Uppercase Of The Input VAR
		stTemp += ToUpper(chTemp);   
	}

	try
	{
		//Copy Back
		memcpy(stString,&stTemp,sizeof(stTemp));
	}
	catch(...)
	{
		return;
	}
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Lowercase()
//| In:			char *chString
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Lowercases A Char Or Sting Of Chars
//| Example:	char p[] = "T";
//|				Lowercase(p);			//Should Chang p To t
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Lowercase(char *chString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string stTemp = "";				//Temp String VAR
	char *buf;
	unsigned int i =0;
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	buf = chString;

	//Loop Through The Length Of The Pointer 
	while(*buf != 0x00)
	{
		//Make The Temp VAR Set To The Lowercase Of The Input VAR
		stTemp += ToLower(chString[i]);
		buf++;
		i++;
	}

	//Copy Back
	strcpy(chString,stTemp.c_str());
}






/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Lowercase()
//|					Overload Function
//| In:			string *stString
//|					In Char Or String Of Chars
//| Return:		BOOL
//| Notes:		This Function Lowercases A Char Or Sting Of Chars
//| Example:	string p = "T";
//|				Lowercase(p);			//Should Chang p To t
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Lowercase(string *stString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string stTemp = "";				//Temp String VAR
	static char chTemp;				//Temp Char VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	//Loop Through The Length Of The Input
	for(unsigned int i=0; i<stString->size(); i++)    
	{
		//Copy One Char At A Time To The Temp Char VAR
		strcpy(&chTemp,stString->substr(i,1).c_str());

		//Make The Temp VAR Set To The Lowercase Of The Input VAR
		stTemp += ToLower(chTemp);   
	}

	//Copy Back
	memcpy(stString,&stTemp,sizeof(stTemp));
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Trim()
//| In:			char *t
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Trims Spaces From The Begining And The End Of A String
//|				This Function Was Created By jim mcnamara on VB-World.net Forums (Modified Some)
//| Example:	char p[] = "    TTTT    ";
//|				Trim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Trim(char *t)
{
	RTrim(t);
	if (strlen(t))
		LTrim(t);
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	Trim()
//|					Overload Function
//| In:			string *stString
//|					In String
//| Return:		None
//| Notes:		This Function Trims Spaces From The Begining And The End Of A String
//|				This Function Was Created By jim mcnamara on VB-World.net Forums
//| Example:	string p = "    TTTT    ";
//|				Trim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void Trim(string *stString)
{
	RTrim(stString);
	if (stString->length())
		LTrim(stString);
}




/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	RTrim()
//| In:			char *t
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Trims Spaces From The End Of A String
//|				This Function Was Created By jim mcnamara on VB-World.net Forums (Modified Some)
//| Example:	char p[] = "TTTT    ";
//|				RTrim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void RTrim(char *t)
{
	char *buf;

	if (!strlen(t)) return;

	buf = t;
	buf += strlen(t) -1;

	while (*buf == ' ' && strlen(t) )
		*buf-- = '\0';
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	RTrim()
//|					Overload Function
//| In:			string stString
//|					In String
//| Return:		None
//| Notes:		This Function Trims Spaces From The End Of A String
//| Example:	string p = "TTTT    ";
//|				RTrim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void RTrim(string *stString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	int i;							//Count VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	if (!stString->length())					//If There Is No Length
		return;

	i = stString->length()-1;					//Set The Counter To The String Length -1

	while (stString->substr(i,1) == " ")		//While There Is Still " "
	{
		*stString = stString->substr(0, i);		//Remove Off The End Of The String
		i--;									//Advance The Counter
	}

}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	LTrim()
//| In:			char *t
//|					In Char Or String Of Chars
//| Return:		None
//| Notes:		This Function Trims Spaces From The Front Of A String
//|				This Function Was Created By jim mcnamara on VB-World.net Forums (Modified Some)
//| Example:	char p[] = "    TTTT";
//|				LTrim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void LTrim(char *t)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	char tmp[128];				//Temp Char VAR
	char *buf;					//Pointer
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
	
	if (!strlen(t)) return;

	strcpy(tmp,t);
	buf=tmp;

	while (*buf == ' ' && strlen(buf))	*buf++;

	strcpy(t,buf);
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	LTrim()
//|					Overload Function
//| In:			string *stString
//|					In String
//| Return:		None
//| Notes:		This Function Trims Spaces From The Front Of A String
//| Example:	string p = "    TTTT";
//|				LTrim(p);			//Should Chang p To "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

void LTrim(string *stString)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	int i;							//Count VAR
	string buf;						//Temp String VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	if (!stString->length()) return;						//If The Length Is 0

	i = 0;													//Setup The Counter VAR

	while (stString->substr(i,1) == " ")					//While " "
		i++;												//Increase Counter

	if (i == stString->length())							//If The Whole String Is " "
	{
		*stString = "";										//Return Blank String
		return;
	}

	try
	{
		*stString = stString->substr(i,stString->length()-i);	//Send The String Back Without The Spaces
	}
	catch(...)
	{
		*stString = "";										//Return Blank String
		return;
	}

}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*right()
//| In:			const char *chString
//|					In Char Or String Of Chars
//|				unsigned int len
//|					Length To Trim
//| Return:		char*
//| Notes:		This Function Trims Chars From Right To Left  <---
//| Example:	char p[] = "TTTT1234";
//|				LPCTSTR t;
//|				t = right(p,3);		//Should Return "234"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

char *right(const char *chString,unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	unsigned int i;				//Loop VAR
	int k, nIndex;				//More Loop VARs
	char *buf;					//Temp String VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	if (!strlen(chString))						//If There Is No String
		return NULL;							//Return NULL

	if (len > strlen(chString))					//If The Amount To Copy Is Larger Than The String
		len = strlen(chString);					//Set The Length To The Length Of The String

	buf = (char *)malloc(len + 1);

	//Copy The Part We Want From The Orginal String To The Result
	for (i = 0, nIndex = ((strlen(chString))-len), k = 0; i < len; i++)	
	{		
		if (chString[i] != '\0')			//If Not A NULL Char		
			buf[k++] = chString[nIndex++];
		else
			break;
	}

	buf[k] = '\0';						//Add A NULL Char To The End Of The String

	return buf;

}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*right()
//|					Overload Function
//| In:			string *stString
//|					In String
//|				unsigned int len
//|					Length To Trim
//| Return:		string
//| Notes:		This Function Trims Chars From Right To Left  <---
//| Example:	string p = "TTTT1234";
//|				string t;
//|				t = right(p,3);		//Should Return "234"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

string *right(const string *stString, unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string *buf;					//Temp String VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	//Error Check
	if(len <= 0 || len > stString->length() || stString->length() <= 0)
		return NULL;

	//Allocate The Buffer
	buf = (string *)malloc(sizeof(stString->substr(stString->length()-len,len)));

	try
	{
		memcpy(buf, &stString->substr(stString->length()-len,len),sizeof(stString->substr(stString->length()-len,len)));	//Move Just What Needed To Be Choped
	}
	catch(...)
	{
		return NULL;
	}

	return buf;									//Return The Buffer
}






/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*left()
//| In:			const char *stString
//|					In Char Or String Of Chars
//|				unsigned int len
//|					Length To Trim
//| Return:		char*
//| Notes:		This Function Trims Chars From Left To Right  --->
//| Example:	char p[] = "TTTT1234";
//|				LPCTSTR t;
//|				t = left(p,4);		//Should Return "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

char *left(const char *chString,unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	unsigned int i;				//Loop VAR
	int k, nIndex;				//More Loop VARs
	char *buf;					//Temp String VARs
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	if (!strlen(chString))						//If There Is No String
		return NULL;							//Return NULL

	if (len > strlen(chString))					//If The Amount To Copy Is Larger Than The String
		len = strlen(chString);					//Set The Length To The Length Of The String

	buf = (char *)malloc(len + 1);

	//Copy The Part We Want From The Orginal String To The Result
	for (i = 0, nIndex = 0, k = 0; i < len; i++)	
	{		
		if (chString[nIndex] != '\0')			//If Not A NULL Char		
			buf[k++] = chString[nIndex++];
		else
			break;
	}

	buf[k] = '\0';						//Add A NULL Char To The End Of The String

	return buf;
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*left()
//|					Overload Function
//| In:			const string *stString
//|					In String
//|				unsigned int len
//|					Length To Trim
//| Return:		string*
//| Notes:		This Function Trims Chars From Left To Right  --->
//| Example:	string p = "TTTT1234";
//|				string t;
//|				t = left(p,4);		//Should Return "TTTT"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

string *left(const string *stString,unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string *buf;					//Temp String VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	//buf = *stString;								//Move The In String To The Temp String

	//Error Check
	if(len <= 0 || len > stString->length() || stString->length() <= 0)
		return NULL;

	//Allocate The Buffer
	buf = (string *)malloc(sizeof(stString->substr(0,len)));

	try
	{
		memcpy(buf, &stString->substr(0,len),sizeof(stString->substr(0,len)));	//Move Just What Needed To Be Choped
	}
	catch(...)
	{
		return NULL;
	}

	return buf;									//Return The Buffer
}






/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*mid()
//| In:			const char *chString
//|					In Char Or String Of Chars
//|				unsigned int start
//|					Starting Position
//|				unsigned int len
//|					Length To Trim
//| Return:		char*
//| Notes:		This Function Trims Chars From A Location To Right  --->
//| Example:	char p[] = "TTTT1234";
//|				LPCTSTR t;
//|				t = mid(p,3,5);		//Should Return "T1234"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

char *mid(const char *chString,unsigned int start,unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	int i, k, nActualEnd, nActualStart, nIndex;
	char *result;
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
	
	if(!strlen(chString))					//If There Is No The Length 
		return NULL;						//Return NULL

	if (start > strlen(chString))			//Make Sure The Start Is Not More Than The Length
		return NULL;						//If It Is Return Null
	if (start < 0)							//If The Start Is Less Than 0
		nActualStart = 0;					//Set The nActualStart To 0
	else		
		nActualStart = start;				//Else Set The nActualStart

	if (len > strlen(chString))				//If The Length Is Longer Than The String
		nActualEnd = strlen(chString);		//Set The nActualEnd To The Length Of The String
	else		
		nActualEnd = len;					//Else nActualEnd To The Length

	//Make A String To Send Back
	result = (char *)malloc(nActualEnd + 1);

	//Copy The Part We Want From The Orginal String To The Result
	for (i = 0, nIndex = nActualStart, k = 0; i < nActualEnd; i++)	
	{		
		if (chString[nIndex] != '\0')			//If Not A NULL Char		
			result[k++] = chString[nIndex++];
		else
			break;
	}

	result[k] = '\0';						//Add A NULL Char To The End Of The String

	return result;							//Return The New String
}





/*##############################################################################################*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//| Function:	*mid()
//|					Overload Function
//| In:			const string *stString
//|					In String
//|				unsigned int start
//|					Starting Position
//|				unsigned int len
//|					Length To Trim
//| Return:		string*
//| Notes:		This Function Trims Chars From A Location To Right  --->
//| Example:	string p = "TTTT1234";
//|				string q;
//|				q = mid(p,3,5);		//Should Return "T1234"
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

string *mid(const string *stString,unsigned int start,unsigned int len)
{
/*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*/
	string *buf;					//Temp String VAR
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

	//Error Check
	if(len > stString->length() || len < 0 || start < 0 || start > stString->length() || stString->length() <= 0 )
		return NULL;

	//Allocate The Buffer
	buf = (string *)malloc(sizeof(stString->substr(start,len)));

	try
	{
		memcpy(buf, &stString->substr(start,len),sizeof(stString->substr(start,len)));	//Move Just What Needed To Be Choped
	}
	catch(...)						//If Something Goes Wrong
	{
		return NULL;				//Return NULL
	}

	return buf;
}