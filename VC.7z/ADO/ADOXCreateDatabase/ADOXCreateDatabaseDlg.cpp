// ADOXCreateDatabaseDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ADOXCreateDatabase.h"
#include "ADOXCreateDatabaseDlg.h"

#include "Shlwapi.h"
#pragma comment(lib,"shlwapi.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CADOXCreateDatabaseDlg dialog

CADOXCreateDatabaseDlg::CADOXCreateDatabaseDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CADOXCreateDatabaseDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CADOXCreateDatabaseDlg)
	m_dbName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CADOXCreateDatabaseDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CADOXCreateDatabaseDlg)
	DDX_Text(pDX, IDC_DBNAME, m_dbName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CADOXCreateDatabaseDlg, CDialog)
	//{{AFX_MSG_MAP(CADOXCreateDatabaseDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_CREATE, OnBtnCreate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CADOXCreateDatabaseDlg message handlers

BOOL CADOXCreateDatabaseDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CADOXCreateDatabaseDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CADOXCreateDatabaseDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CADOXCreateDatabaseDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CADOXCreateDatabaseDlg::OnBtnCreate() 
{
	//ʹ���뵽�༭��IDC_DBNAME�����ݸ��µ�m_dbName������
    UpdateData(TRUE);


    CString str;
	str="d:\\"+m_dbName+".mdb";

	//�������ݿ��Ƿ��Ѿ����ڣ���������ݿ��Ѿ����ڣ�������Ϣ�򣬷���
	//ʹ��API����PathFileExists()���·���ļ��Ƿ����
	//��ע�⣺Ϊ��ʹ��API����PathFileExists()����Ҫ����
	//#include "Shlwapi.h"
    //#pragma comment(lib,"shlwapi.lib")
	if(PathFileExists(str))
	{
		CString strTemp;
		strTemp.Format("%s�Ѵ���!",str);
		AfxMessageBox(strTemp);
		return ;
	}

	//����ADOX����ָ�벢��ʼ��ΪNULL
	//��ADOX����access���ݿⷽ���ܼ򵥣�
	//ֻ��Ҫ�½�һ��Catalog����Ȼ���������Create�����Ϳ����ˡ�
	//Catalog�� ADOX ��һ��������������������ԴģʽĿ¼�ļ��ϡ�
	//�������ֻ��֪���������ݿ�ʱʹ���������Ϳ����ˡ�
	//ע����try...catch��ϲ�׽����
	_CatalogPtr m_pCatalog = NULL;
	CString DBName="Provider=Microsoft.JET.OLEDB.4.0;Data source=";
    DBName=DBName+str;
	try
	{
		m_pCatalog.CreateInstance(__uuidof(Catalog));
		m_pCatalog->Create(_bstr_t((LPCTSTR)DBName));
	}
	catch(_com_error &e)
	{
		AfxMessageBox(e.ErrorMessage());
		return ;

	}	
}
