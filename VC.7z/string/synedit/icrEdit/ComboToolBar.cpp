// ComboToolBar.cpp : implementation file
//

#include "stdafx.h"
#include "ComboToolBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComboToolBar

CComboToolBar::CComboToolBar()
{
}

CComboToolBar::~CComboToolBar()
{
}


BEGIN_MESSAGE_MAP(CComboToolBar, CToolBar)
	//{{AFX_MSG_MAP(CComboToolBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboToolBar message handlers



